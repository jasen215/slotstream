import subprocess,json,hashlib,time,sys,re
from pathlib import Path
root=Path('/tmp/slotstream-speed-20260921');binary=Path('/Users/carlos/Projects/slotstream/apps/macos/.build/release/sevra-mac-checks')
def vm():
 s=subprocess.check_output(['vm_stat'],text=True);p=int(re.search(r'page size of (\d+)',s)[1]);v={k:int(re.search(re.escape(k)+r':\s+(\d+)',s)[1]) for k in ['Pages free','Pages purgeable','File-backed pages','Swapins','Swapouts']};v['reclaimable_gb']=sum(v[k] for k in ['Pages free','Pages purgeable','File-backed pages'])*p/1e9;return v
for check in sys.argv[1:]:
 for name in ['slotstream','sevra-mac-checks']:
  found=subprocess.run(['pgrep','-x',name],capture_output=True,text=True)
  for pid in found.stdout.split():
   args=subprocess.check_output(['ps','-p',pid,'-o','args='],text=True)
   # The concurrent static matrix only runs weights-free simulated doctor
   # commands; a real model or another app check still blocks this launch.
   assert name=='slotstream' and ' doctor ' in args and '--sim-ram ' in args,args
 assert 'swift-frontend' not in subprocess.check_output(['ps','-Ao','comm'],text=True),'compiler running'
 before=vm();assert before['reclaimable_gb']>=14,before
 home=root/(check+'-home');assert not home.exists(),home
 cmd=[str(binary),'--'+check,'--home',str(home)];start=time.monotonic()
 with (root/(check+'.stdout')).open('w') as out,(root/(check+'.stderr')).open('w') as err:r=subprocess.run(cmd,stdout=out,stderr=err,timeout=1200)
 (root/(check+'-receipt.json')).write_text(json.dumps({'command':cmd,'before':before,'after':vm(),'exit':r.returncode,'seconds':time.monotonic()-start,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()},indent=2))
 print(check,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
