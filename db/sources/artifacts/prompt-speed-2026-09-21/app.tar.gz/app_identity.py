from pathlib import Path
import json,hashlib,tarfile,sys
root=Path('/Users/carlos/Projects/slotstream');out=Path('/tmp/slotstream-speed-20260921')
paths=[p for p in (root/'apps/macos').rglob('*') if p.is_file() and not any(x in p.parts for x in ['.build','.swiftpm','.DS_Store'])]
paths += list((root/'Sources').rglob('*'));paths += [root/'Package.swift',root/'Package.resolved']
paths=sorted(p for p in paths if p.is_file());m={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
if sys.argv[1]=='before':(out/'app-source-before.json').write_text(json.dumps(m,indent=2))
else:
 assert m==json.loads((out/'app-source-before.json').read_text()),'app source changed during build'
 with tarfile.open(out/'app-source.tar.gz','w:gz') as t:
  for p in paths:t.add(p,arcname=str(p.relative_to(root)))
 b=root/'apps/macos/.build/release/sevra-mac-checks'
 (out/'app-identity.json').write_text(json.dumps({'source':m,'binary_sha256':hashlib.sha256(b.read_bytes()).hexdigest(),'archive_sha256':hashlib.sha256((out/'app-source.tar.gz').read_bytes()).hexdigest()},indent=2))
