import os, subprocess, json, time, re, hashlib, statistics
from pathlib import Path
root=Path('/tmp/slotstream-speed-20260921')
binary=Path('/Users/carlos/Projects/slotstream/.build/release/slotstream')
identity=hashlib.sha256(binary.read_bytes()).hexdigest()
results=[]
def vm():
 s=subprocess.check_output(['vm_stat'],text=True)
 p=int(re.search(r'page size of (\d+)',s)[1])
 v={k:int(re.search(re.escape(k)+r':\s+(\d+)',s)[1]) for k in ['Pages free','Pages purgeable','File-backed pages','Swapins','Swapouts']}
 return dict(v,reclaimable_gb=sum(v[k] for k in ['Pages free','Pages purgeable','File-backed pages'])*p/1e9)
for round in range(5):
 for scope in ([4096,8192] if round%2==0 else [8192,4096]):
  assert subprocess.run(['pgrep','-x','slotstream'],capture_output=True).returncode==1,'another model process'
  assert not any('swift-frontend' in s for s in subprocess.check_output(['ps','-Ao','comm'],text=True).splitlines()),'compiler present'
  before=vm();assert before['reclaimable_gb']>=14,before
  assert hashlib.sha256(binary.read_bytes()).hexdigest()==identity,'binary changed'
  stem=f'scope-pair-{round}-{scope}'
  env=dict(os.environ,SLOTSTREAM_PREFILL_CHUNK='256',SLOTSTREAM_OPT_LAYER_WORKSPACE='1',SLOTSTREAM_OPT_INDEXER_TILES='1',SLOTSTREAM_OPT_PLE_TILES='1',SLOTSTREAM_OPT_WORKSPACE_TILE='1024',SLOTSTREAM_OPT_SCOPE_FRONTIER='1',SLOTSTREAM_OPT_READ_SCOPE=str(scope))
  cmd=[str(binary),'run','--memory-gb','10','--mtp','off','--vision','off','--max-context','32768','--prefill-placeholder']
  cmd=cmd[:-1]+['--prompt-file',str(root/'scope-prompt.txt'),'--raw','--greedy','--max-tokens','1','--sample-footprint','--stats-json',str(root/(stem+'.json'))]
  started=time.monotonic()
  with (root/(stem+'.stdout')).open('w') as out,(root/(stem+'.stderr')).open('w') as err:
   r=subprocess.run(cmd,env=env,stdout=out,stderr=err,timeout=600)
  after=vm();assert r.returncode==0,(stem,r.returncode)
  d=json.loads((root/(stem+'.json')).read_text());s=d['stats']
  row={'round':round,'scope':scope,'before':before,'after':after,'binary_sha256':identity,'command':cmd,'seconds':time.monotonic()-started,'stats_file':stem+'.json','prefill_seconds':s['prefillSeconds'],'prefill_reads':s['prefillReadBytes'],'peak_gb':s['peakMemoryGB'],'valid':before['Swapins']==after['Swapins'] and before['Swapouts']==after['Swapouts']}
  results.append(row);(root/'scope-pairs.json').write_text(json.dumps(results,indent=2));print(json.dumps(row),flush=True)
  assert s['prefillTokens']==s['promptTokens'] and s['promptTokens']>=8192,s
  assert s['peakMemoryGB']<=10.0,s['peakMemoryGB']
  assert not s.get('runtimeError'),s.get('runtimeError')
pairs=[]
for r in range(5):
 a,b=[next(x for x in results if x['round']==r and x['scope']==scope) for scope in [4096,8192]]
 da,db=[json.loads((root/x['stats_file']).read_text()) for x in [a,b]]
 assert da['prompt_ids']==db['prompt_ids'] and da['output_ids']==db['output_ids'],'different work/output'
 assert da['stats']['prefillComputePasses']==db['stats']['prefillComputePasses'],'compute shape changed'
 if a['valid'] and b['valid']:pairs.append(a['prefill_seconds']/b['prefill_seconds'])
summary={'valid_pairs':len(pairs),'speedups':pairs,'median_speedup':statistics.median(pairs) if pairs else None}
(root/'scope-pairs-summary.json').write_text(json.dumps(summary,indent=2));print(summary)
