import sys,json,subprocess,re,time,hashlib
from pathlib import Path
root=Path('/tmp/slotstream-speed-20260921');binary=root/'qualified-bin/slotstream'
def memory():
 s=subprocess.check_output(['vm_stat'],text=True);p=int(re.search(r'page size of (\d+)',s)[1]);v={k:int(re.search(re.escape(k)+r':\s+(\d+)',s)[1]) for k in ['Pages free','Pages purgeable','File-backed pages','Swapins','Swapouts']};v['reclaimable_gb']=sum(v[k] for k in ['Pages free','Pages purgeable','File-backed pages'])*p/1e9;return v
for variant in sys.argv[1:]:
 assert subprocess.run(['pgrep','-x','slotstream'],capture_output=True).returncode==1,'another model process'
 assert 'swift-frontend' not in subprocess.check_output(['ps','-Ao','comm'],text=True),'compiler running'
 before=memory();assert before['reclaimable_gb']>=14,before
 stem='qualified-'+variant
 cmd=[str(binary),'optimization-state-check','--variant',variant,'--model','/Users/carlos/.slotstream/models/qwen38-flash-next-mlx-4bit','--tokens','2051','--json']
 start=time.monotonic()
 with (root/(stem+'.json')).open('w') as out,(root/(stem+'.stderr')).open('w') as err:r=subprocess.run(cmd,stdout=out,stderr=err,timeout=900)
 receipt={'command':cmd,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'before':before,'after':memory(),'seconds':time.monotonic()-start,'exit':r.returncode}
 (root/(stem+'-receipt.json')).write_text(json.dumps(receipt,indent=2))
 if r.returncode:print(stem,'FAILED',flush=True);sys.exit(r.returncode)
 d=json.loads((root/(stem+'.json')).read_text());print(stem,len(d.get('items',[])), 'passed',flush=True)
