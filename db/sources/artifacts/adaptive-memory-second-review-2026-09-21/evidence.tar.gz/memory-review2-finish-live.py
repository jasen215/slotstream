import fcntl,json,os,re,subprocess,time
from pathlib import Path
binary=Path('/Users/carlos/Projects/slotstream/.build/memory-review2-complete-igewatq5/slotstream')
checks=[('complete-pinned-server',['python3','Tools/adaptive_memory_e2e.py','--binary',str(binary),'--limit-gb','9.99','--no-elastic','--out','/tmp/memory-review2-complete-pinned-server'],13),('complete-fractional-server',['python3','Tools/adaptive_memory_e2e.py','--binary',str(binary),'--limit-gb','9.99','--out','/tmp/memory-review2-complete-fractional-server'],13),('complete-full-drill-retry',[str(binary),'elastic-drill','--slots','1000','--max-memory-gb','13','--memory-limit-gb','13','--mtp','off'],16)]
results=[]
deadline=time.monotonic()+900
for name,command,minimum in checks:
    while True:
        if time.monotonic()>deadline:raise RuntimeError('Shared model remains busy beyond bounded wait')
        with open(f'/tmp/slotstream-model-{os.getuid()}.lock','a+') as lock:
            try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:
                time.sleep(2);continue
            fcntl.flock(lock,fcntl.LOCK_UN)
        vm=subprocess.check_output(['vm_stat'],text=True)
        page=int(re.search(r'page size of (\d+)',vm)[1])
        counts={k:int(v) for k,v in re.findall(r'^([^:\n]+):\s+(\d+)\.',vm,re.M)}
        avail=sum(counts[k] for k in ['Pages free','Pages purgeable','File-backed pages'])*page/1e9
        assert avail>=minimum,(name,avail,minimum)
        # The larger exception also requires no concurrent Swift build.
        if minimum==16 and subprocess.run(['pgrep','-x','swift-build'],capture_output=True).returncode==0:
            time.sleep(2);continue
        print('START',name,'available_gb',avail,flush=True)
        log=Path('/tmp/memory-review2-'+name+'.log')
        with log.open('w') as stream:
            done=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,timeout=240)
        # A race with another task must remain a refusal, never a lock bypass.
        text=log.read_text()
        if done.returncode and 'another Slotstream model process' in text:
            log.rename(log.with_suffix('.lock-refused.log'));time.sleep(2);continue
        results.append({'name':name,'command':command,'preflight_gb':avail,'exit':done.returncode})
        Path('/tmp/memory-review2-final-live-results.json').write_text(json.dumps(results,indent=2)+'\n')
        print('END',name,'exit',done.returncode,flush=True)
        assert done.returncode==0,text[-3000:]
        break
