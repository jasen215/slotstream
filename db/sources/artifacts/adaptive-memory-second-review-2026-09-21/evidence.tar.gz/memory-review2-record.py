from pathlib import Path
import datetime,hashlib,json,re
root=Path.cwd(); temp=Path('/tmp')
binary=Path((temp/'memory-review2-complete-binary.txt').read_text())
def read(name):return (temp/('memory-review2-'+name)).read_text()
small=read('complete-small-drill-retry.log');full=read('complete-full-drill-retry.log')
assert 'ELASTIC DRILL PASS:' in small and 'ELASTIC DRILL PASS:' in full
live=json.loads(read('final-live-results.json'));assert len(live)==3 and all(x['exit']==0 for x in live)
cli=json.loads(read('complete-cli.json'));assert cli['passed']
t0=json.loads(read('complete-t0.json'));assert t0['failed']==0
proxy=json.loads(read('complete-proxy/report.json'));assert proxy['passed']
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in proxy['source_sha256'].items())
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=hashlib.sha256(binary.read_bytes()).hexdigest()
body=f'''---
type: run
meta-type: fact
created: {now}
updated: {now}
summary: Second memory review fixes small-cache recovery, fractional limits and response reporting, with final policy and live gates.
binary: {sha}
captured_at: 2026-09-21
command: Exact commands and raw outputs below and in the evidence archive
discarded: false
machines: '[[records/machines/macbook-pro-m5-pro-48gb]]'
title: Adaptive memory second adversarial review
tool: source review, policy contracts, public CLI, native runtime and UI checks
---
# Adaptive memory second review

This extends [[sources/runs/2026/09/2026-09-21-adaptive-memory-adversarial-review]]. The earlier complete live drill used a large enough cache to cross the normal growth band. A smaller cache could donate less than that band and never recover. The same gap affects a cache starting small on a busy Mac.

The final governor lets the cache reach its supported ceiling once availability no longer clamps the fresh plan. Both cooldowns, the complete live feasibility check and the saved ceiling still apply. Continued contention keeps the ordinary growth band. An intermediate fix tracked prior donations; it was replaced because it missed busy startup and added unnecessary mutable state. Final policy tests reproduce busy startup, small recovery, continued contention, cooldowns and lower ceilings. The final live small and full drills prove the actual resize path, exact outputs and bounded memory.

Other corrections retain fractional target precision in JSON and child arguments, explain the reachable hardware/RAM-share bound while busy, log explicitly disabled elasticity, and preserve the saved ceiling separately from a response's current budget. Older stored responses decode without inventing a ceiling. The actual native lifecycle verifies that a pending change does not rewrite the active response's limit.

## Coverage and evidence

[Raw archive](../../../artifacts/adaptive-memory-second-review-2026-09-21/evidence.tar.gz) preserves the path matrix, source snapshots, build outputs, intermediate failures, final reports and all eight UI renders. [Manifest](../../../artifacts/adaptive-memory-second-review-2026-09-21/manifest.json) gives the SHA-256 and byte count for every member; every member was reopened and verified. Model weights, executables and disposable Homes are excluded.

Final release CLI: `{binary.relative_to(root)}`, SHA-256 `{sha}`. The final native executable is a separate debug build with SHA-256 `f5cdbf775582fe2b7f80a15803eae6030a9efb5078a40bbe8725d75d20b74b6b`. Core policy source hashes match the final proxy. Concurrent unrelated work remains in this checkout; these checks do not certify all unrelated changes.

The review traced CLI inputs, fixed/adaptive conflicts, planner and context selection, plan copies, startup validation, launch forwarding/reuse, server metadata and timer behavior, governor pressure/poll/cooldown/resizing, native preference migration, deferred changes, release/reload, persisted response details and rendered settings. Fixed-profile diagnostics still refuse unsupported adaptive flags. The previous source receipt retains the server context-copy counterexample.

Final results: {cli['cases']} public CLI cases; {proxy['contracts']['assertions']} pure assertions, including {proxy['contracts']['gates']['M01']} memory assertions; {t0['passed']} T0 groups and {sum(len(c.get('items',[])) for c in t0['checks'])} assertions, no failures or skips. Native policy accepted 85 feasible cases and refused 215, with deferred changes, sleep, idle and context-refusal checks passing. Response persistence/backward decoding and all eight production renders passed. Harness suites passed 22 status/dispatch, 3 cleanup, 7 planner-harness and 9 context-qualification tests.

The final small drill restored 961 to 640 to 961 slots. The final full drill restored 1576 to 640 to 1576. Both held cooldowns and returned identical token IDs. The final public server retained a 9.99 GB ceiling through the real timer and a completed request; the explicit no-elastic path also completed a request and logged its pinned behavior. Native real work completed cold and warm turns, deferred a 10-to-9 GB change until the response ended, reloaded within the lower ceiling, released on idle and preserved the draft.

Commands from the repository root (exact child invocations also ride in the archive):

```sh
swift build -c release --product slotstream -j 2
python3 Tools/context_proxy.py --out /tmp/memory-review2-complete-proxy
python3 Tools/memory_override_gate.py --binary {binary.relative_to(root)} --out /tmp/memory-review2-complete-cli.json
swift build -c release --product slotstream-checks --disable-build-manifest-caching -j 2
.build/release/slotstream-checks --tier t0 --json
{binary.relative_to(root)} elastic-drill --memory-limit-gb 10 --max-memory-gb 10 --mtp off
{binary.relative_to(root)} elastic-drill --slots 1000 --max-memory-gb 13 --memory-limit-gb 13 --mtp off
python3 Tools/adaptive_memory_e2e.py --binary {binary.relative_to(root)} --limit-gb 9.99 --out /tmp/memory-review2-complete-fractional-server
python3 Tools/adaptive_memory_e2e.py --binary {binary.relative_to(root)} --limit-gb 9.99 --no-elastic --out /tmp/memory-review2-complete-pinned-server
swift build --package-path apps/macos --product sevra-mac-checks -j 2
/tmp/memory-review2-native-complete/sevra-mac-checks --performance
/tmp/memory-review2-native-complete/sevra-mac-checks --response-details
/tmp/memory-review2-native-complete/sevra-mac-checks --performance-real --home /tmp/memory-review2-native-home
SEVRA_UI_OUT=/tmp/memory-review2-ui-final bash Tools/check_sevra_memory_ui.sh
python3 Tools/verify_binary_test.py
```

## Intermediate failures and scope

A concurrent diagnostics edit temporarily broke the shared release build; its owner corrected it. New native test variables initially collided with older fixture names and were renamed. The first response screenshot had a transparent background, hiding dark text from OCR; the fixture now supplies the popover background and all final renders were inspected. SwiftPM retained one test-kit object compiled against the intermediate governor initializer; forcing its recompilation yielded the passing T0 result. Two model launches were safely refused because another task held the normal model lock. Their incomplete receipts remain archived, and are not counted as passing drills. The final retries preserve that lock and do not stop the other task's processes.

This is functional and process-memory evidence. Global paging is recorded separately, not attributed to Slotstream and not used to claim clean benchmark speed. Ordinary model runs use bounded small targets with real headroom; the full drill requires at least 16 GB reclaimable and no concurrent heavy build. Every owned model/test driver finishes or reaps its child. No memory hog was used. Larger hardware is simulated, not real allocation qualification on a 64 GiB Mac. The entire release battery was not rerun and no release was published.
'''
for title,name in [('Final small recovery','complete-small-drill-retry.log'),('Final full recovery','complete-full-drill-retry.log'),('Native real lifecycle','native-real.log'),('Native policy','complete-native-policy.log'),('Response persistence','complete-response-details.log'),('Rendered UI','ui-final.log'),('Public fractional server','complete-fractional-server.log'),('Public pinned server','complete-pinned-server.log')]:
 body += '\n## '+title+'\n\n```text\n'+read(name).rstrip()+'\n```\n'
p=root/'db/sources/runs/2026/09/2026-09-21-adaptive-memory-second-review.md'
assert not p.exists();p.write_text(body)
print(p)
