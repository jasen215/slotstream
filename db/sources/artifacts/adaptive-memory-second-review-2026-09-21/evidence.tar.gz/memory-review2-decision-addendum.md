
## Second review correction, September 21

The second pass found a separate recovery gap. A small cache could remain below the fully affordable supported budget indefinitely because its missing capacity was smaller than the normal growth band. This affects both a busy startup and a later pressure donation. The governor now completes growth to the supported ceiling when the fresh plan is no longer availability-clamped. It still requires both cooldowns and all physical/ceiling checks. While availability continues to clamp the plan, the normal growth band remains. This avoids extra recovery state and does not infer that every transient increase in free memory should cause an allocation. Revisit this exception if measured resize churn appears; the small-cache and full live drills must retain exact output and bounded process memory.

The same pass preserves exact fractional target values in JSON and launch arguments, explains the reachable hardware/RAM-share bound while busy, explicitly logs disabled elasticity, and records a response's saved ceiling separately from its current budget. Historical response records with no ceiling remain readable and do not invent one.

Evidence and corrected fixtures are [[sources/runs/2026/09/2026-09-21-adaptive-memory-second-review]]. This is development qualification, not a published release or real allocation qualification on a 64 GiB Mac.
