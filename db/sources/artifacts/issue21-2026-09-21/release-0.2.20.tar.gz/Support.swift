import Foundation
public enum GatewayDialect {
public enum ToolChoice: Equatable, Sendable {
        case auto
        /// The wire value is "none". The case is NOT called `none`: in any
        /// optional context Swift resolves a bare `.none` to `Optional.none`,
        /// so `choice == .none` silently compares against nil instead. The
        /// first gate written against this hit exactly that.
        case disabled
        case required
        case tool(String)

        public var isNamedTool: Bool {
            if case .tool = self { return true }
            return false
        }
        public var label: String {
            switch self {
            case .auto: return "auto"
            case .disabled: return "none"
            case .required: return "required"
            case .tool(let n): return "tool(\(n))"
            }
        }
    }
}
public enum OpenAIDialect {
public static func toolCall(_ call: ParsedToolCall) -> [String: Any] {
        ["id": call.id, "type": "function", "function": ["name": call.name, "arguments": call.inputJSON]]
    }
}
public enum RuntimeClock {
    public static func now() -> UInt64 { DispatchTime.now().uptimeNanoseconds }
    public static func seconds(since start: UInt64) -> Double {
        Double(now() - start) / 1e9
    }
}
