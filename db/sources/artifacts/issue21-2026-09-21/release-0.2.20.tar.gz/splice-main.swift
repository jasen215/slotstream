import Foundation
@main struct Main {
 static func main() {
  let prefix=Array("PROMPT-ONE".utf8).map(Int.init)
  let first="First answer."
  let subsequent="<|im_end|>\n<|im_start|>user\nNext question<|im_end|>\n<|im_start|>assistant\nSecond answer."
  let cache=CacheProbe()
  cache.entries=[.init(tokens:prefix+Array(first.utf8).map(Int.init)),.init(tokens:prefix+Array((first+subsequent).utf8).map(Int.init))]
  let picked=cache.peek(extending:prefix)!
  let generated=String(decoding:picked.dropFirst(prefix.count).map(UInt8.init),as:UTF8.self)
  let turn=ChatMessage(role:"assistant",content:first)
  let exact=SpliceProbe.spliceDescribes(first,turn,tools:[])
  let selected=SpliceProbe.spliceDescribes(generated,turn,tools:[])
  precondition(exact && !selected)
  print("prefix splice fixture: original first-turn state matches=\(exact); peek selects later descendant=\(picked.count > cache.entries[0].tokens.count); selected remainder matches first turn=\(selected)")
 }
}
