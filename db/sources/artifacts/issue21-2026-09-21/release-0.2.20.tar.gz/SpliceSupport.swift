import Foundation
public enum GatewayDialect {
public enum ToolChoice: Equatable, Sendable {
        case auto
        /// The wire value is "none". The case is NOT called `none`: in any
        /// optional context Swift resolves a bare `.none` to `Optional.none`,
        /// so `choice == .none` silently compares against nil instead. The
        /// first gate written against this hit exactly that.
        case disabled
        case required
        case tool(String)

        public var isNamedTool: Bool {
            if case .tool = self { return true }
            return false
        }
        public var label: String {
            switch self {
            case .auto: return "auto"
            case .disabled: return "none"
            case .required: return "required"
            case .tool(let n): return "tool(\(n))"
            }
        }
    }
}
public enum OpenAIDialect {
public static func toolCall(_ call: ParsedToolCall) -> [String: Any] {
        ["id": call.id, "type": "function", "function": ["name": call.name, "arguments": call.inputJSON]]
    }
}
public enum RuntimeClock {
    public static func now() -> UInt64 { DispatchTime.now().uptimeNanoseconds }
    public static func seconds(since start: UInt64) -> Double {
        Double(now() - start) / 1e9
    }
}

public struct ChatMessage {
    public var role: String
    public var content: String
    /// An assistant turn's reasoning, rendered as `reasoning_content`. Clients
    /// that keep reasoning in history can replay it; fx does not send any.
    public var reasoning: String?
    /// Calls this assistant turn made.
    public var toolCalls: [ParsedToolCall]
    /// For a `tool` message: which call it answers.
    public var toolCallId: String?
    public var toolName: String?
    /// Pictures this turn carries, as inline bytes (a `data:` URL or bare
    /// base64) in the order the template should render them. Text-only paths
    /// leave it empty and behave exactly as before.
    public var images: [String] = []

    public init(role: String, content: String) {
        self.role = role
        self.content = content
        self.reasoning = nil
        self.toolCalls = []
        self.toolCallId = nil
        self.toolName = nil
    }

    public init(
        role: String, content: String, reasoning: String? = nil,
        toolCalls: [ParsedToolCall] = [], toolCallId: String? = nil, toolName: String? = nil
    ) {
        self.role = role
        self.content = content
        self.reasoning = reasoning
        self.toolCalls = toolCalls
        self.toolCallId = toolCallId
        self.toolName = toolName
    }

    /// The dictionary the chat template consumes.
    ///
    /// Tool-call arguments are bridged as an unordered dictionary because
    /// swift-jinja accepts nothing else, so the template's `arguments|items`
    /// follows Swift's hash order. That is why a generated assistant turn is
    /// spliced back as raw ids rather than re-rendered (`PrefixCache`): a
    /// re-render is semantically identical but not byte-identical, and the
    /// prefix cache matches on bytes.
    public var templateValue: [String: any Sendable] {
        var m: [String: any Sendable] = ["role": role, "content": content]
        // The template checks each content part for an `image`/`image_url`
        // key, so a turn with pictures has to arrive as parts rather than a
        // string. Images first, then the text: that is the order the template
        // numbers them in ("Picture 1: ..."), and the order
        // `Engine.imageSources` reads them back in.
        if !images.isEmpty {
            var parts: [[String: any Sendable]] = images.map {
                ["type": "image_url", "image_url": ["url": $0] as [String: any Sendable]]
            }
            if !content.isEmpty { parts.append(["type": "text", "text": content]) }
            m["content"] = parts
        }
        if let r = reasoning, !r.isEmpty { m["reasoning_content"] = r }
        if !toolCalls.isEmpty {
            m["tool_calls"] = toolCalls.map { call in
                [
                    "type": "function",
                    "function": [
                        "name": call.name,
                        "arguments": call.arguments.mapValues { $0.any },
                    ] as [String: any Sendable],
                ] as [String: any Sendable]
            }
        }
        return m
    }
}
final class ThinkSplitter {
    private static let tag = "</think>"
    private var buf = ""
    private var closed = false

    /// Splits one delta into (thinking, content). Until the tag arrives the
    /// last few characters are withheld, so a tag straddling two deltas is
    /// never emitted as reasoning text.
    func push(_ s: String) -> (String, String) {
        if closed { return ("", s) }
        buf += s
        if let r = buf.range(of: Self.tag) {
            let think = String(buf[..<r.lowerBound])
            var rest = String(buf[r.upperBound...])
            while rest.hasPrefix("\n") { rest.removeFirst() }
            buf = ""
            closed = true
            return (think, rest)
        }
        let keep = min(buf.count, Self.tag.count - 1)
        let emit = String(buf.dropLast(keep))
        buf = String(buf.suffix(keep))
        return (emit, "")
    }

    /// Whatever is still withheld when generation ends. A response that never
    /// closed its reasoning is all thinking and no answer, and says so.
    func flush() -> (String, String) {
        let rest = buf
        buf = ""
        return closed ? ("", rest) : (rest, "")
    }

    /// The same split over a whole non-streamed response.
    static func split(_ text: String) -> (String, String) {
        guard let r = text.range(of: tag) else { return (text, "") }
        var content = String(text[r.upperBound...])
        while content.hasPrefix("\n") { content.removeFirst() }
        return (String(text[..<r.lowerBound]), content)
    }
}
enum SpliceProbe {
public static func spliceDescribes(
        _ generated: String, _ message: ChatMessage, tools: [ToolDefinition]
    ) -> Bool {
        let (_, body) = ThinkSplitter.split(generated)
        let visible = body.isEmpty && !generated.contains("</think>") ? generated : body
        let events = ToolCallSplitter.parseAll(visible, tools: tools.map { $0.schema })
        var calls: [ParsedToolCall] = []
        var text = ""
        for e in events {
            switch e {
            case .toolCall(let c): calls.append(c)
            case .text(let t): text += t
            case .malformed: return false
            default: break
            }
        }
        guard calls.count == message.toolCalls.count else { return false }
        for (a, b) in zip(calls, message.toolCalls) {
            guard a.name == b.name, a.arguments == b.arguments else { return false }
        }
        // The text is compared after trimming only. A client that rewrites the
        // assistant's prose is describing a different turn, and re-rendering it
        // is then the correct answer.
        return text.trimmingCharacters(in: .whitespacesAndNewlines)
            == message.content.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
final class CacheProbe {
 struct Entry { var tokens:[Int]; var images:[Int]=[]; var reusable=false }
 let lock=NSLock(); var entries:[Entry]=[]; var _enabled=true
 var _persistent:PersistentPrefixCache?=nil
public func peek(extending prefix: [Int]) -> [Int]? {
        let (retained, tier) = lock.withLock { () -> ([Int]?, PersistentPrefixCache?) in
            guard _enabled else { return (nil, nil) }
            var best: [Int]?
            // Vision entries are skipped: the caller splices these ids into a
            // text-only render that carries no images, and the resulting prompt
            // would claim placeholder tokens it has no embeddings for.
            for e in entries
            where !e.reusable && e.images.isEmpty && e.tokens.count > prefix.count
                && e.tokens.starts(with: prefix) {
                if best == nil || e.tokens.count > best!.count { best = e.tokens }
            }
            return (best, _persistent)
        }
        // After a restart, or for a conversation longer than memory retains,
        // the previous turn's exact ids exist only in the persistent tier.
        guard let stored = tier?.longestExtension(of: prefix), stored.count > (retained?.count ?? 0)
        else { return retained }
        return stored
    }
}
final class PersistentPrefixCache { func longestExtension(of prefix:[Int])->[Int]? { nil } }
