import Foundation
@main struct Main { static func main() { let v = ToolCallSplitter.coerce("1e20", as: .integer); precondition(v == .double(1e20)); print("current main integer 1e20: survived, represented as a finite number") } }
