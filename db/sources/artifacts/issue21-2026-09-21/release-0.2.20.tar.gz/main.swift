import Foundation
import Darwin
if CommandLine.arguments.contains("crash-integer") {
    print(ToolCallSplitter.coerce("1e20", as: .integer))
    exit(0)
}
let tool = ToolDefinition(name: "save_page", description: "save", parameters: .object([
 "type": .string("object"), "properties": .object(["content": .object(["type": .string("string")])])]))
func pair() -> (ToolCallSplitter, OpenAIOutput) {
 (ToolCallSplitter(tools: [tool.schema], idFactory: { "call_test" }),
 OpenAIOutput(tools: [tool], choice: .auto, parallel: true))
}
let opening = "<tool_call>\n<function=save_page>\n<parameter=content>\n"
let closeParam = "\n</parameter>"
let closeCall = "\n</function>\n</tool_call>"
do {
 let (p,o) = pair()
 var count = 0
 for _ in 0..<16000 { count += o.consume(p.push("abcd")).count }
 count += o.consume(p.flush()).count
 assert(count == 16000 && o.text.count == 64000 && o.error == nil)
 print("plain text WITH tools: \(count) deltas, \(o.text.count) chars, finish=\(o.finishReason("length"))")
}
do {
 let (p,o) = pair()
 var count = o.consume(p.push(opening)).count
 let t = RuntimeClock.now()
 for _ in 0..<16000 { count += o.consume(p.push("abcd")).count }
 assert(count == 0)
 let events = p.push(closeParam)
 let parameterDeltas = events.filter { if case .toolInputDelta = $0 { return true }; return false }.count
 count += o.consume(events).count
 assert(count == 0 && parameterDeltas == 1)
 print("64 KB tool argument: \(count) OpenAI deltas before call closure; parser emitted \(parameterDeltas) argument delta; elapsed=\(RuntimeClock.seconds(since:t))s")
 count += o.consume(p.push(closeCall)).count
 assert(count == 1 && o.calls.count == 1 && o.error == nil)
 print("closed tool call: \(count) OpenAI delta, arguments=\(o.calls[0].inputJSON.utf8.count) bytes")
}
do {
 let (p,o) = pair()
 let deltas = o.consume(p.push(opening + String(repeating:"abcd", count:16000))) + o.consume(p.flush())
 _ = o.finishReason("length")
 assert(deltas.isEmpty && o.calls.isEmpty && o.error != nil)
 print("truncated tool call: \(deltas.count) deltas, \(o.text.count) text chars, error=\(o.error!)")
}
do {
 let (p,o) = pair()
 let deltas = o.consume(p.push(opening + String(repeating:"x",count:1_048_576) + closeParam + closeCall))
 let object: [String: Any] = ["choices": [["index":0,"delta":deltas[0],"finish_reason":NSNull()]]]
 let frame = Data("data: ".utf8) + (try JSONSerialization.data(withJSONObject:object)) + Data("\n\n".utf8)
 var fds: [Int32] = [0,0]; assert(socketpair(AF_UNIX,SOCK_STREAM,0,&fds) == 0)
 let out = BoundedOutput(fd:fds[0])
 let accepted = out.enqueue(frame)
 let drained = out.finish()
 assert(!accepted && !drained)
 print("oversized completed call: \(frame.count)-byte SSE frame, accepted=\(accepted), written=\(out.snapshot.writtenBytes), failed=\(out.snapshot.failed)")
 close(fds[0]);close(fds[1])
}
