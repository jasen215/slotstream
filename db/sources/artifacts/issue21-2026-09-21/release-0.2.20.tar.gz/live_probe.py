import http.client, json, os, socket, subprocess, time
from pathlib import Path
root=Path(__file__).resolve().parent
vm=subprocess.check_output(['vm_stat'],text=True)
import re
page=int(re.search(r'page size of (\d+) bytes',vm).group(1))
counts={k:int(v) for k,v in re.findall(r'^([^:\n]+):\s+(\d+)\.',vm,re.M)}
reclaim=sum(counts[k] for k in ['Pages free','Pages purgeable','File-backed pages'])*page/1e9
assert reclaim>12, reclaim
print('reclaimable_GB',round(reclaim,2),flush=True)
with socket.socket() as s:
 s.bind(('127.0.0.1',0));port=s.getsockname()[1]
log=(root/'live-server.log').open('w')
proc=subprocess.Popen([str(root/'slotstream'),'serve','--model','/Users/carlos/.slotstream/models/qwen38-flash-next-mlx-4bit','--memory-gb','8.1','--max-context','32768','--vision','off','--mtp','off','--port',str(port)],stdout=log,stderr=subprocess.STDOUT)
results=[]
def request(label,body):
 start=time.monotonic(); c=http.client.HTTPConnection('127.0.0.1',port,timeout=120)
 try:
  c.request('POST','/v1/chat/completions',body=json.dumps(body),headers={'Content-Type':'application/json'})
  r=c.getresponse();raw=[];events=[];first=None;keep=0
  while True:
   line=r.readline()
   if not line:break
   raw.append(line)
   if line.startswith(b':'):keep+=1
   if line.startswith(b'data: '):
    if first is None:first=time.monotonic()-start
    data=line[6:].strip()
    events.append(data.decode() if data==b'[DONE]' else json.loads(data))
  out={'label':label,'status':r.status,'seconds':round(time.monotonic()-start,2),'first_data_seconds':None if first is None else round(first,2),'keepalives':keep,'events':events}
  (root/(label+'.sse')).write_bytes(b''.join(raw))
  results.append(out)
  print(json.dumps(out),flush=True)
 finally:c.close()
try:
 deadline=time.monotonic()+90
 while time.monotonic()<deadline:
  if proc.poll() is not None:raise RuntimeError('server exited '+str(proc.returncode))
  try:
   c=http.client.HTTPConnection('127.0.0.1',port,timeout=1);c.request('GET','/api/version');r=c.getresponse();r.read();c.close();break
  except (OSError,http.client.HTTPException):time.sleep(.25)
 else:raise RuntimeError('startup timeout')
 base={'model':'qwen3.8-flash-next:4bit','stream':True,'temperature':0,'seed':42,'max_tokens':16,'stream_options':{'include_usage':True}}
 tool={'type':'function','function':{'name':'save_page','description':'Save a complete page of text.','parameters':{'type':'object','properties':{'content':{'type':'string'}},'required':['content']}}}
 msg=[{'role':'user','content':'Count from 1 to 100, writing every number separated by commas. Do not call any tools. Just write the numbers.'}]
 request('plain-cap',dict(base,messages=msg))
 request('tools-unused-cap',dict(base,messages=msg,tools=[tool]))
 request('truncated-call',dict(base,max_tokens=32,messages=[{'role':'user','content':'Use save_page to save a complete 1000-word essay about the ocean. Write all 1000 words in the content argument.'}],tools=[tool],tool_choice={'type':'function','function':{'name':'save_page'}}))
 print('server_still_alive',proc.poll() is None,flush=True)
finally:
 if proc.poll() is None:
  proc.terminate()
  try:proc.wait(timeout=20)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
 log.close()
 (root/'live-results.json').write_text(json.dumps(results,indent=2))
 print('test_server_reaped',proc.pid,proc.returncode,flush=True)
