import http.client,json,os,re,socket,subprocess,time
from pathlib import Path
root=Path('/tmp/slotstream-issue21-fixed')
repo=Path('/Users/carlos/Projects/slotstream')
owned=None
log=None

def start(label):
 global owned,log
 pids=subprocess.run(['pgrep','-x','slotstream'],capture_output=True,text=True).stdout.split()
 for pid in pids:
  command=subprocess.run(['ps','-p',pid,'-o','command='],capture_output=True,text=True).stdout.strip()
  assert not command or re.search(r'slotstream doctor ',command), 'another model is running: '+command
 vm=subprocess.check_output(['vm_stat'],text=True)
 page=int(re.search(r'page size of (\d+) bytes',vm)[1]);counts=dict((k,int(v)) for k,v in re.findall(r'^([^:\n]+):\s+(\d+)\.',vm,re.M))
 reclaim=sum(counts[k] for k in ['Pages free','Pages purgeable','File-backed pages'])*page/1e9
 assert reclaim>12,reclaim
 print('reclaimable_GB',round(reclaim,2),flush=True)
 with socket.socket() as sock:
  sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 log=(root/(label+'-server.log')).open('w')
 owned=subprocess.Popen([str(root/'bin/slotstream'),'serve','--model','/Users/carlos/.slotstream/models/qwen38-flash-next-mlx-4bit',
   '--memory-gb','8.1','--max-context','32768','--vision','off','--mtp','off','--port',str(port),
   '--prefix-cache-dir',str(root/'prefix'),'--prefix-cache-min-tokens','512'],stdout=log,stderr=subprocess.STDOUT)
 for _ in range(180):
  assert owned.poll() is None, 'server exited '+str(owned.returncode)
  try:
   c=http.client.HTTPConnection('127.0.0.1',port,timeout=1);c.request('GET','/api/version');r=c.getresponse();r.read();c.close()
   if r.status==200:return port
  except (OSError,http.client.HTTPException):pass
  time.sleep(.5)
 raise RuntimeError('startup timeout')

def stop():
 global owned,log
 if owned is not None:
  if owned.poll() is None:
   owned.terminate()
   try:owned.wait(timeout=20)
   except subprocess.TimeoutExpired:owned.kill();owned.wait()
  print('test_server_reaped',owned.pid,owned.returncode,flush=True);owned=None
 if log:log.close();log=None

try:
 port=start('restart')
 original=json.loads((root/'issue21/cache-turn-3.json').read_text())
 c=http.client.HTTPConnection('127.0.0.1',port,timeout=180)
 c.request('POST','/v1/chat/completions',json.dumps(original['request']),{'Content-Type':'application/json'})
 r=c.getresponse();raw=r.read().decode();c.close();(root/'restart.sse').write_text(raw)
 events=[json.loads(line[6:]) for line in raw.splitlines() if line.startswith('data: ') and line!='data: [DONE]']
 def message(events):
  out={'content':'','reasoning_content':''}
  for ev in events:
   if not isinstance(ev,dict):continue
   for choice in ev.get('choices',[]):
    for k in out:out[k]+=choice['delta'].get(k,'')
  return out
 assert r.status==200 and 'data: [DONE]' in raw and not any('error' in e for e in events)
 assert message(events)==message(original['events']),(message(events),message(original['events']))
 usage=next(e['usage'] for e in reversed(events) if e.get('usage'))
 assert usage['prompt_tokens_details']['cached_tokens']>0,usage
 (root/'restart-result.json').write_text(json.dumps({'same_message':True,'usage':usage},indent=2))
 print('PASS restart restores a three-turn spliced conversation with identical output',usage,flush=True)
 assert owned.poll() is None
 import sys
 sys.path.insert(0,str(repo))
 from Tools.issue21_gate import check_disconnect
 check_disconnect(port,root/'disconnect')
finally:stop()
