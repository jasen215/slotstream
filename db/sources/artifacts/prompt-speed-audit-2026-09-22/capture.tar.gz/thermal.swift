import Foundation
let names = ["nominal", "fair", "serious", "critical"]
let raw = ProcessInfo.processInfo.thermalState.rawValue
let state = names.indices.contains(raw) ? names[raw] : "unknown"
print("\(state) \(ProcessInfo.processInfo.isLowPowerModeEnabled)")
