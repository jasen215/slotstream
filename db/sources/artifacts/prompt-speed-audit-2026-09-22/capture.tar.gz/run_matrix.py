from pathlib import Path
import json,sys,time,subprocess,signal,os
R=Path(__file__).resolve().parent
S=Path('/tmp/slotstream-release-0.2.23-20260922/source')
started=time.monotonic()
while not (R/'short_decode_8g/completion.json').exists():
 if time.monotonic()-started>1800:raise TimeoutError('first cohort did not finish')
 time.sleep(2)
manifest=json.loads((R/'study.json').read_text())
results=[]
for case in manifest['cases'][1:]:
 name=case['name']; print(json.dumps({'study':name,'phase':'start'}),flush=True)
 command=[sys.executable,str(S/'Tools/serve_bench.py'),'--protocol',str(R/'protocols'/f'{name}.json'),'--out',str(R/name)]
 with (R/f'{name}.driver.log').open('w') as log:
  child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,cwd=S,start_new_session=True)
  try:
   for line in child.stdout:log.write(line);log.flush();print(line,end='',flush=True)
   code=child.wait()
  finally:
   if child.poll() is None:
    os.killpg(child.pid,signal.SIGINT)
    try:child.wait(timeout=20)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGTERM);child.wait()
 results.append({'study':name,'exit':code})
 (R/'matrix-progress.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(results[-1]),flush=True)
 if code not in [0,1]:raise RuntimeError('unexpected harness failure')
print('MATRIX_COMPLETE',flush=True)
