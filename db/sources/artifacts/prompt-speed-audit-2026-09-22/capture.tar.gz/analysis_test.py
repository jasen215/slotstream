import unittest,copy
from analyze import eligible,metric_summary
class AnalysisChecks(unittest.TestCase):
 def setUp(self):
  self.p={'maximum_sampled_footprint_bytes':10_000_000_000,'require_nominal_power_state':True}
  self.s={'prefillSeconds':2,'decodeTokens':1,'sampledFootprint':{'peakBytes':9_000_000_000},'generatorVMBefore':{'swapins':1,'swapouts':2},'generatorVMAfter':{'swapins':1,'swapouts':2},'generatorSystemBefore':{'thermalState':'nominal','lowPowerModeEnabled':False},'generatorSystemAfter':{'thermalState':'nominal','lowPowerModeEnabled':False}}
  self.d={'metrics':{'stats':self.s}}
 def test_clean(self):self.assertEqual(eligible(self.d,self.p),[])
 def test_swapin(self):
  self.s['generatorVMAfter']['swapins']+=1;self.assertIn('generator swap activity',eligible(self.d,self.p))
 def test_swapout(self):
  self.s['generatorVMAfter']['swapouts']+=1;self.assertIn('generator swap activity',eligible(self.d,self.p))
 def test_client_interval(self):
  self.assertIn('client interval swap activity',eligible(self.d,self.p,{'before':{'swapins':1,'swapouts':1},'after':{'swapins':2,'swapouts':1}}))
 def test_peak(self):
  self.s['sampledFootprint']['peakBytes']=10_000_000_001;self.assertTrue(eligible(self.d,self.p))
 def test_thermal(self):
  self.s['generatorSystemAfter']['thermalState']='fair';self.assertTrue(eligible(self.d,self.p))
 def test_power(self):
  self.s['generatorSystemBefore']['lowPowerModeEnabled']=True;self.assertTrue(eligible(self.d,self.p))
 def test_missing(self):self.assertTrue(eligible({},self.p))
 def test_cancel(self):
  self.s['memoryPressureCancelled']=True;self.assertTrue(eligible(self.d,self.p))
 def test_no_output(self):
  self.s['decodeTokens']=0;self.assertTrue(eligible(self.d,self.p))
 def test_paired_not_ratio_of_medians(self):
  pairs=[{'old':{'x':v},'new':{'x':w}} for v,w in [(1,2),(2,1),(100,50)]]
  r=metric_summary(pairs,'x');self.assertEqual(r['median_paired_reduction_pct'],50);self.assertEqual(r['individual_reduction_pct'],[-100,50,50]);self.assertTrue(r['qualified'])
  self.assertFalse(metric_summary(pairs[:2],'x')['qualified'])
  self.assertEqual(metric_summary(pairs,'x',lambda x:False)['pairs'],0)
 def test_missing_or_zero_timer(self):
  self.assertEqual(metric_summary([{'old':{'x':1},'new':{'x':None}},{'old':{'x':0},'new':{'x':1}}],'x')['pairs'],0)
if __name__=='__main__':unittest.main()
