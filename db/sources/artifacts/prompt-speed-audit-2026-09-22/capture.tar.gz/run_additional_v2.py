from pathlib import Path
import json,sys,time,subprocess,signal,os
R=Path(__file__).resolve().parent;S=Path('/tmp/slotstream-release-0.2.23-20260922/source')
start=time.monotonic()
while True:
 p=R/'matrix-progress.json'
 if p.exists() and len(json.loads(p.read_text()))==6:break
 if time.monotonic()-start>14400:raise TimeoutError('primary matrix did not finish')
 time.sleep(5)
results=[]
for case in json.loads((R/'additional-studies.json').read_text())['cases']:
 name=case['name'];print(json.dumps({'study':name,'phase':'start'}),flush=True)
 harness=R/'default_requests.py' if name.startswith('default_') else S/'Tools/serve_bench.py'
 command=[sys.executable,str(harness),'--protocol',str(R/'protocols'/f'{name}.json'),'--out',str(R/name)]
 with (R/f'{name}.driver.log').open('w') as log:
  child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,cwd=S,start_new_session=True)
  try:
   for line in child.stdout:log.write(line);log.flush();print(line,end='',flush=True)
   code=child.wait()
  finally:
   if child.poll() is None:
    os.killpg(child.pid,signal.SIGINT)
    try:child.wait(timeout=20)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGTERM);child.wait()
 results.append({'study':name,'exit':code});(R/'additional-progress.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(results[-1]),flush=True)
 if code not in [0,1]:raise RuntimeError('unexpected harness failure')
print('ADDITIONAL_COMPLETE',flush=True)
