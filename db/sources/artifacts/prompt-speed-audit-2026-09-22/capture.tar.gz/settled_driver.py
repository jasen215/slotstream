from pathlib import Path
import sys,json,time,subprocess,fcntl,os,hashlib,shutil
R=Path(__file__).resolve().parent
sys.path.insert(0,'/tmp/slotstream-release-0.2.23-20260922/source/Tools')
import serve_bench as s
p=json.loads(Path(sys.argv[sys.argv.index('--protocol')+1]).read_text())
out=Path(sys.argv[sys.argv.index('--out')+1]);probe=R/'thermal-probe'
assert hashlib.sha256(probe.read_bytes()).hexdigest()==p['thermal_probe_sha256']
count=0

def settled(seconds,wait_limit,lock_path=None):
 global count
 count+=1;start=time.monotonic();stable=None;samples=[];announced=start-30
 with open(lock_path or f'/tmp/slotstream-model-{os.getuid()}.lock','a') as lock:
  while True:
   try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);break
   except BlockingIOError:
    if time.monotonic()-start>wait_limit:raise TimeoutError('other model holds reservation')
    time.sleep(2)
  acquired=time.monotonic()
  while True:
   now=time.monotonic();value=subprocess.check_output([str(probe)],text=True,timeout=5).strip()
   samples.append({'elapsed':now-acquired,'state':value})
   if value=='nominal false':
    if stable is None:stable=now
   else:stable=None
   stable_seconds=0 if stable is None else now-stable
   if now-announced>=30:
    print(json.dumps({'phase':'thermal settling','cell':count,'elapsed':round(now-acquired),'nominal_seconds':round(stable_seconds),'required':p['thermal_settle_seconds'],'state':value}),flush=True);announced=now
   if stable_seconds>=p['thermal_settle_seconds'] and now-acquired>=seconds:break
   if now-acquired>=900:raise TimeoutError('thermal state did not settle within900seconds')
   time.sleep(2)
 record={'reserved':True,'wait_seconds':acquired-start,'settle_seconds':time.monotonic()-acquired,'required_nominal_seconds':p['thermal_settle_seconds'],'samples':samples}
 out.mkdir(parents=True,exist_ok=True)
 (out/f'thermal-cell-{count}.json').write_text(json.dumps(record,indent=2)+'\n')
 return record
s.reserved_cooldown=settled
if p.get('mode')=='first_request_prefix_enabled':
 import default_requests
 code=default_requests.main()
else:code=s.main()
(out/'settling-identity.json').write_text(json.dumps({'wrapper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'probe_sha256':hashlib.sha256(probe.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256((R/'thermal.swift').read_bytes()).hexdigest()},indent=2)+'\n')
raise SystemExit(code)
