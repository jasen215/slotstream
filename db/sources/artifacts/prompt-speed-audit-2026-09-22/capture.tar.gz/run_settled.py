from pathlib import Path
import json,sys,subprocess,signal,os,hashlib
R=Path(__file__).resolve().parent;S=Path('/tmp/slotstream-release-0.2.23-20260922/source');results=[]
for case in json.loads((R/'settled-study.json').read_text())['cases']:
 name=case['name'];protocol=R/'protocols'/f'{name}.json'
 assert hashlib.sha256(protocol.read_bytes()).hexdigest()==case['protocol_sha256']
 harness=R/'settled_driver.py'
 print(json.dumps({'study':name,'phase':'start'}),flush=True)
 with (R/f'{name}.driver.log').open('w') as log:
  child=subprocess.Popen([sys.executable,str(harness),'--protocol',str(protocol),'--out',str(R/name)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,cwd=S,start_new_session=True)
  try:
   for line in child.stdout:log.write(line);log.flush();print(line,end='',flush=True)
   code=child.wait()
  finally:
   if child.poll() is None:
    os.killpg(child.pid,signal.SIGINT)
    try:child.wait(timeout=20)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGTERM);child.wait()
 results.append({'study':name,'exit':code});(R/'settled-progress.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results[-1]),flush=True)
 if code not in [0,1]:raise RuntimeError('unexpected harness failure')
print('SETTLED_STUDY_COMPLETE',flush=True)
