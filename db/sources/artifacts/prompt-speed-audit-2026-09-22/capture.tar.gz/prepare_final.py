from pathlib import Path
import json,hashlib,datetime,copy
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cases=[]
for base in ['short_decode_8g','prose_2k','code_8k','prose_16k_mtp','structured_16k_mtp','prose_8k_8g','code_24k_mtp']:
 p=json.loads((R/'protocols'/f'{base}.json').read_text());p['max_tokens']=1;p['mode']='first_request_prefix_enabled'
 name='default_'+base;path=R/'protocols'/f'{name}.json';text=json.dumps(p,indent=2)+'\n'
 if path.exists():assert path.read_text()==text
 else:path.write_text(text)
 cases.append({'name':name,'protocol_sha256':sha(path),'harness':'default_requests.py','purpose':'Primary published-release first-token latency with normal cache planning'})
p=json.loads((R/'protocols/ablation_code_8k.json').read_text());p['mode']='first_request_prefix_enabled'
name='default_ablation_code_8k';path=R/'protocols'/f'{name}.json';path.write_text(json.dumps(p,indent=2)+'\n');cases.append({'name':name,'protocol_sha256':sha(path),'harness':'default_requests.py','purpose':'Same-backend first-request fusion and workspace attribution'})
for name in ['prefix_prose_off','prefix_code_on','short_setup_attribution']:
 cases.append({'name':name,'protocol_sha256':sha(R/'protocols'/f'{name}.json'),'harness':'serve_bench.py','purpose':'Separate cache followup or warm/cold setup attribution'})
(R/'final-study.json').write_text(json.dumps({'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'amendment_sha256':sha(R/'methodology-amendment.json'),'cases':cases,'timing_eligibility':'Same input ids and MTP; fixed total memory; complete request; nominal thermal and normal power; zero global swap changes in client and generator intervals; sampled peak <= target; three eligible pairs required for a repeatable median. All output differences and exclusions retained.','scope':'First-request metrics include lazy kernel setup; filesystem cache uncontrolled, no purge. Warming is studied separately. One output measures prompt latency, not full-answer or decode throughput. All settings except memory, MTP, 256-row compute, disabled elastic resizing and benchmark instrumentation retain defaults.','no_replacement_rounds':True},indent=2)+'\n')
print(json.dumps(cases,indent=2))
