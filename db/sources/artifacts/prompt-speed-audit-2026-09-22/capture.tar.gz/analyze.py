from pathlib import Path
import json,statistics,sys,math
R=Path(__file__).resolve().parent
sys.path.insert(0,'/tmp/slotstream-release-0.2.23-20260922/source/Tools')
from serve_bench import resource_exclusions

def eligible(d,p,outer=None):
 if not isinstance(d,dict) or 'metrics' not in d:return ['missing completed metrics']
 s=d['metrics']['stats']; reasons=resource_exclusions(s,p)
 if s.get('runtimeError') or s.get('memoryPressureCancelled'):reasons.append('generation failed or cancelled')
 if not s.get('decodeTokens'):reasons.append('no generated output')
 a,b=s.get('generatorVMBefore'),s.get('generatorVMAfter')
 if not a or not b or any(a[k]!=b[k] for k in ['swapins','swapouts']):reasons.append('generator swap activity')
 if outer and any(outer['before'][k]!=outer['after'][k] for k in ['swapins','swapouts']):reasons.append('client interval swap activity')
 if outer and outer.get('competing_jobs_after_measurement'):reasons.append('workspace contention')
 return reasons

def observation(d):
 s=d['metrics']['stats']
 return {'prefill_seconds':s['prefillSeconds'],'ttft_seconds':d['first_protocol_delta_seconds'],'visible_text_seconds':d['first_visible_text_seconds'],'client_seconds':d['client_seconds'],'decode_seconds':s['decodeSeconds'],'output_tokens':s['decodeTokens'],'prompt_tokens':s['promptTokens'],'read_gb':s['prefillReadBytes']/1e9,'peak_gb':s['sampledFootprint']['peakBytes']/1e9,'pool_slots':d['metrics']['effective_pool_slots'],'read_groups':s['prefillPasses'],'compute_passes':s['prefillComputePasses'],'reused_tokens':s['reusedPrefixTokens'],'prefill_io_seconds':s['prefillIOSeconds'],'prefill_gpu_wait_seconds':s['prefillGPUWaitSeconds'],'prefill_scatter_seconds':s['prefillScatterSeconds']}

def metric_summary(pairs,key,subset=lambda p:True):
 pairs=[p for p in pairs if subset(p) and all(type(p[a].get(key)) in (int,float) and math.isfinite(p[a][key]) and p[a][key]>0 for a in ['old','new'])]
 return {'pairs':len(pairs),'qualified':len(pairs)>=3,'old_median':statistics.median(p['old'][key] for p in pairs) if pairs else None,'new_median':statistics.median(p['new'][key] for p in pairs) if pairs else None,'median_paired_reduction_pct':statistics.median(100*(1-p['new'][key]/p['old'][key]) for p in pairs) if pairs else None,'individual_reduction_pct':[100*(1-p['new'][key]/p['old'][key]) for p in pairs]}

def main():
 report=[]
 studies=[]
 for manifest_name in ['final-study.json','settled-study.json','larger-profile-study.json']:
  studies.extend(json.loads((R/manifest_name).read_text())['cases'])
 # Original methodology pilot is analyzed separately; do not pool cohorts.
 for case in studies:
  name=case['name'];p=json.loads((R/'protocols'/f'{name}.json').read_text());root=R/name
  if not (root/'manifest.json').exists():continue
  candidate_names=[a for a in p['arms'] if a!='reference']
  for candidate in candidate_names:
   for phase in (['first_request'] if p.get('mode')=='first_request_prefix_enabled' else ['first_request','warmed_request']):
    pairs=[];excluded=[]
    for n in range(1,p['rounds']+1):
     values={};fail=[]
     for arm in ['reference',candidate]:
      cell=root/f'{n}-{arm}';f=cell/('warmup.json' if phase=='first_request' and p.get('mode')!='first_request_prefix_enabled' else 'result.json')
      if not f.exists():fail.append(arm+': missing');continue
      d=json.loads(f.read_text()); values[arm]=d
      outer=d if 'before' in d and 'after' in d else None
      if phase=='first_request' and outer is None and (cell/'result.json').exists():
       status=json.loads((cell/'result.json').read_text())
       if 'after_startup_vm' in status and 'after_warmup_vm' in status:outer={'before':status['after_startup_vm'],'after':status['after_warmup_vm']}
      fail.extend(arm+': '+x for x in eligible(d,p,outer))
      if 'valid' in d and not d['valid']:fail.append(arm+': '+d.get('exclusion',d.get('error','harness invalid')))
     if fail:excluded.append({'round':n,'reasons':fail});continue
     a,b=values['reference'],values[candidate];am,bm=a['metrics'],b['metrics']
     if am['prompt_ids']!=bm['prompt_ids'] or am['effective_mtp']!=bm['effective_mtp']:
      excluded.append({'round':n,'reasons':['input or MTP mismatch']});continue
     same_output=am['output_ids']==bm['output_ids'] and a['text']==b['text']
     same_decode=all(am['stats'].get(k)==bm['stats'].get(k) for k in ['decodeTokens','decodeForwardPasses','decodeModelTokens','draftedTokens','verifyPasses'])
     pairs.append({'round':n,'same_output':same_output,'same_decode_work':same_decode,'old':observation(a),'new':observation(b)})
    report.append({'case':name,'candidate':candidate,'phase':phase,'study_complete':(root/'completion.json').exists(),'memory_gb':p['memory_gb'],'mtp':p['mtp'],'pairs':pairs,'excluded':excluded,'prefill':metric_summary(pairs,'prefill_seconds'),'ttft':metric_summary(pairs,'ttft_seconds'),'end_to_end_exact_output':metric_summary(pairs,'client_seconds',lambda x:x['same_output']),'decode_exact_work':metric_summary(pairs,'decode_seconds',lambda x:x['same_output'] and x['same_decode_work'])})
 (R/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
 for row in report:
  s=row['prefill'];t=row['ttft'];e=row['end_to_end_exact_output'];
  print(json.dumps({'case':row['case'],'candidate':row['candidate'],'phase':row['phase'],'pairs':s['pairs'],'prefill_old':s['old_median'],'prefill_new':s['new_median'],'prefill_reduction_pct':s['median_paired_reduction_pct'],'ttft_reduction_pct':t['median_paired_reduction_pct'],'e2e_exact_pairs':e['pairs'],'exclusions':len(row['excluded'])}))
if __name__=='__main__':main()
