from pathlib import Path
import json,hashlib,copy,datetime
from tokenizers import Tokenizer
R=Path(__file__).resolve().parent
T=Tokenizer.from_file(str(Path.home()/'.slotstream/models/qwen38-flash-next-mlx-4bit/tokenizer.json'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base=json.loads((R/'protocols/code_8k.json').read_text()); new=base['binary']
def arm(env):return {'binary':new,'chunk':256,'env':env}
cases=[]
p=copy.deepcopy(base);p['max_tokens']=1;p['arms']={'reference':arm({'SLOTSTREAM_OPT_FUSED_PREFILL':'0','SLOTSTREAM_OPT_FUSED_WORKSPACE':'0'}),'fusion':arm({'SLOTSTREAM_OPT_FUSED_WORKSPACE':'0'}),'released':arm({})}
name='ablation_code_8k';path=R/'protocols'/f'{name}.json';path.write_text(json.dumps(p,indent=2)+'\n');cases.append({'name':name,'protocol_sha256':sha(path)})
for family,mtp in [('prose','off'),('code','on')]:
 src=(R/'fixtures'/('prose_8k_8g.txt' if family=='prose' else 'code_8k.txt')).read_text()
 ids=T.encode(src,add_special_tokens=False).ids
 # Freeze a common material prefix safely beyond the retained 2048-token boundary.
 shared=T.decode(ids[:2080],skip_special_tokens=False)+'\n'
 warm=shared+'Summarize the material in one sentence.'
 tail=shared+'Explain the most important operating constraint in one sentence.'
 warm_ids=T.encode(warm,add_special_tokens=False).ids;tail_ids=T.encode(tail,add_special_tokens=False).ids
 assert 2048<len(warm_ids)<2304 and warm_ids[:2048]==tail_ids[:2048]
 for suffix,text in [('warm',warm),('followup',tail)]: (R/'fixtures'/f'prefix_{family}_{suffix}.txt').write_text(text)
 p=copy.deepcopy(base);p['mtp']=mtp;p['raw']=True;p.pop('think');p['max_tokens']=16
 p['arms']={'reference':arm({'SLOTSTREAM_OPT_PREFIX_CHECKPOINT':'0','SLOTSTREAM_OPT_COMPLETE_PROMPT':'0'}),'released':arm({})}
 f=R/'fixtures'/f'prefix_{family}_followup.txt';w=R/'fixtures'/f'prefix_{family}_warm.txt'
 p.update(fixture=str(f),fixture_sha256=sha(f),warmup_fixture=str(w),warmup_fixture_sha256=sha(w),prefix_cache={'expected_reused_tokens':{'reference':0,'released':2048},'partial_prefix':True})
 name=f'prefix_{family}_{mtp}';path=R/'protocols'/f'{name}.json';path.write_text(json.dumps(p,indent=2)+'\n');cases.append({'name':name,'protocol_sha256':sha(path),'warm_prompt_tokens':len(warm_ids),'followup_prompt_tokens':len(tail_ids)})
(R/'additional-studies.json').write_text(json.dumps({'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Attribution and conversation reuse, frozen before these cohorts; same three-pair eligibility and no replacement rule as primary study','cases':cases},indent=2)+'\n')
print(json.dumps(cases,indent=2))
