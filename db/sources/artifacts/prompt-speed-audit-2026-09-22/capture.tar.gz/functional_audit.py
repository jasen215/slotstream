from pathlib import Path
import json,hashlib,statistics
R=Path(__file__).resolve().parent

def completed(d):
 s=d.get('metrics',{}).get('stats',{})
 return bool(s) and not s.get('runtimeError') and not s.get('memoryPressureCancelled') and s.get('decodeTokens',0)>0

def main():
 result=[]
 for root in sorted(R.iterdir()):
  if not root.is_dir() or not (root/'manifest.json').exists():continue
  manifest=json.loads((root/'manifest.json').read_text())
  if not isinstance(manifest,dict):continue
  p=manifest.get('protocol',{})
  if 'arms' not in p or 'reference' not in p['arms']:continue
  rows={}
  for path in root.glob('*-*/result.json'):
   d=json.loads(path.read_text());rows[d['round'],d['arm']]=d
  pairs=[]
  for n in range(1,p['rounds']+1):
   for arm in p['arms']:
    if arm=='reference':continue
    a,b=rows.get((n,'reference')),rows.get((n,arm))
    if not a or not b or not completed(a) or not completed(b):continue
    am,bm=a['metrics'],b['metrics'];as_,bs=am['stats'],bm['stats'];boundary=bs['reusedPrefixTokens'];consumed=0;tail=[]
    for count in as_['prefillComputePasses']:
     if consumed>=boundary:tail.append(count)
     consumed+=count
    pairs.append({'round':n,'candidate':arm,'both_timing_eligible':a['valid'] and b['valid'],'prompt_ids_equal':am['prompt_ids']==bm['prompt_ids'],'output_ids_equal':am['output_ids']==bm['output_ids'],'wire_text_equal':a['text']==b['text'],'mtp_equal':am['effective_mtp']==bm['effective_mtp'],'pool_slots':[am['effective_pool_slots'],bm['effective_pool_slots']],'compute_tail_equal_after_reuse':tail==bs['prefillComputePasses'],'reused_tokens':[as_['reusedPrefixTokens'],bs['reusedPrefixTokens']],'read_gb':[as_['prefillReadBytes']/1e9,bs['prefillReadBytes']/1e9]})
  arms={}
  for arm in p['arms']:
   ds=[d for (_,name),d in rows.items() if name==arm and completed(d)]
   if not ds:continue
   stats=[d['metrics']['stats'] for d in ds]
   lifetime=[max(s.get('lifetimePhysicalFootprintPeakBytes',0),s.get('lifetimeRSSPeakBytes',0),s.get('physicalFootprintEndBytes',0)) for s in stats]
   arms[arm]={'completed_requests':len(ds),'clean_timing_requests':sum(d['valid'] for d in ds),'output_ids_repeatable':all(d['metrics']['output_ids']==ds[0]['metrics']['output_ids'] for d in ds),'sampled_peak_gb':max(s['sampledFootprint']['peakBytes'] for s in stats)/1e9,'lifetime_peak_gb':max(lifetime)/1e9,'read_gb':[s['prefillReadBytes']/1e9 for s in stats],'groups':[s['prefillPasses'] for s in stats],'thermal_states':[[s.get('generatorSystemBefore'),s.get('generatorSystemAfter')] for s in stats]}
  result.append({'case':root.name,'target_gb':p['memory_gb'],'mtp':p['mtp'],'arms':arms,'functional_pairs':pairs,'recorded_cells':len(rows),'planned_cells':len(p['arms'])*p['rounds'],'completion_record':(root/'completion.json').exists(),'arithmetic_scope':'Same-backend workspace/cache-only comparisons require exact outputs; backend and fusion changes have independent numerical/task qualification, not an unconditional cross-backend bit-equality requirement.'})
 (R/'functional-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
 for row in result:
  print(json.dumps({'case':row['case'],'recorded_cells':row['recorded_cells'],'planned_cells':row['planned_cells'],'completed_pairs':len(row['functional_pairs']),'output_changes':sum(not p['output_ids_equal'] for p in row['functional_pairs']),'peak_gb':max([a['lifetime_peak_gb'] for a in row['arms'].values()],default=0)}))
if __name__=='__main__':main()
