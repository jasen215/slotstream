from pathlib import Path
import json,hashlib,datetime,copy
R=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();cases=[]
def add(name,base,rounds,seconds,purpose,transform=None):
 p=json.loads((R/'protocols'/f'{base}.json').read_text());p['rounds']=rounds;p['thermal_settle_seconds']=seconds;p['thermal_probe_sha256']=sha(R/'thermal-probe')
 if transform:transform(p)
 path=R/'protocols'/f'{name}.json';path.write_text(json.dumps(p,indent=2)+'\n');cases.append({'name':name,'protocol_sha256':sha(path),'purpose':purpose})
add('settled_default_prose_2k','default_prose_2k',3,30,'Short document confirmation under ordinary release defaults')
add('settled_ablation_code_8k','default_ablation_code_8k',3,120,'Three-arm same-backend first-request fusion/workspace attribution')
def scope_control(p):
 new=p['binary'];p['arms']={'reference':{'binary':new,'chunk':256,'env':{'SLOTSTREAM_OPT_FUSED_WORKSPACE':'0'}},'released':{'binary':new,'chunk':256,'env':{}}}
add('settled_structured_16k_mtp','default_structured_16k_mtp',3,120,'Same-backend automatic workspace/grouping causal confirmation, real structured records, MTP on',scope_control)
add('screen_floor_prose_8k','default_prose_8k_8g',1,120,'Prospective one-pair lower-memory boundary screen; no qualified percentage')
add('screen_code_24k_mtp','default_code_24k_mtp',1,120,'Prospective one-pair beyond16K boundary screen; no qualified percentage')
for name in ['prefix_prose_off','prefix_code_on','short_setup_attribution']:
 add('settled_'+name,name,3,30,'Separate cache-followup or cold/warm setup confirmation')
(R/'settled-study.json').write_text(json.dumps({'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Preserve interrupted continuous screen and all exclusions. Separate bounded confirmation with measured prelaunch settling; no replacement rounds.','thermal_gate':'120 continuous nominal normal-power seconds before each long workload cell;30 before short/cache cells. Native generator before/after still must be nominal and no global paging.','other_gates':'Original memory, input, output, MTP and exact-work criteria remain; at least3clean pairs for a qualified repeated median. Boundary screens are1pair and explicitly preliminary.','wrapper_sha256':sha(R/'settled_driver.py'),'default_harness_sha256':sha(R/'default_requests.py'),'probe_sha256':sha(R/'thermal-probe'),'cases':cases},indent=2)+'\n')
p=R/'run_final.py';s=p.read_text().replace("(R/'final-study.json')","(R/'settled-study.json')").replace("harness=R/'default_requests.py' if case['harness']=='default_requests.py' else S/'Tools/serve_bench.py'","harness=R/'settled_driver.py'").replace("R/'final-progress.json'","R/'settled-progress.json'").replace('FINAL_STUDY_COMPLETE','SETTLED_STUDY_COMPLETE')
(R/'run_settled.py').write_text(s)
print(json.dumps(cases,indent=2))
