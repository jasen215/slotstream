"""Bounded installed-release memory/disk follow-up diagnostic; no timing promotion."""
from pathlib import Path
import sys, json, hashlib, os, socket, subprocess, time, fcntl
R = Path(__file__).resolve().parent
sys.path.insert(0, '/tmp/slotstream-release-0.2.23-20260922/source/Tools')
import serve_bench as s
from prefill_bench import vm_snapshot, model_identity

def main():
    p = json.loads((R/'long-prefix-protocol.json').read_text())
    out = R/'long-prefix-diagnostic'
    out.mkdir(exist_ok=False)
    build = s.verified_build(p['binary'])
    fixtures = []
    for key in ['fixture', 'followup_fixture']:
        f = Path(p[key])
        assert s.digest(f) == p[key+'_sha256']
        fixtures.append(f.read_text())
    probe = R/'thermal-probe'
    assert s.digest(probe) == p['thermal_probe_sha256']
    manifest = {'protocol':p, 'protocol_sha256':s.digest(R/'long-prefix-protocol.json'),
                'build':build, 'script_sha256':s.digest(Path(__file__)),
                'model':model_identity(Path(p['model']))}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    need = s.measurement_memory(p)
    clean = {k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_', 'SS_DEBUG'))}
    arms = {}
    for arm in p['arms']:
        cell = out/arm; cell.mkdir()
        child = None; rows = []
        try:
            assert not s.competing_jobs(), 'competing storage/build job'
            start = time.monotonic(); stable = None; samples = []
            with open(f'/tmp/slotstream-model-{os.getuid()}.lock','a') as lock:
                while True:
                    try: fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB); break
                    except BlockingIOError:
                        if time.monotonic()-start > p['model_reservation_wait_seconds']:
                            raise TimeoutError('model reservation timeout')
                        time.sleep(2)
                acquired = time.monotonic(); announced = acquired-30
                while True:
                    now = time.monotonic()
                    value = subprocess.check_output([str(probe)],text=True,timeout=5).strip()
                    samples.append({'elapsed':now-acquired,'state':value})
                    if value == 'nominal false':
                        if stable is None: stable = now
                    else: stable = None
                    if now-announced >= 30:
                        print(json.dumps({'arm':arm,'phase':'thermal settling','seconds':round(now-acquired)}),flush=True)
                        announced = now
                    if stable is not None and now-stable >= p['thermal_settle_seconds']: break
                    if now-acquired > 900: raise TimeoutError('thermal settling timeout')
                    time.sleep(2)
            (cell/'thermal.json').write_text(json.dumps(samples,indent=2)+'\n')
            before_startup, headroom = s.wait_for_headroom(need,p['memory_settle_seconds'])
            assert not s.competing_jobs(), 'competing storage/build job'
            with socket.socket() as sock:
                sock.bind(('127.0.0.1',0)); port = sock.getsockname()[1]
            command = [build['binary'],'serve','--model',p['model'],'--port',str(port),
                       '--memory-gb',str(p['memory_gb']),'--mtp',p['mtp'],'--no-elastic']
            if p['arms'][arm].get('persistent'):
                command += ['--prefix-cache-dir',str(cell/'prefix-cache'),'--prefix-cache-disk-gb','1']
            env = clean|{'SLOTSTREAM_BENCH_DETAILS':'1','SLOTSTREAM_PREFILL_CHUNK':'256'}
            (cell/'launch.json').write_text(json.dumps({'command':command,'before_startup':before_startup,'headroom':headroom},indent=2)+'\n')
            with (cell/'server.stdout').open('wb') as stdout, (cell/'server.stderr').open('wb') as stderr:
                child = subprocess.Popen(command,cwd=s.ROOT,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
                s.wait_ready(child,port)
                for index, prompt in enumerate(fixtures):
                    body = s.request_body(p,prompt)
                    (cell/f'{index}-request.json').write_bytes(body)
                    before = vm_snapshot()
                    measured, wire = s.exchange(port,body,p['timeout_seconds'])
                    after = vm_snapshot(); stats = measured['metrics']['stats']
                    reasons = s.resource_exclusions(stats,p)
                    if any(before[k] != after[k] or stats['generatorVMBefore'][k] != stats['generatorVMAfter'][k]
                           for k in ['swapins','swapouts']): reasons.append('swap activity')
                    if s.competing_jobs(): reasons.append('workspace contention')
                    measured.update(before=before,after=after,valid=not reasons,exclusions=reasons)
                    (cell/f'{index}-response.ndjson').write_bytes(wire)
                    (cell/f'{index}-result.json').write_text(json.dumps(measured,indent=2)+'\n')
                    rows.append(measured)
                    print(json.dumps({'arm':arm,'request':index,'seconds':measured['client_seconds'],
                        'reuse':stats['reusedPrefixTokens'],'stores':stats['prefixCheckpointStores'],
                        'refusals':stats['prefixCheckpointRefusals'],'valid':not reasons}),flush=True)
            arms[arm] = rows
        finally:
            if child is not None: s.stop_server(child)
    a,b = arms['memory'],arms['disk']
    checks = {'same_prompts':all(x['metrics']['prompt_ids']==y['metrics']['prompt_ids'] for x,y in zip(a,b)),
              'same_outputs':all(x['metrics']['output_ids']==y['metrics']['output_ids'] and x['text']==y['text'] for x,y in zip(a,b)),
              'fresh_first_requests':all(v[0]['metrics']['stats']['reusedPrefixTokens']==0 for v in arms.values()),
              'memory_followup_reuse':a[1]['metrics']['stats']['reusedPrefixTokens'],
              'disk_followup_reuse':b[1]['metrics']['stats']['reusedPrefixTokens'],
              'within_target':all(v['metrics']['stats']['peakMemoryGB']<=p['memory_gb'] for vs in arms.values() for v in vs),
              'sequence_client_seconds':{k:sum(x['client_seconds'] for x in v) for k,v in arms.items()},
              'scope':'One sequence per arm, functional diagnostic only; not repeated clean-host timing.'}
    (out/'completion.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(json.dumps(checks),flush=True)
    return 0 if all(checks[k] for k in ['same_prompts','same_outputs','fresh_first_requests','within_target']) else 1

if __name__=='__main__': raise SystemExit(main())
