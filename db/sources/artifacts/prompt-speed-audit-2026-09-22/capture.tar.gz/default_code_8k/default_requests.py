#!/usr/bin/env python3
"""Frozen release, first HTTP request with normal prefix-cache planning.
Reuses verified server transport, identity, headroom, and resource checks.
No warmup request; first-request latency includes lazy kernel initialization.
"""
from pathlib import Path
import sys,os,json,time,socket,subprocess,hashlib,shutil,argparse
sys.path.insert(0,'/tmp/slotstream-release-0.2.23-20260922/source/Tools')
import serve_bench as s
from prefill_bench import vm_snapshot,host_conditions,model_identity,digest

def main():
 a=argparse.ArgumentParser();a.add_argument('--protocol',type=Path,required=True);a.add_argument('--out',type=Path,required=True);a=a.parse_args()
 p=json.loads(a.protocol.read_text());s.validate_arms(p['arms']);need=s.measurement_memory(p)
 assert p['mode']=='first_request_prefix_enabled' and p['max_tokens']==1
 fixture=Path(p['fixture']);assert digest(fixture)==p['fixture_sha256']
 builds={n:s.verified_build(v['binary']) for n,v in p['arms'].items()}
 a.out.mkdir(parents=True,exist_ok=False)
 sources={}
 for f in [Path(__file__),Path(s.__file__),Path(s.__file__).with_name('prefill_bench.py')]:
  sources[f.name]=digest(f);shutil.copyfile(f,a.out/f.name)
 (a.out/'manifest.json').write_text(json.dumps({'protocol':p,'protocol_sha256':digest(a.protocol),'builds':builds,'harness_sources':sources,'model':model_identity(Path(p['model']))},indent=2)+'\n')
 shutil.copyfile(fixture,a.out/'fixture.txt');body=s.request_body(p,fixture.read_text());(a.out/'request.json').write_bytes(body)
 clean={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','SS_DEBUG'))}
 rows=[]
 for number in range(1,p['rounds']+1):
  order=list(p['arms']) if number%2 else list(reversed(p['arms']))
  for name in order:
   cell=a.out/f'{number}-{name}';cell.mkdir();row={'round':number,'arm':name,'valid':False};child=None
   try:
    if s.competing_jobs():raise RuntimeError('competing storage/build job')
    row['cooldown_reservation']=s.reserved_cooldown(p['between_cells_seconds'],p['model_reservation_wait_seconds'])
    row['before_startup'],row['headroom_settle']=s.wait_for_headroom(need,p['memory_settle_seconds'])
    if s.competing_jobs():raise RuntimeError('competing storage/build job')
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    arm=p['arms'][name];env=clean|arm['env']|{'SLOTSTREAM_BENCH_DETAILS':'1','SLOTSTREAM_PREFILL_CHUNK':str(arm['chunk'])}
    command=[builds[name]['binary'],'serve','--model',p['model'],'--port',str(port),'--memory-gb',str(p['memory_gb']),'--mtp',p['mtp'],'--no-elastic']
    row['command']=command;row['env']={k:v for k,v in env.items() if k.startswith('SLOTSTREAM_')}
    with (cell/'server.stdout').open('wb') as out,(cell/'server.stderr').open('wb') as err:
     launch=time.monotonic();child=subprocess.Popen(command,cwd=s.ROOT,env=env,stdout=out,stderr=err,start_new_session=True);s.wait_ready(child,port)
     row['startup_seconds']=time.monotonic()-launch;row['host_before']=host_conditions();row['before']=vm_snapshot()
     measured,wire=s.exchange(port,body,p['timeout_seconds']);row['after']=vm_snapshot();row['host_after']=host_conditions()
     row.update(measured);row['complete_seconds_from_launch']=time.monotonic()-launch
     (cell/'response.ndjson').write_bytes(wire);(cell/'warmup.json').write_text(json.dumps(measured,indent=2)+'\n')
     m=measured['metrics'];stats=m['stats'];reasons=s.resource_exclusions(stats,p)
     if stats['reusedPrefixTokens']!=0:reasons.append('fresh process unexpectedly reused prefix')
     if m['effective_mtp']!=(p['mtp']=='on') or m['effective_prefill_chunk']!=256:reasons.append('effective settings mismatch')
     if any(row['before'][k]!=row['after'][k] or stats['generatorVMBefore'][k]!=stats['generatorVMAfter'][k] for k in ['swapins','swapouts']):reasons.append('swap activity during request')
     if s.competing_jobs():reasons.append('competing storage/build job')
     row['valid']=not reasons
     if reasons:row['exclusion']='; '.join(reasons)
   except KeyboardInterrupt:raise
   except Exception as e:row['error']=f'{type(e).__name__}: {e}'
   finally:
    if child is not None:s.stop_server(child)
   (cell/'result.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row)
   with (a.out/'results.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   print(json.dumps({k:row[k] for k in ['round','arm','valid','client_seconds','error','exclusion'] if k in row}),flush=True)
 (a.out/'completion.json').write_text(json.dumps({'recorded_cells':len(rows),'planned_cells':p['rounds']*len(p['arms']),'valid_cells':sum(r['valid'] for r in rows)},indent=2)+'\n')
 return 0 if all(r['valid'] for r in rows) else 1
if __name__=='__main__':raise SystemExit(main())
