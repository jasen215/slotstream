"""Secondary check that cache savings survive charging both request latencies."""
from pathlib import Path
import json
from analyze import eligible,metric_summary
R=Path(__file__).resolve().parent
def main():
 report=[]
 for name in ['settled_prefix_prose_off','settled_prefix_code_on']:
  root=R/name;p=json.loads((R/'protocols'/f'{name}.json').read_text());pairs=[];excluded=[]
  for n in range(1,p['rounds']+1):
   arms={};reasons=[]
   for arm in ['reference','released']:
    cell=root/f'{n}-{arm}'
    if not all((cell/f).exists() for f in ['warmup.json','result.json']):
     reasons.append(arm+': incomplete');continue
    warm=json.loads((cell/'warmup.json').read_text());follow=json.loads((cell/'result.json').read_text())
    if not follow.get('valid'):reasons.append(arm+': followup ineligible')
    if not follow.get('startup_and_warmup_valid'):reasons.append(arm+': startup/warmup ineligible')
    reasons.extend(arm+': '+x for x in eligible(warm,p))
    reasons.extend(arm+': '+x for x in eligible(follow,p,follow if 'before' in follow else None))
    if any(follow.get('before_startup',{}).get(k)!=follow.get('after',{}).get(k) for k in ['swapins','swapouts']):
     reasons.append(arm+': full sequence paging')
    arms[arm]=(warm,follow)
   if not reasons:
    for a,b in zip(arms['reference'],arms['released']):
     if any(a['metrics'][key]!=b['metrics'][key] for key in ['prompt_ids','output_ids','effective_mtp','effective_pool_slots']) or a['text']!=b['text']:
      reasons.append('first or followup exact-work identity mismatch')
   if reasons:excluded.append({'round':n,'reasons':reasons});continue
   pairs.append({'round':n,**{label:{'client_sum_seconds':sum(x['client_seconds'] for x in arms[arm]),
                                  'first_request_seconds':arms[arm][0]['client_seconds'],
                                  'followup_seconds':arms[arm][1]['client_seconds']}
                              for label,arm in [('old','reference'),('new','released')]}})
  report.append({'case':name,'pairs':pairs,'excluded':excluded,'sum_of_request_latencies':metric_summary(pairs,'client_sum_seconds'),
                 'scope':'Secondary analysis. Sum of two HTTP request latencies after server readiness, excluding inter-request harness work. Full startup-through-followup VM gate. Exact output IDs/text on both requests. Not a complete-answer or app-turn result.'})
 (R/'sequence-analysis.json').write_text(json.dumps(report,indent=2)+'\n')
 for row in report:print(json.dumps({'case':row['case'],**row['sum_of_request_latencies']}))
if __name__=='__main__':main()
