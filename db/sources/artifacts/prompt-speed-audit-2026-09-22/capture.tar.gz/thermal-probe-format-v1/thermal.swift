import Foundation
print("\(String(describing: ProcessInfo.processInfo.thermalState)) \(ProcessInfo.processInfo.isLowPowerModeEnabled)")
