from pathlib import Path
from tokenizers import Tokenizer
import hashlib,json,datetime
R=Path('/tmp/slotstream-speed-audit-20260922'); S=Path('/tmp/slotstream-release-0.2.23-20260922/source')
M=Path.home()/'.slotstream/models/qwen38-flash-next-mlx-4bit'
T=Tokenizer.from_file(str(M/'tokenizer.json'))
old=str(Path.home()/'.slotstream/releases/6301b7e02749f3f5a040136da2b9de15e7a980075a2356c90b60936b45adf1b4-macos26/slotstream')
new=str(Path.home()/'.slotstream/releases/1b499652c33e2eb46af702c64b4ed26f62191b9538804567d057b8914f62ed22-macos26/slotstream')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
(R/'fixtures').mkdir(exist_ok=True); (R/'protocols').mkdir(exist_ok=True)
prose='\n\n'.join('DOCUMENT: '+str(p.relative_to(S))+'\n'+p.read_text() for p in [S/'README.md',*sorted((S/'docs').glob('*.md'))] if p.exists())
code='\n\n'.join('FILE: '+str(p.relative_to(S))+'\n'+p.read_text() for p in sorted((S/'Sources/Slotstream').glob('*.swift')))
structured='\n'.join(json.dumps({'job':i,'kind':['index','query','backup','reconcile'][i%4],'duration_ms':37+(i*73)%987,'attempts':1+(i%7==0),'state':['done','done','retry','done','blocked'][i%5],'dependency':max(0,i-3),'memory_mb':512+(i*131)%2048}) for i in range(1,1100))
def bounded(body,target,ask):
    head='Read the following material carefully.\n<material>\n'; tail='\n</material>\n'+ask
    n=target-len(T.encode(head+tail,add_special_tokens=False).ids)
    ids=T.encode(body,add_special_tokens=False).ids
    assert len(ids)>n,(len(ids),n)
    return head+T.decode(ids[:n],skip_special_tokens=False)+tail
cases=[
 ('short_decode_8g', 'Explain how a hash table resolves collisions. Give a detailed, concrete explanation with an example and discuss time complexity.',8.1,'off',192),
 ('prose_2k',bounded(prose,2048,'Summarize the main user-facing capabilities and operating limits in five concise bullets.'),10,'off',64),
 ('code_8k',bounded(code,8192,'Explain the main data structures and identify two potential performance bottlenecks, referring to the code shown.'),10,'off',64),
 ('prose_16k_mtp',bounded(prose,16384,'Summarize the architecture, memory limits, and user-facing tradeoffs in five concise bullets.'),10,'on',64),
 ('structured_16k_mtp',bounded(structured,16384,'Describe the job-state patterns in this log and give three concrete recommendations for monitoring failed work.'),10,'on',64),
 ('prose_8k_8g',bounded(prose,8192,'Summarize the key operating limits and explain what a new user should verify before starting.'),8.1,'off',64),
 ('code_24k_mtp',bounded(code,24576,'Explain the architecture shown, then identify three expensive operations and their purpose.'),10,'on',64)
]
manifest={'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Published v0.2.22 versus v0.2.23 multi-workload audit, prospectively frozen before timing','binary_hashes':{old:sha(old),new:sha(new)},'cases':[],'analysis_contract':{'rounds':3,'order':'AB,BA,AB within each workload; retain every cell','warmup':'Fresh server first request and repeated uncached warmed request measured separately; filesystem cache uncontrolled, no purge','timing_eligibility':'Both arms complete, exact input IDs and MTP, same total memory, no swap during interval, nominal thermal and normal power, footprint within target. Output differences are reported; prefill comparison does not require equal generated text. Exact-output subset required for end-to-end matched-work claims.','claim_threshold':'At least three eligible pairs per workload to report repeatable median; smaller samples descriptive only. Never compound gains. Decode rates require matching output IDs and decode work.','exclusion_policy':'No replacement rounds in the primary matrix. Preserve failures, paging and slow outliers. Followups separately preregistered.','scope':'One M5 Pro 48GB host, two small fixed total memory targets; excludes cold SSD and cross-hardware generalization.'}}
for name,prompt,mem,mtp,outputs in cases:
 f=R/'fixtures'/f'{name}.txt'; f.write_text(prompt)
 p={'model':str(M),'binary':new,'memory_gb':mem,'mtp':mtp,'raw':False,'think':False,'seed':7,'rounds':3,'max_tokens':outputs,'minimum_output_tokens':1,'comparison_basis':'fixed-total-memory','fixture':str(f),'fixture_sha256':sha(f),'maximum_sampled_footprint_bytes':int(mem*1e9),'require_nominal_power_state':True,'between_cells_seconds':20,'model_reservation_wait_seconds':1800,'stop_on_workspace_contention':True,'initial_workspace_quiet':{'stable_seconds':5,'maximum_wait_seconds':300},'memory_settle_seconds':30,'timeout_seconds':900,'arms':{'reference':{'binary':old,'chunk':256,'env':{}},'released':{'binary':new,'chunk':256,'env':{}}}}
 path=R/'protocols'/f'{name}.json';path.write_text(json.dumps(p,indent=2)+'\n')
 manifest['cases'].append({'name':name,'prompt_tokens_without_template':len(T.encode(prompt,add_special_tokens=False).ids),'protocol_sha256':sha(path),'fixture_sha256':sha(f),'memory_gb':mem,'mtp':mtp})
(R/'study.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
