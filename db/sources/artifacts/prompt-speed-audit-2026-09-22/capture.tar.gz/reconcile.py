"""Independent reconciliation of completed requests, including excluded timing."""
from pathlib import Path
import json
R=Path(__file__).resolve().parent
def main():
 rows=[]; failures=[]; incomplete=[]
 for root in sorted(R.iterdir()):
  if not root.is_dir() or not (root/'manifest.json').exists():continue
  manifest=json.loads((root/'manifest.json').read_text())
  if not isinstance(manifest,dict):continue
  p=manifest.get('protocol',{})
  if 'arms' not in p or 'reference' not in p['arms']:continue
  for cell in sorted(root.glob('*-*')):
   if not cell.is_dir():continue
   paths=[cell/'result.json']
   if p.get('mode')!='first_request_prefix_enabled':paths.insert(0,cell/'warmup.json')
   for path in paths:
    if not path.exists():
     incomplete.append(str(path.relative_to(R)));continue
    d=json.loads(path.read_text());m=d.get('metrics',{});s=m.get('stats',{})
    if not s:
     incomplete.append({'path':str(path.relative_to(R)),'error':d.get('error',d.get('exclusion'))});continue
    checks={
      'prompt_count':len(m['prompt_ids'])==s['promptTokens'],
      'prefill_count':sum(s['prefillComputePasses'])==s['prefillTokens'],
      'group_count':sum(s['prefillPasses'])==s['prefillTokens'],
      'reuse_count':s['reusedPrefixTokens']+s['prefillTokens']==s['promptTokens'],
      'declared_mtp':m['effective_mtp']==(p['mtp']=='on'),
      'actual_output':len(m['output_ids'])>0,
      'generation_completed':not s.get('runtimeError') and not s.get('memoryPressureCancelled'),
      'sampled_memory':s['sampledFootprint']['peakBytes']<=p['maximum_sampled_footprint_bytes'],
      'lifetime_memory':max(s['lifetimePhysicalFootprintPeakBytes'],s['lifetimeRSSPeakBytes'],s['physicalFootprintEndBytes'])<=p['maximum_sampled_footprint_bytes']}
    row={'path':str(path.relative_to(R)),'checks':checks,'prompt_tokens':s['promptTokens'],
         'output_tokens':len(m['output_ids']),'reused':s['reusedPrefixTokens'],
         'max_tokens':p['max_tokens'],'target_gb':p['memory_gb'],'mtp':p['mtp']}
    rows.append(row)
    if not all(checks.values()):failures.append(row)
 result={'completed_requests':len(rows),'checks_per_request':9,'passed_checks':sum(sum(x['checks'].values()) for x in rows),
         'failed_checks':sum(sum(not v for v in x['checks'].values()) for x in rows),
         'rows':rows,'failures':failures,'incomplete_or_missing':incomplete,
         'scope':'Reconciliation of emitted runtime/HTTP metrics, not new raw-logit or model-quality tests. Timing exclusions remain separate.'}
 (R/'reconciliation.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k not in ['rows']}))
 return bool(failures)
if __name__=='__main__':raise SystemExit(main())
