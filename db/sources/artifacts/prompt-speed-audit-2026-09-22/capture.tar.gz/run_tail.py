from pathlib import Path
import json,sys,subprocess,signal,os,hashlib
R=Path(__file__).resolve().parent;results=[]
p=json.loads((R/'long-prefix-protocol.json').read_text())
assert hashlib.sha256((R/'long_prefix_diagnostic.py').read_bytes()).hexdigest()==p['script_sha256']
p=json.loads((R/'protocols/screen_planned_24g_code_8k.json').read_text())
assert hashlib.sha256((R/'planned_profile_screen.py').read_bytes()).hexdigest()==p['harness_sha256']
assert hashlib.sha256((R/'planned_profile_driver.py').read_bytes()).hexdigest()==p['driver_sha256']
jobs=[('long-prefix-diagnostic',[sys.executable,str(R/'long_prefix_diagnostic.py')]),
      ('screen_planned_24g_code_8k',[sys.executable,str(R/'planned_profile_driver.py'),'--protocol',str(R/'protocols/screen_planned_24g_code_8k.json'),'--out',str(R/'screen_planned_24g_code_8k')])]
for name,command in jobs:
 print(json.dumps({'study':name,'phase':'start'}),flush=True)
 with (R/f'{name}.driver.log').open('w') as log:
  child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
  try:
   for line in child.stdout:log.write(line);log.flush();print(line,end='',flush=True)
   code=child.wait()
  finally:
   if child.poll() is None:
    os.killpg(child.pid,signal.SIGINT)
    try:child.wait(timeout=20)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGTERM);child.wait()
 results.append({'study':name,'exit':code});(R/'tail-progress.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(results[-1]),flush=True)
 if code not in [0,1]:raise RuntimeError('unexpected harness failure')
print('TAIL_COMPLETE',flush=True)
