from pathlib import Path
import json,hashlib,tarfile
r=Path(__file__).parent
results=[]
for receipt in sorted(r.glob('*/receipt.json')):
 item=json.loads(receipt.read_text());row={'name':receipt.parent.name,'exit':item['exit'],'seconds':item['seconds']}
 path=receipt.parent/'stdout.txt'
 try:
  d=json.loads(path.read_text())
  if isinstance(d,dict):
   row.update({k:d[k] for k in ['passed','measurements'] if k in d})
   row['assertions']=d.get('items',[])
 except (ValueError,OSError):pass
 results.append(row)
for name,limit in [('floor81',8.1),('fusion-disabled',10)]:
 path=r/name/'metrics.json'
 if path.exists():
  d=json.loads(path.read_text());s=d['stats']
  checks={'complete':s['prefillTokens']==len(d['prompt_ids']),'success':s.get('runtimeError') is None,'physical':s['peakMemoryGB']<=limit}
  results.append({'name':name+'-metrics','checks':checks,'passed':all(checks.values()),'peak_gb':s['peakMemoryGB'],'prefill_seconds':s['prefillSeconds'],'read_groups':s['prefillPasses'],'reads':s['prefillReadBytes'],'pool':d['effective_pool_slots']})
(r/'functional-summary.json').write_text(json.dumps(results,indent=2)+'\n')
with tarfile.open(r/'candidate/build-source.tar.gz') as t:
 verification=[]
 for m in t.getmembers():
  if not m.isfile():continue
  p=Path('/Users/carlos/Projects/slotstream')/m.name
  verification.append({'path':m.name,'matches':p.exists() and hashlib.sha256(p.read_bytes()).digest()==hashlib.sha256(t.extractfile(m).read()).digest()})
(r/'current-source-verified.json').write_text(json.dumps(verification,indent=2)+'\n')
print('source identity:',len(verification),'files',all(x['matches'] for x in verification))
for row in results:
 print(row['name'],row.get('exit'),row.get('passed'),len(row.get('assertions',[])))
