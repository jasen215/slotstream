from pathlib import Path
import json,subprocess
r=Path(__file__).parent;repo=Path('/Users/carlos/Projects/slotstream');db=repo/'db'
assert (db/'sources/artifacts/automatic-prefill-policy-2026-09-21/capture.tar.gz').exists()
checks={x['name']:x for x in json.loads((r/'functional-summary.json').read_text())}
for name in ['catalogue-final','equality16','lifecycle','checkpoint','mtp-equality','mtp-vision','floor81','fusion-disabled','app','static']:
 assert checks[name]['exit']==0,name
for name in ['equality16','lifecycle','checkpoint','mtp-equality','mtp-vision','floor81-metrics','fusion-disabled-metrics']:
 assert checks[name]['passed'],name
sha=json.loads((r/'candidate/build-identity.json').read_text())['binary_sha256']
analysis=json.loads((r/'analysis.json').read_text())
assert not analysis['qualified'] and analysis['eligible_pairs']==0
prefix='sources/runs/2026/09/2026-09-21-automatic-prefill-policy-'
measurement='records/measurements/automatic-prefill-policy-2026-09-21'
decision='records/decisions/automatic-prefill-read-policy'
drafts=r/'record-drafts';drafts.mkdir(exist_ok=True)
def write(path,kind,title,body,**fields):
 p=drafts/(Path(path).stem+'.md');p.write_text(body+'\n')
 cmd=['dbmd','write','--dir',str(db),'--type',kind,path+'.md','--summary',title,'--fm','title='+title,'--body-file',str(p),'--json']
 for k,v in fields.items():cmd+=['--fm',k+'='+str(v)]
 out=subprocess.run(cmd,text=True,capture_output=True,check=True);print(out.stdout,flush=True)
 target=db/(path+'.md')
 if not target.exists():
  matches=list(db.rglob(target.name));assert len(matches)==1,matches
  subprocess.run(['dbmd','rename',str(matches[0].relative_to(db)),str(target.relative_to(db)),'--dir',str(db),'--json'],check=True)
def run(suffix,title,body,discarded=False):
 links='[Raw capture](../../../artifacts/automatic-prefill-policy-2026-09-21/capture.tar.gz) and [member hashes](../../../artifacts/automatic-prefill-policy-2026-09-21/manifest.json).'
 write(prefix+suffix,'run',title,links+'\n\n'+body,tool='Frozen Swift model checks and paired benchmark',command='run_qualification.py; run_remaining.py; run_step.py; analyze.py; summarize.py',binary=sha,machines='[[records/machines/macbook-pro-m5-pro-48gb]]',captured_at='2026-09-21',discarded=str(discarded).lower())
rows=[]
for rd in [1,2,3]:
 a=next(x for x in analysis['cells'] if x['round']==rd and x['arm']=='baseline')
 b=next(x for x in analysis['cells'] if x['round']==rd and x['arm']=='automatic')
 rows.append(f"| {rd} | {a['seconds']:.3f} | {b['seconds']:.3f} | Excluded: paging |")
table='| Round | Previous default prefill seconds | Automatic policy prefill seconds | Timing eligibility |\n| --- | ---: | ---: | --- |\n'+'\n'.join(rows)
performance=f'''The new default is compared with the prior final verified build, with no optimization environment variables in either arm. The explicit fixture controls are the same: inventory16387, 10 GB, compute256, MTP off, greedy one-token output, sampled footprint and fresh processes. Effective pool is 961. Filesystem cache is uncontrolled; all binary, shader, source, fixture and model-header identities are preserved. Candidate binary: {sha}. Baseline binary: 686a6955f614c397087ac0473ced5d2a5373065133d3f2d0fc2d160a5209a297.

The frozen protocol requires three clean matched pairs, with three initial rounds and at most two optional extensions. Every timed cell waits for 120 consecutive nominal, normal-power seconds. Timing eligibility still requires no global paging, nominal thermal at both ends, identical inputs/output IDs/pool/compute, and physical peak at or below the declared target. All six initial processes complete. Every pair is excluded because at least one cell has paging. Two baseline cells are individually eligible, but none forms a matched eligible pair.

{table}

The original protocol and analysis script are preserved. After paging made all three initial pairs ineligible, a documented early failure stop was added: even two clean extensions could not reach three qualifying pairs. The current third pair was completed; no extension model was launched. The analyzer emits futility-stop.json and exit10, which stops the first driver. run_remaining.py then completes the prespecified smaller-prompt screen and functional checks. No timing threshold is relaxed, no old study is pooled, and this is a failed performance qualification, not a passed promotion gate.

Every primary candidate requests 355763404800 expert bytes versus 1239147417600 in the prior default. These are application-requested bytes, not measured SSD traffic. The first group is 14336 versus 8192 tokens, while all chronological compute passes and output IDs match. Candidate physical peak is at most 8.617757888 GB. The smaller inventory8195 screen has nominal thermal state and no paging in both cells. Prefill is 30.058812041 seconds for the baseline and 29.522505541 for automatic; both select [8192, 3] and request 60167577600 expert bytes. Candidate peak is 8.195935376 GB. One pair cannot establish repeatability or a speed gain. Full receipts are preserved separately. The previous study's one clean 41.67% reduction remains preliminary and is not a new measurement of this default.'''
run('timing','Automatic prefill policy: timing exclusions and failed qualification',performance,True)
counts=', '.join(f"{name}: {len(checks[name]['assertions'])}" for name in ['equality16','lifecycle','checkpoint','mtp-equality','mtp-vision'])
correctness=f'''All final checks run without optimization environment flags. The catalogue passes 73 groups and 31816 assertions. Explicit real-model assertion counts are {counts}. The 16387-token state test exercises the complete 16384-token read envelope at a floor-sized pool and proves exact logits, every retained state byte, teacher-forced continuation, output IDs and chronological passes. Its complete process peak, including fingerprinting and continuation, is {checks['equality16']['measurements']['complete_diagnostic_peak_gb']:.9f} GB. Allocation history differs between its sequential arms, so it is not a speed comparison.

Lifecycle tests exercise cancellation, partial-scope rollback, I/O failure, memory refusal, checkpoint splits and smaller-scope fallback. The existing lifecycle fixture explicitly tests legacy hand-seeded checkpoint semantics; the separate deployed checkpoint test retains aligned resume, warm/cold equality, disk reopen and arithmetic-identity refusal. MTP and image tests retain their original reservation and group policy under the new default. No golden or tolerance is changed.

The catalogue's first attempt reported two failures for requested 64/128-row passes: the pure policy advertised a larger cap because the underlying scheduling helper clamps them to 256. The actual automatic dispatcher already refuses those requested shapes. PrefillReadPolicy now checks the requested range before advertising an expanded cap; the complete catalogue rerun passes. candidate-v1, the failed output and the final source comparison remain preserved. Source changes from the previous build are limited to the coupled policy/default, its generator wiring, comments and diagnostics.

The ordinary CLI completes the 8195-token prompt at 8.1 GB and with fusion disabled at 10 GB. Their actual process peaks and output identities are in functional-summary.json and raw metrics. Full paired-input/output/compute/pool equality is checked even for timing-excluded cells in pair-correctness.json. The complete Mac build/scripted suites and static/planner/installer gates pass. Final brain/projection checks are preserved beside the immutable archive after record registration. This is a local, unreleased source/build change; no commit, push or installation is performed.'''
run('correctness','Automatic prefill policy: default behavior and integration checks',correctness)
body=f'''The engine now selects the combined fused-workspace and expert-read policy automatically on the existing qualified M5 Pro profile. Carlos explicitly requested automatic behavior instead of user opt-in after being told the speed result lacked three clean pairs. This is a bounded product adoption supported by exact-state, lifecycle, memory and integration checks. It is **not a claim that the frozen performance-adoption criterion passed**: the new study has zero eligible matched pairs, and the earlier 41.67% result remains one preliminary pair.

## Automatic behavior

Deployment enables fused workspace accounting alongside the already qualified fused kernel. One internal PrefillReadPolicy checks the actual GPU/NAX capability, BF16 weights, attention geometry, MTP/image mode and attention fallbacks. Its default larger read envelope applies only to 256-query computation and ends within 16384 keys. At later positions, on other compute shapes, or when the attention path cannot use the reservation, the established automatic cap remains. Each candidate still passes the same physical-footprint, live-headroom and request-ownership admission. A larger maximum never grants memory, changes compute rows or bypasses a checkpoint.

The Mac app, CLI and serving adapters inherit this through the shared engine. There is no new UI control or startup tuning benchmark. Explicit reference configurations and older serialized settings keep original reservations. SLOTSTREAM_OPT_FUSED_WORKSPACE=0 restores original accounting and automatic cap; disabling forced fusion also disables the combined automatic path. Independent read-cap overrides remain diagnostic tools, not a setup requirement. MTP, images, CPU and unqualified hardware retain their existing automatic policy.

## Evidence and limits

{table}

These raw times are excluded from a qualified speed estimate. All primary default runs request 355.763 GB of expert data versus 1239.147 GB, with the same output IDs and compute schedule; requested bytes are not physical SSD bytes. All complete below 10 GB. The study stops after the three initial pairs because both allowed extensions could yield at most two eligible pairs. The original protocol, initial analyzer, explicit early-failure rationale, all cells and the controlled driver exit are preserved. No further extension or cross-study pooling earns a passed result.

The full 16K state comparison, default catalogue, lifecycle, aligned checkpoint/disk, MTP/image, 8.1 GB boundary and fusion-disabled checks pass. Mac and static suites pass. See the raw correctness run for exact counts, peaks and the small-pass boundary correction discovered by the first catalogue attempt. Broader hardware, larger contexts and MTP workspace reductions remain unqualified; the guarded default falls back there. A reproducible performance regression should revise the policy, and a reliable speed percentage still requires a new independently frozen clean-host study.

Decision: [[{decision}]]. Previous experiment and exclusions: [[records/measurements/prefill-opportunities-2026-09-21]]. Raw evidence: [[{prefix}timing]], [[{prefix}correctness]].'''
write(measurement,'measurement','Automatic prefill policy: validation and bounded adoption',body,doc='measurements',order='1614',level='2',date='2026-09-21',status='measured',machines='[[records/machines/macbook-pro-m5-pro-48gb]]',runs='[['+prefix+'timing]], [['+prefix+'correctness]]')
write(decision,'decision','Apply supported prefill improvements automatically',f'''At Carlos's explicit direction, make the supported combined prefill optimization an internal engine policy rather than user opt-in. The prior explanation had already stated that only one timing pair was clean and three were required for performance qualification. His follow-up requests automatic behavior where it helps and a simpler user experience. Adopt the bounded policy after the functional, physical-memory and integration gates in [[{measurement}]].

This explicitly reverses [[records/decisions/prefill-opportunities-remain-experimental]] as a product-default decision. The new timing study fails its frozen performance-adoption criterion; it is not promoted or relabeled successful. The default is adopted on exactness/memory evidence, the previous clean directional observation and consistent read reduction, with the performance uncertainty retained. No new qualified percentage or general hardware-speed claim is published.

Couple larger automatic read groups to valid fused workspace accounting. Keep chronological math, actual memory admission, checkpoints, cancellation and the existing fallback. Retain internal diagnostic overrides and the explicit reference API, but require no user setting in ordinary app/CLI/server usage. Wider hardware, context, MTP and image activation needs its own evidence.''',decided_on='2026-09-21',status='standing',evidence='[['+measurement+']]',reversible_if='A reproduced state, cache or physical-memory failure, or clean paired performance regression, narrows or removes the automatic policy; broader profiles require separate evidence.')
def prepend(path,text):
 p=db/path;body=p.read_text().split('\n---\n',1)[1]
 draft=drafts/('updated-'+p.name);draft.write_text(text+'\n\n'+body)
 subprocess.run(['dbmd','body','set',str(p),'--body-file',str(draft),'--json'],check=True)
prepend('records/measurements/prefill-opportunities-2026-09-21.md',
 'Historical experiment and original verdict, preserved unchanged below. The later user-directed automatic policy is recorded in [['+measurement+']] and [['+decision+']]; its adoption does not upgrade this preliminary speed result.')
old='records/decisions/prefill-opportunities-remain-experimental.md'
subprocess.run(['dbmd','fm','set',str(db/old),'status=reversed','--json'],check=True)
prepend(old,'Reversed as a product-default decision by [['+decision+']] at Carlos\'s explicit direction. The new timing study also fails its frozen speed gate; all original evidence and thresholds below remain historical facts. Functional and memory validation support the bounded automatic adoption, without a new qualified speed claim.')
prepend('records/decisions/qualified-upstream-fused-prefill.md',
 'Follow-up: fused-workspace accounting and larger expert reads now form the guarded automatic policy in [['+decision+']]. The kernel qualification and measured gain below remain unchanged; larger compute passes and sparse alternatives remain unadopted.')

(r/'pending-record-updates.json').write_text(json.dumps({'decision':decision,'measurement':measurement},indent=2)+'\n')
