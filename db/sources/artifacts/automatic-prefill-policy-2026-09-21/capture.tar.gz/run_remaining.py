from pathlib import Path
import sys,subprocess,json
r=Path(__file__).parent;c=r/'candidate'
def step(name,args,env={}):
 print('START',name,flush=True)
 code=subprocess.call([sys.executable,str(r/'run_step.py'),name,json.dumps(env)]+args)
 print('END',name,code,flush=True)
 if code:raise SystemExit(code)
def check(name,variant,extra=[]):
 step(name,[str(c/'slotstream'),'optimization-state-check','--variant',variant,'--json']+extra)
base='/tmp/slotstream-prefill-followup-20260921/candidate-verified/slotstream'
def bench(name,rounds,reverse=False,prompt='inventory16387'):
 arms=['baseline='+base,'automatic='+str(c/'slotstream')]
 if reverse:arms.reverse()
 cmd=[sys.executable,str(r/'settled_bench.py')]
 for arm in arms:cmd+=['--arm',arm]
 cmd+=['--prompts',prompt,'--rounds',str(rounds),'--chunks','256','--memory-gb','10','--max-tokens','1','--sample-footprint','--out',str(r/name)]
 print('START',name,flush=True)
 code=subprocess.call(cmd)
 print('END',name,code,flush=True)
 # Paging exclusions return 1. Inspect all cells; missing runs stop the study.
 if not (r/name/'results.jsonl').exists() or len((r/name/'results.jsonl').read_text().splitlines())!=2*rounds:raise SystemExit('incomplete benchmark study')
bench('screen8',1,prompt='inventory8195')
for name,variant,extra in [('lifecycle','prefill-followup-lifecycle',[]),('checkpoint','prefill-followup-checkpoint',[]),('mtp-equality','prefill-followup-mtp-equality',['--tokens','8195']),('mtp-vision','prefill-followup-mtp-vision',[])]:check(name,variant,extra)
for name,budget,env in [('floor81',8.1,{}),('fusion-disabled',10,{'SLOTSTREAM_OPT_FUSED_PREFILL':'0'})]:
 step(name,[str(c/'slotstream'),'run','--raw','--prompt-file',str(r/'fixtures/inventory8195.txt'),'--memory-gb',str(budget),'--mtp','off','--greedy','--max-tokens','1','--sample-footprint','--stats-json',str(r/name/'metrics.json')],env|{'SLOTSTREAM_PREFILL_CHUNK':'256'})
step('app',['bash','Tools/check_sevra_mac.sh'])
print('QUALIFICATION FINISHED',flush=True)
