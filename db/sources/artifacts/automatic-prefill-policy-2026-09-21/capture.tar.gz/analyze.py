from pathlib import Path
import json,statistics
r=Path(__file__).parent
pairs=[];excluded=[];cells=[]
for study in ['primary','extension']:
 p=r/study/'results.jsonl'
 if not p.exists():continue
 rows=[json.loads(x) for x in p.read_text().splitlines()]
 for row in rows:
  reasons=[];m=row.get('metrics',{});s=m.get('stats',{})
  if not row['valid']:reasons.append(row.get('exclusion','invalid'))
  for k in ['generatorSystemBefore','generatorSystemAfter']:
   if s.get(k)!={'thermalState':'nominal','lowPowerModeEnabled':False}:reasons.append(k)
  for k in ['host_before','host_after']:
   if row.get(k,{}).get('instantaneous_thermal')!='nominal false':reasons.append(k)
  if not 0<s.get('peakMemoryGB',0)<=10:reasons.append('physical footprint')
  row['eligible']=not reasons;row['reasons']=reasons
  cells.append({'study':study,'round':row['round'],'arm':row['arm'],'eligible':row['eligible'],'reasons':reasons,'seconds':s.get('prefillSeconds'),'reads':s.get('prefillReadBytes'),'peak_gb':s.get('peakMemoryGB')})
 for round in sorted({x['round'] for x in rows}):
  arms={x['arm']:x for x in rows if x['round']==round}
  a,b=arms.get('baseline'),arms.get('automatic')
  reasons=[]
  if a is None or b is None:reasons.append('missing cell')
  elif not a['eligible'] or not b['eligible']:reasons.append({k:v['reasons'] for k,v in arms.items()})
  else:
   x,y=a['metrics'],b['metrics']
   for k in ['prompt_ids','output_ids','effective_pool_slots','effective_mtp','effective_prefill_chunk']:
    if x[k]!=y[k]:reasons.append(k+' mismatch')
   if x['stats']['prefillComputePasses']!=y['stats']['prefillComputePasses']:reasons.append('compute schedule mismatch')
  if reasons:excluded.append({'study':study,'round':round,'reasons':reasons});continue
  sa,sb=a['metrics']['stats'],b['metrics']['stats']
  pairs.append({'study':study,'round':round,'baseline_seconds':sa['prefillSeconds'],'automatic_seconds':sb['prefillSeconds'],'reduction':1-sb['prefillSeconds']/sa['prefillSeconds'],'saved_seconds':sa['prefillSeconds']-sb['prefillSeconds'],'baseline_reads':sa['prefillReadBytes'],'automatic_reads':sb['prefillReadBytes'],'peak_gb':sb['peakMemoryGB'],'read_groups':sb['prefillPasses']})
median=statistics.median(x['reduction'] for x in pairs) if pairs else None
result={'eligible_pairs':len(pairs),'median_reduction':median,'qualified':len(pairs)>=3 and median>=.05 and all(p['reduction']>=-.05 for p in pairs),'pairs':pairs,'excluded':excluded,'cells':cells}
(r/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

# Stop after the initial study when even every allowed extension would leave
# fewer than three eligible pairs. This cannot turn a failing study into a pass.
if len(cells)==6 and not (r/'extension/results.jsonl').exists() and len(pairs)+2<3:
 (r/'futility-stop.json').write_text(json.dumps({'reason':'Even two eligible extension pairs cannot reach the frozen minimum of three.','eligible_pairs':len(pairs),'maximum_possible_pairs':len(pairs)+2,'performance_qualified':False},indent=2)+'\n')
 raise SystemExit(10)
