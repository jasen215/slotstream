from pathlib import Path
import json,tarfile,hashlib,subprocess,shutil,re
r=Path(__file__).parent;repo=Path('/Users/carlos/Projects/slotstream')
subprocess.run(['python3',str(r/'summarize.py')],check=True)
rows=[]
for study in ['primary','screen8']:
 source=r/study/'results.jsonl'
 if not source.exists():continue
 cells=[json.loads(line) for line in source.read_text().splitlines()]
 for round in sorted({c['round'] for c in cells}):
  arms={c['arm']:c for c in cells if c['round']==round};a,b=arms['baseline']['metrics'],arms['automatic']['metrics']
  checks={k:a[k]==b[k] for k in ['prompt_ids','output_ids','effective_pool_slots','effective_mtp','effective_prefill_chunk']}
  checks['compute_passes']=a['stats']['prefillComputePasses']==b['stats']['prefillComputePasses']
  checks['physical_peaks']=all(0<c['metrics']['stats']['peakMemoryGB']<=10 for c in arms.values())
  rows.append({'study':study,'round':round,'checks':checks,'passed':all(checks.values())})
(r/'pair-correctness.json').write_text(json.dumps(rows,indent=2)+'\n')
assert all(x['passed'] for x in rows)
assert all(x['matches'] for x in json.loads((r/'current-source-verified.json').read_text()))
# Include only scripted synthetic UI snapshots named by this run's app suite.
app=r/'app/stdout.txt'
if app.exists():
 snapshots=r/'app-screenshots';snapshots.mkdir(exist_ok=True)
 for line in app.read_text().splitlines():
  if line.startswith(('SNAPSHOT: ', 'SNAPSHOT ')):
   p=Path(line.split(' ',1)[1].strip())
   if p.is_file():shutil.copy2(p,snapshots/(p.parent.name+'-'+p.name))
dest=repo/'db/sources/artifacts/automatic-prefill-policy-2026-09-21'
assert not dest.exists(),'append-only evidence'
dest.mkdir(parents=True);selected=[];omitted=[]
for p in sorted(r.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(r)
 if '__pycache__' in rel.parts or 'Home' in rel.parts:continue
 reason=None
 if p.name in ['slotstream','slotstream-checks','thermal'] or p.suffix=='.metallib':reason='Executable or Metal payload retained locally; archived source and build identity identify exact bytes.'
 item={'path':str(rel),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 (omitted if reason else selected).append(item|({'reason':reason} if reason else {}))
with tarfile.open(dest/'capture.tar.gz','w:gz') as t:
 for item in selected:t.add(r/item['path'],arcname=item['path'],recursive=False)
with tarfile.open(dest/'capture.tar.gz') as t:
 actual={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers() if m.isfile()}
assert actual=={i['path']:i['sha256'] for i in selected}
manifest={'files':selected,'omitted':omitted,'archive_sha256':hashlib.sha256((dest/'capture.tar.gz').read_bytes()).hexdigest()}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(selected),'bytes':(dest/'capture.tar.gz').stat().st_size,'sha256':manifest['archive_sha256']}))
