import hashlib,json,os,pathlib,shutil,subprocess,time,sys
base=pathlib.Path(__file__).resolve().parent; root=base/'checkout'; out=base/'qualification';out.mkdir(exist_ok=False)
repo='carloslfu/slotstream';run='35819111606';started=time.time();receipt={'started':started,'ci_run':run,'passed':False}
def step(label,cmd,timeout=3600,env=None):
 print(label,flush=True);t=time.monotonic()
 with (out/(label+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=timeout,env=env)
 receipt.setdefault('steps',[]).append({'label':label,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-t});(out/'receipt.json').write_text(json.dumps(receipt,indent=2))
 if r.returncode:raise RuntimeError(label+' failed: '+str(r.returncode))
try:
 for i in range(40):
  artifacts=json.loads(subprocess.check_output(['gh','api',f'repos/{repo}/actions/runs/{run}/artifacts']))
  if any(x['name']=='slotstream-ci-candidate' for x in artifacts['artifacts']):break
  print('Awaiting the CI candidate archive',i,flush=True);time.sleep(45)
 else:raise TimeoutError('CI candidate did not become available')
 step('download',['gh','run','download',run,'--repo',repo,'--name','slotstream-ci-candidate','--dir',str(base/'ci')],300)
 step('verify-archive',['python3','Tools/release_candidate.py','--archive',str(base/'ci/slotstream-arm64.tar.gz'),'--output',str(base/'candidate')],300)
 identity=json.loads((base/'candidate/build-identity.json').read_text());mismatch=[p for p,h in identity['source'].items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h]
 assert not mismatch,mismatch;receipt['source_inputs_matched']=len(identity['source']);receipt['build_identity']=identity
 sys.path.insert(0,str(root/'Tools'));from prefill_bench import preflight
 receipt['preflight']=preflight(20.5)
 env={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','SS_DEBUG'))};env.update(SLOTSTREAM_TEST_BINARY=str(base/'candidate/slotstream'),SLOTSTREAM_VERIFY_OUT=str(out/'native'))
 # Full original battery, preserving per-gate output in its output directory.
 step('native-full',['bash','Tools/verify.sh'],18000,env)
 receipt['passed']=True
except Exception as e:
 receipt['error']=str(e);print('QUALIFICATION ERROR',e,flush=True)
finally:
 receipt['finished']=time.time()
 capture=out/'temporary-gate-output';capture.mkdir(exist_ok=True)
 for p in pathlib.Path('/tmp').glob('ssv*'):
  if p.is_file() and not p.is_symlink() and p.stat().st_mtime>=started:shutil.copy2(p,capture/p.name)
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2));print('Qualification passed:',receipt['passed'],flush=True)
sys.exit(0 if receipt['passed'] else 1)
