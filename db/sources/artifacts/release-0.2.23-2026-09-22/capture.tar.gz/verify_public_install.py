import hashlib,json,os,subprocess,sys,time
from pathlib import Path
p=Path('/tmp/slotstream-release-0.2.23-20260922')
sys.path.insert(0,str(p/'source/Tools'))
from prefill_bench import run_child,digest
repo='carloslfu/slotstream'
env={k:v for k,v in os.environ.items() if not k.startswith('SLOTSTREAM_') and k not in ('BIN','MLX_METAL_PATH')}
def run(name,command,timeout=300):
 cell=p/name;cell.mkdir(exist_ok=False)
 receipt={'command':command,'started_unix':time.time()}
 try:receipt['exit_code']=run_child(command,env,cell,timeout)
 finally:
  receipt['finished_unix']=time.time();(cell/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(name,receipt['exit_code'],flush=True)
 if receipt['exit_code']:raise RuntimeError(name+' failed; inspect preserved outputs')
 return cell
meta=json.loads(subprocess.check_output(['gh','release','view','v0.2.23','--repo',repo,'--json','tagName,publishedAt,url,isDraft,isPrerelease,assets']))
assert meta['tagName']=='v0.2.23' and not meta['isDraft'] and not meta['isPrerelease']
(p/'published-release.json').write_text(json.dumps(meta,indent=2)+'\n')
run('public-download',['gh','release','download','v0.2.23','--repo',repo,'--pattern','slotstream-arm64.tar.gz*','--dir',str(p/'published')])
for name in ['slotstream-arm64.tar.gz','slotstream-arm64.tar.gz.sha256']:
 assert (p/'published'/name).read_bytes()==(p/'ci-download'/name).read_bytes(),name
run('public-archive-verification',['python3',str(p/'source/Tools/release_candidate.py'),'--archive',str(p/'published/slotstream-arm64.tar.gz'),'--output',str(p/'public-candidate')])
run('provenance',['gh','attestation','verify',str(p/'published/slotstream-arm64.tar.gz'),'--repo',repo])
assert (p/'public-install.sh').read_bytes()==(p/'source/install.sh').read_bytes()
run('public-install',['sh',str(p/'public-install.sh')])
installed=Path.home()/'.slotstream/bin'
identity=json.loads((p/'candidate/build-identity.json').read_text())
version=subprocess.check_output([str(installed/'slotstream'),'--version'],text=True).strip()
assert version=='0.2.23',version
for name,key in [('slotstream','binary_sha256'),('mlx.metallib','metallib_sha256'),('build-source.tar.gz','source_archive_sha256')]:assert digest(installed/name)==identity[key],name
receipt={'version':version,'binary_sha256':digest(installed/'slotstream'),'archive_sha256':digest(p/'published/slotstream-arm64.tar.gz'),'installed_directory':str(installed.resolve()),'public_archive_matches_ci':True,'installed_bytes_match_ci':True,'provenance_passed':True}
(p/'installed-identity.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2),flush=True)
