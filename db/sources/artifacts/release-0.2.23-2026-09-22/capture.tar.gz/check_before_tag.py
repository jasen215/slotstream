import json,re,subprocess,sys
from pathlib import Path
p=Path('/tmp/slotstream-release-0.2.23-20260922')
sys.path.insert(0,str(p/'source/Tools'))
from build_identity import sha,source_files
commit='14fb9aa3c253908cf7705b62780b28039ab42f92'
for name in ('ci','sevra-mac','docs','context-proxies'):
 d=json.loads((p/(name+'-passed.json')).read_text()); assert d['headSha']==commit and d['conclusion']=='success',name
identity=json.loads((p/'candidate/build-identity.json').read_text())
assert identity['source']=={str(f.relative_to(p/'source')):sha(f) for f in source_files(p/'source')}
for name,key in [('slotstream','binary_sha256'),('mlx.metallib','metallib_sha256'),('build-source.tar.gz','source_archive_sha256')]:assert sha(p/'candidate'/name)==identity[key],name
for name in ('native-rerun-2','mtp-16k'):
 d=json.loads((p/name/'receipt.json').read_text());assert d['exit_code']==0 and d['binary_sha256']==identity['binary_sha256'],name
text=(p/'native-rerun-2/stdout.txt').read_text()
assert re.search(r'^passed [0-9]+, failed 0$',text,re.M)
assert not re.search(r'^(FAIL|SKIP)\s',text,re.M)
for phrase in ('PASS  speculative decode gates','PASS  vision serving suite','PASS  serving robustness suite','PASS  behavioural quality probe','PASS  ELASTIC DRILL PASS:'):
 assert phrase in text,phrase
mtp=json.loads((p/'mtp-16k/stdout.txt').read_text())
assert mtp['passed'] and len(mtp['items'])==13 and all(x['passed'] for x in mtp['items'])
assert mtp['measurements']['candidate.largest_scope']>8192
assert mtp['measurements']['candidate.piecewise_writes']>0
assert mtp['measurements']['complete_diagnostic_peak_gb']<=10
version=subprocess.check_output([str(p/'candidate/slotstream'),'--version'],text=True).strip();assert version=='0.2.23'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=p/'source',text=True).strip()==commit
print(json.dumps({'commit':commit,'version':version,'binary_sha256':identity['binary_sha256'],'archive_sha256':sha(p/'ci-download/slotstream-arm64.tar.gz'),'all_required_acceptance_receipts_pass':True},indent=2))
