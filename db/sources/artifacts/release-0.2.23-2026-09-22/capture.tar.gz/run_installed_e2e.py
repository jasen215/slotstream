import json, os, socket, subprocess, sys, time, urllib.request
from pathlib import Path
sys.path.insert(0, '/tmp/slotstream-release-0.2.23-20260922/source/Tools')
from prefill_bench import preflight, run_child, vm_snapshot, digest, terminate_child_tree
ROOT=Path('/tmp/slotstream-release-0.2.23-20260922/source')
OUT=Path('/tmp/slotstream-release-0.2.23-20260922/installed-e2e')
OUT.mkdir(exist_ok=False)
BINARY=Path.home()/'.slotstream/bin/slotstream'
PORT=11530
env={k:v for k,v in os.environ.items() if not k.startswith('SLOTSTREAM_') and k not in ('BIN','MLX_METAL_PATH')}
env['BIN']=str(BINARY)
with socket.socket() as sock:
    sock.bind(('127.0.0.1',PORT))
command=[str(BINARY),'serve','--memory-gb','10','--mtp','on','--port',str(PORT)]
receipt=dict(command=command,binary_sha256=digest(BINARY),started_unix=time.time(),before=preflight(14))
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
server=None
try:
    with (OUT/'server-stdout.txt').open('wb') as so, (OUT/'server-stderr.txt').open('wb') as se:
        server=subprocess.Popen(command,cwd=ROOT,env=env,stdout=so,stderr=se,start_new_session=True)
        receipt['server_pid']=server.pid
        deadline=time.monotonic()+180
        while True:
            if server.poll() is not None: raise RuntimeError(f'server exited {server.returncode}')
            try:
                with urllib.request.urlopen(f'http://127.0.0.1:{PORT}/api/version',timeout=2) as r:
                    version=json.load(r)
                if version.get('version')!='0.2.23': raise RuntimeError(f'wrong server version: {version}')
                break
            except (OSError,TimeoutError):
                if time.monotonic()>=deadline: raise RuntimeError('server did not become ready')
                time.sleep(1)
        receipt['api_version']=version
        receipt['exit_code']=run_child(['bash','Tools/e2e_release.sh',str(PORT)],env,OUT,7200)
        for endpoint,body,name in [('/api/show',{'model':'qwen3.8-flash-next:4bit'},'final-show.json'),('/api/ps',None,'final-ps.json')]:
            req=urllib.request.Request(f'http://127.0.0.1:{PORT}'+endpoint,data=json.dumps(body).encode() if body else None,headers={'Content-Type':'application/json'})
            with urllib.request.urlopen(req,timeout=30) as r:
                (OUT/name).write_bytes(r.read())
finally:
    if server is not None:
        if server.poll() is None: terminate_child_tree(server)
        receipt['server_exit_code']=server.returncode
    receipt.update(finished_unix=time.time(),after=vm_snapshot())
    (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
raise SystemExit(receipt['exit_code'])
