import json, os, shutil, sys, time
from pathlib import Path
sys.path.insert(0, '/tmp/slotstream-release-0.2.23-20260922/source/Tools')
from prefill_bench import preflight, run_child, vm_snapshot, digest
ROOT = Path('/tmp/slotstream-release-0.2.23-20260922/source')
OUT = Path('/tmp/slotstream-release-0.2.23-20260922')
BINARY = OUT/'candidate/slotstream'
step = sys.argv[1]
cell = OUT/(sys.argv[2] if len(sys.argv)>2 else step)
cell.mkdir(exist_ok=False)
env = {k:v for k,v in os.environ.items() if not k.startswith('SLOTSTREAM_') and k not in ('BIN','MLX_METAL_PATH')}
if step == 'native':
    command = ['bash','Tools/verify-release-diagnostics.sh']
    env.update(SLOTSTREAM_TEST_BINARY=str(BINARY), SLOTSTREAM_VERIFY_OUT=str(cell/'verification'))
    needed, timeout = 20.5, 10800
elif step == 'mtp-16k':
    command = [str(BINARY),'optimization-state-check','--variant','prefill-followup-mtp-equality','--tokens','16387','--json']
    needed, timeout = 14, 3600
else:
    raise SystemExit('unknown step')
receipt = dict(command=command, binary_sha256=digest(BINARY), started_unix=time.time(), before=preflight(needed), overrides={k:v for k,v in env.items() if k.startswith('SLOTSTREAM_')})
(cell/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
try:
    receipt['exit_code'] = run_child(command,env,cell,timeout)
finally:
    receipt.update(finished_unix=time.time(),after=vm_snapshot())
    if step == 'native':
        fixed = cell/'fixed-tmp-outputs'; fixed.mkdir(exist_ok=False)
        for pattern in ('ssv_*','ssv-vision-serve.log'):
            for p in Path('/tmp').glob(pattern):
                if p.is_file(): shutil.copy2(p,fixed/p.name)
    (cell/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ('command','exit_code','started_unix','finished_unix')},indent=2),flush=True)
raise SystemExit(receipt['exit_code'])
