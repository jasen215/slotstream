/// Couple the automatic read envelope to the attention workspace actually
/// available for this request. This never grants memory: every candidate still
/// goes through physical-footprint, live-headroom and request admission.
package struct PrefillReadPolicy {
    package let fusedKVHeads: Int?

    package init(options: InferenceOptimizations, gpu: Bool, nax: Bool,
                 bf16: Bool, headDimension: Int, attentionHeads: Int, kvHeads: Int,
                 mtp: Bool, vision: Bool, smallPass: Bool) {
        let supported = options.fusedPrefillWorkspace == true
            && options.fusedPrefillAttention == true && gpu && nax && bf16
            && headDimension == 256 && attentionHeads > 0 && kvHeads > 0
            && kvHeads <= attentionHeads && attentionHeads % kvHeads == 0
            && !mtp && !vision && !smallPass
            && !options.terminalPrefillPruning && !options.selectedTextAttention
        fusedKVHeads = supported ? kvHeads : nil
    }

    /// The combined policy shares up to 16K tokens of reads only within the
    /// fused reservation's measured 256-query / 16K-key envelope. Later keys,
    /// other compute shapes and fallback attention retain the established cap.
    /// Explicit diagnostic overrides can study grouping independently.
    package func maximumScope(at position: Int, maxChunk: Int, gpu: Bool,
                              override: Int?) -> Int {
        guard gpu else { return 8192 }
        if let override { return override }
        guard fusedKVHeads != nil, (256 ... 4096).contains(maxChunk), position >= 0, position < 8192,
              PrefillSchedule.chunk(at: position, maxChunk: maxChunk) == 256 else { return 8192 }
        return 16384 - position
    }
}
