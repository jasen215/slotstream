from pathlib import Path
import hashlib, json, subprocess

r = Path(__file__).parent
repo = Path('/Users/carlos/Projects/slotstream')
artifact = repo / 'db/sources/artifacts/mtp-prefill-policy-2026-09-21'
assert (r/'registration-result.json').exists()
results = []
def run(name, args, cwd=repo):
    result = subprocess.run(args, cwd=cwd, text=True, capture_output=True)
    (artifact/(name+'.stdout.txt')).write_text(result.stdout)
    (artifact/(name+'.stderr.txt')).write_text(result.stderr)
    results.append({'name': name, 'args': args, 'exit': result.returncode})
    print(name, result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

run('final-docs', ['make', 'docs'])
run('final-brain-before-log', ['bash', 'Tools/brain_gates.sh'])
run('final-llms', ['bash', 'Tools/llms_full.sh', '--check'])
run('final-diff', ['git', 'diff', '--check'])
run('final-log', ['dbmd', '--json', 'log', 'update',
    'records/measurements/mtp-prefill-policy-2026-09-21.md', '-m',
    'Qualified automatic MTP prefill with separate main/draft peaks and bounded expert writes. Three clean paired runs show 65.40% lower prefill time at the 16K/10 GB M5 Pro profile; exact state/output, lifecycle, low-memory fallback, persistent restart, native app and static gates pass. Preserved V1 failure and paging-excluded component screen. Local implementation, not a release.'], repo/'db')
run('final-brain-after-log', ['bash', 'Tools/brain_gates.sh'])

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

identity = json.loads((r/'candidate/build-identity.json').read_text())
sources = {name: sha(repo/name)==value for name,value in identity['source'].items()}
assert all(sources.values()), [name for name,ok in sources.items() if not ok]
binary = sha(repo/'.build/release/slotstream')
assert binary == identity['binary_sha256']
for name in ['docs/LIBRARY.md', 'docs/TESTING.md']:
    text = (repo/name).read_text()
    link = '../db/records/measurements/mtp-prefill-policy-2026-09-21.md'
    assert link in text and ((repo/name).parent/link).exists()
manifest = json.loads((artifact/'manifest.json').read_text())
assert sha(artifact/'capture.tar.gz') == manifest['archive_sha256']
receipt = {'gates': results, 'source_matches_tested_build': sources,
    'working_release_binary_sha256': binary,
    'capture_sha256': manifest['archive_sha256'],
    'new_documentation_links_resolve': True,
    'validation_note': 'Zero errors; the two pre-existing legacy log warnings remain. See complete before/after transcripts.'}
(artifact/'final-verification.json').write_text(json.dumps(receipt, indent=2)+'\n')
