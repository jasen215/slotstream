from pathlib import Path
import sys,subprocess,json
r=Path(__file__).parent;c=r/'candidate'
def step(name,args,env={}):
 print('START',name,flush=True)
 code=subprocess.call([sys.executable,str(r/'run_step.py'),name,json.dumps(env)]+args)
 print('END',name,code,flush=True)
 if code:raise SystemExit(code)
for name,variant,extra in [('plain-equality16','prefill-opportunity-equality',['--tokens','16387']),('lifecycle','prefill-followup-lifecycle',[]),('checkpoint','prefill-followup-checkpoint',[]),('mtp-vision','prefill-followup-mtp-vision',[])]:
 step(name,[str(c/'slotstream'),'optimization-state-check','--variant',variant,'--json']+extra)
for name,budget,env in [('floor81',8.1,{}),('fusion-disabled',10,{'SLOTSTREAM_OPT_FUSED_PREFILL':'0'})]:
 step(name,[str(c/'slotstream'),'run','--raw','--prompt-file',str(r/'fixtures/inventory8195.txt'),'--memory-gb',str(budget),'--mtp','on','--greedy','--max-tokens','16','--sample-footprint','--stats-json',str(r/name/'metrics.json')],env|{'SLOTSTREAM_PREFILL_CHUNK':'256'})
step('persistent-mtp',[sys.executable,str(r/'persistent_mtp.py')],{'SLOTSTREAM_PREFILL_CHUNK':'256'})
step('app',['bash','Tools/check_sevra_mac.sh'])
