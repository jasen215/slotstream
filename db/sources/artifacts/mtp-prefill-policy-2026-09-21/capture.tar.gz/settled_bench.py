import sys,time,json,subprocess
from pathlib import Path
r=Path(__file__).parent
sys.path.insert(0,'/Users/carlos/Projects/slotstream/Tools')
import prefill_bench as bench
bench.FIXTURES=r/'fixtures'
original=bench.host_conditions
preflight=bench.preflight
bench.preflight=lambda n:preflight(max(14,n))
count=0
def host():
 global count
 if count%2==0:
  start=time.monotonic();nominal_since=None
  while True:
   condition=subprocess.check_output([str(r/'thermal')],text=True).strip()
   now=time.monotonic()
   with (r/'thermal.jsonl').open('a') as f:f.write(json.dumps({'study':sys.argv[sys.argv.index('--out')+1], 'cell':count//2+1,'seconds':now-start,'condition':condition})+'\n')
   if condition=='nominal false':
    if nominal_since is None:nominal_since=now
   else:nominal_since=None
   if nominal_since is not None and now-nominal_since>=120:break
   if now-start>=600:raise SystemExit('thermal state did not settle; stopped')
   time.sleep(15)
 count+=1
 result=original()
 result['instantaneous_thermal']=subprocess.check_output([str(r/'thermal')],text=True).strip()
 return result
bench.host_conditions=host
bench.main()
