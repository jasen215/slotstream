from pathlib import Path
import json,statistics
r=Path(__file__).parent
result={}
for study,control in [('timing','control'),('phase-screen','phase_only')]:
 path=r/study/'results.jsonl'
 if not path.exists():continue
 rows=[json.loads(s) for s in path.read_text().splitlines()];cells=[];pairs=[]
 for row in rows:
  d=row.get('metrics');s=d.get('stats',{}) if d else {};reasons=[]
  if not row.get('valid'):reasons.append(row.get('exclusion','invalid cell'))
  for edge in ['before','after']:
   if row.get('host_'+edge,{}).get('instantaneous_thermal')!='nominal false':reasons.append(edge+' thermal/power')
   if s.get('generatorSystem'+edge.title())!={'lowPowerModeEnabled':False,'thermalState':'nominal'}:reasons.append(edge+' generator thermal/power')
  if s.get('peakMemoryGB',100)>10:reasons.append('physical peak above10GB')
  if s.get('finishReason')=='error' or s.get('runtimeError'):reasons.append('generation error')
  if d and (not d.get('effective_mtp') or s.get('draftedTokens',0)<=0):reasons.append('MTP not exercised')
  cells.append({'round':row['round'],'arm':row['arm'],'eligible':not reasons,'exclusions':reasons,'prefill_seconds':s.get('prefillSeconds'),'request_seconds':s.get('requestSeconds'),'read_bytes':s.get('prefillReadBytes'),'read_groups':s.get('prefillPasses'),'peak_gb':s.get('peakMemoryGB'),'drafted_tokens':s.get('draftedTokens'),'output_ids':d.get('output_ids') if d else None,'swapins':row.get('after',{}).get('swapins',0)-row.get('before',{}).get('swapins',0),'swapouts':row.get('after',{}).get('swapouts',0)-row.get('before',{}).get('swapouts',0)})
 for n in sorted({x['round'] for x in rows}):
  group={x['arm']:x for x in rows if x['round']==n}
  if control not in group or 'automatic' not in group:continue
  a,b=group[control].get('metrics'),group['automatic'].get('metrics');checks={}
  if a and b:
   for k in ['prompt_ids','output_ids','effective_pool_slots','effective_mtp','effective_prefill_chunk','sampling']:checks[k]=a[k]==b[k]
   for k in ['prefillComputePasses','prefillComputeQueryRows','prefillComputeKeyExtents']:checks[k]=a['stats'][k]==b['stats'][k]
  matched=bool(checks) and all(checks.values());eligible=matched and all(x['eligible'] for x in cells if x['round']==n)
  pairs.append({'round':n,'eligible':eligible,'checks':checks,'prefill_reduction':1-b['stats']['prefillSeconds']/a['stats']['prefillSeconds'] if a and b else None,'request_reduction':1-b['stats']['requestSeconds']/a['stats']['requestSeconds'] if a and b else None,'read_reduction':1-b['stats']['prefillReadBytes']/a['stats']['prefillReadBytes'] if a and b else None})
 clean=[x for x in pairs if x['eligible']]
 result[study]={'cells':cells,'pairs':pairs,'eligible_pairs':len(clean),'qualified':len(clean)>=3,'median_prefill_reduction':statistics.median(x['prefill_reduction'] for x in clean) if len(clean)>=3 else None,'median_request_reduction':statistics.median(x['request_reduction'] for x in clean) if len(clean)>=3 else None}
(r/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
for study,x in result.items():
 print(study, len(x['cells']),'cells',x['eligible_pairs'],'eligible pairs','median',x['median_prefill_reduction'])
 for c in x['cells']:print(c['round'],c['arm'],c['prefill_seconds'],c['read_bytes'],c['read_groups'],c['peak_gb'],c['exclusions'])
