from pathlib import Path
import sys,subprocess,shutil,json
r=Path(__file__).parent;repo=Path('/Users/carlos/Projects/slotstream');c=r/'candidate';c.mkdir(exist_ok=False)
for n in ['slotstream','slotstream-checks','mlx.metallib','build-source.tar.gz','build-identity.json']:shutil.copy2(repo/'.build/release'/n,c/n)
def step(name,args,env={}):
 print('START',name,flush=True)
 code=subprocess.call([sys.executable,str(r/'run_step.py'),name,json.dumps(env)]+args)
 print('END',name,code,flush=True)
 if code:raise SystemExit(code)
step('catalogue-v2',[str(c/'slotstream-checks'),'--tier','t0','--tier','t1'])
step('mtp-equality16-v2',[str(c/'slotstream'),'optimization-state-check','--variant','prefill-followup-mtp-equality','--tokens','16387','--json'])
