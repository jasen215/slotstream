from pathlib import Path
import hashlib,json,tarfile,difflib
r=Path(__file__).parent;repo=Path('/Users/carlos/Projects/slotstream')
dest=repo/'db/sources/artifacts/mtp-prefill-policy-2026-09-21';dest.mkdir(parents=True,exist_ok=False)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
identity=json.loads((r/'candidate/build-identity.json').read_text())
source_check={name:sha(repo/name)==value for name,value in identity['source'].items()}
(r/'current-source-verified.json').write_text(json.dumps(source_check,indent=2)+'\n')
assert all(source_check.values()),[x for x,v in source_check.items() if not v]
out=''
for before in sorted((r/'before').rglob('*.swift')):
 p=before.relative_to(r/'before');out+=''.join(difflib.unified_diff(before.read_text().splitlines(True),(repo/p).read_text().splitlines(True),fromfile=str(p)+'.before',tofile=str(p)))
(r/'task-source.diff').write_text(out)
manifest={'members':{},'omitted_binaries':{}}
files=[]
for p in sorted(r.rglob('*')):
 if not p.is_file() or '__pycache__' in p.parts or p.name in ['continuation-notes.txt','capture.log']:continue
 name=str(p.relative_to(r))
 item={'bytes':p.stat().st_size,'sha256':sha(p)}
 if p.name in ['slotstream','slotstream-checks','mlx.metallib','thermal'] or ('persistent-mtp-state' in p.parts and p.parent != r/'persistent-mtp-state'):
  manifest['omitted_binaries'][name]=item;continue
 manifest['members'][name]=item;files.append((p,name))
with tarfile.open(dest/'capture.tar.gz','w:gz') as tar:
 for p,name in files:tar.add(p,arcname=name)
manifest['archive_sha256']=sha(dest/'capture.tar.gz');manifest['archive_bytes']=(dest/'capture.tar.gz').stat().st_size
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(files),'sha256':manifest['archive_sha256'],'bytes':manifest['archive_bytes']}))
