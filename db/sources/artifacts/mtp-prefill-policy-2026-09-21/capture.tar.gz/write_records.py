from pathlib import Path
import json,subprocess,statistics
r=Path(__file__).parent;repo=Path('/Users/carlos/Projects/slotstream');db=repo/'db'
artifact=db/'sources/artifacts/mtp-prefill-policy-2026-09-21'
assert (artifact/'capture.tar.gz').exists()
checks={x['name']:x for x in json.loads((r/'functional-summary.json').read_text())}
required=['catalogue-final','mtp-equality16-final','plain-equality16','lifecycle','checkpoint','mtp-vision','floor81-auto','fusion-disabled','persistent-mtp','app','static']
for name in required:
 assert checks[name]['exit']==0,name
 if 'passed' in checks[name]:assert checks[name]['passed'],name
for name in ['floor81-auto-metrics','fusion-disabled-metrics']:
 assert checks[name]['passed'],name
assert checks['floor81-auto-metrics']['mtp'] is False
assert checks['fusion-disabled-metrics']['mtp'] is True
assert checks['floor81']['exit']==1
assert 'cannot fit the 1.6 GB draft head above the 8.1 GB minimum' in (r/'floor81/stderr.txt').read_text()
analysis=json.loads((r/'analysis.json').read_text());primary=analysis['timing'];screen=analysis['phase-screen']
assert len(primary['cells'])==6 and len(screen['cells'])==2
assert all(all(p['checks'].values()) for p in primary['pairs']), 'unmatched primary pair'
assert primary['qualified'] and primary['eligible_pairs']==3
assert all(len(cell['output_ids'])==11 for cell in primary['cells'])
persistent=json.loads((r/'persistent-mtp-result.json').read_text())
assert persistent['passed'] and all(persistent['checks'].values())
assert 'STATIC GATES PASS' in (r/'static/stdout.txt').read_text()
sha=json.loads((r/'candidate/build-identity.json').read_text())['binary_sha256']
measurement='records/measurements/mtp-prefill-policy-2026-09-21';decision='records/decisions/automatic-mtp-prefill-read-policy'
prefix='sources/runs/2026/09/2026-09-21-mtp-prefill-policy-';drafts=r/'record-drafts';drafts.mkdir(exist_ok=True)
def write(path,kind,title,body,**fields):
 p=drafts/(Path(path).stem+'.md');p.write_text(body+'\n')
 cmd=['dbmd','write','--dir',str(db),'--type',kind,path+'.md','--summary',title,'--fm','title='+title,'--body-file',str(p),'--json']
 for k,v in fields.items():cmd+=['--fm',k+'='+str(v)]
 out=subprocess.run(cmd,text=True,capture_output=True,check=True);print(out.stdout,flush=True)
 target=db/(path+'.md')
 if not target.exists():
  matches=list(db.rglob(target.name));assert len(matches)==1,matches
  subprocess.run(['dbmd','rename',str(matches[0].relative_to(db)),str(target.relative_to(db)),'--dir',str(db),'--json'],check=True)
def run(suffix,title,body,discarded=False,binary=sha):
 links='[Raw capture](../../../artifacts/mtp-prefill-policy-2026-09-21/capture.tar.gz) and [member hashes](../../../artifacts/mtp-prefill-policy-2026-09-21/manifest.json).'
 write(prefix+suffix,'run',title,links+'\n\n'+body,tool='Frozen Swift model checks and paired benchmark',command='finish_qualification.py; timing.py; regressions.py; run_step.py; analyze.py; summarize.py',binary=binary,machines='[[records/machines/macbook-pro-m5-pro-48gb]]',captured_at='2026-09-21',discarded=str(discarded).lower())
def table(study,control):
 rows=['| Round | Control prefill seconds | Automatic prefill seconds | Pair eligibility |','| --- | ---: | ---: | --- |']
 for p in study['pairs']:
  a=next(x for x in study['cells'] if x['round']==p['round'] and x['arm']==control)
  b=next(x for x in study['cells'] if x['round']==p['round'] and x['arm']=='automatic')
  label='Eligible' if p['eligible'] else 'Excluded: '+', '.join(a['exclusions']+b['exclusions'])
  rows.append(f"| {p['round']} | {a['prefill_seconds']:.3f} | {b['prefill_seconds']:.3f} | {label} |")
 return '\n'.join(rows)
qualified=primary['qualified']
claim=(f"All three matched pairs are eligible. Median paired prefill-time reduction is {primary['median_prefill_reduction']*100:.2f}%; median paired request-time reduction is {primary['median_request_reduction']*100:.2f}%." if qualified else f"Only {primary['eligible_pairs']} matched pairs are eligible. The study does not meet its three-pair speed qualification; no repeatable percentage is claimed.")
perf=f'''The same frozen binary compares `SLOTSTREAM_OPT_FUSED_WORKSPACE=0` against the default automatic policy. Both retain fused attention. Configuration: inventory16387, 10 GB target, 640 slots, compute 256, MTP on with two drafts, greedy maximum 16 outputs, fresh processes, sampled physical footprint. Every primary cell actually emitted 11 tokens and finished at its stop token. The M5 Pro / 48 GB machine uses the pinned MLX 0.32.2 backend. Filesystem cache is uncontrolled; no purge. Source, binary, shader, model-header and exact token identities are preserved.

Each cell waits for 120 consecutive nominal, normal-power seconds. Eligibility requires completion, no global swap activity, nominal power/thermal before and after, matching prompt/output IDs, pool, compute geometry and sampling, and physical peak <= 10 GB. Every primary pair has matching inputs, outputs and compute passes. {claim}

{table(primary,'control')}

The generated analysis.json preserves every exclusion, observed read group, requested read byte count, actual peak and drafted-token count. Requested expert bytes are engine requests, not physical SSD traffic. This is a synthetic long-prompt/MTP result, not a universal throughput or cross-hardware claim. The sequential equality diagnostic is separate and must not be substituted for fresh-process timing.'''
run('timing','Automatic MTP prefill: paired latency evidence',perf,discarded=not qualified)
long=checks['mtp-equality16-final'];m=long['measurements'];catalogue=checks['catalogue-final']
counts=', '.join(f"{name}: {checks[name].get('assertions','see raw transcript')}" for name in ['mtp-equality16-final','plain-equality16','lifecycle','checkpoint','mtp-vision'])
functional=f'''Final catalogue: {catalogue['groups']} groups, {catalogue['assertions']} assertions, all pass. Model assertion counts: {counts}. A real server restart test forces MTP on in every server launch and checks the ordinary persistent-prefix path. Native Mac build/scripted regressions and the complete static suite pass. Functional and physical-memory checks retain global paging as diagnostics, independently of clean timing eligibility.

The long MTP equality check requires actual grouping beyond 8192 and actual piecewise writes, while comparing raw prompt logits, all retained tensor bytes, teacher-forced continuation, speculative output IDs and chronological compute passes exactly. It exercises {int(m['candidate.largest_scope'])} rows and {int(m['candidate.piecewise_writes'])} piecewise writes. Complete process peak including both sequential arms, fingerprinting and continuation is {m['complete_diagnostic_peak_gb']:.9f} GB, below 10 GB. Candidate requested reads are {int(m['candidate.expert_bytes'])} bytes; the sequential control requests {int(m['baseline.expert_bytes'])}. Different allocation histories make this an equality/physical-memory check, not a speed comparison.

The followup MTP/image lifecycle explicitly executes piecewise expert writes through cancellation during draft processing, checked read failure, rollback and exact retry. Automatic selection, checkpoints, disk restoration, head alignment, process/live-headroom fallback and image geometry remain covered. At 8.1 GB, forced MTP correctly refuses its additional resident head; normal automatic mode completes with MTP off, within the original target. The fusion-disabled MTP run also completes within its target. See functional-summary.json and each original receipt. No golden, tolerance or memory ceiling was relaxed.'''
run('correctness','Automatic MTP prefill: exactness, memory and integration',functional)
run('v1','MTP phase accounting alone: larger-scope gate failure preserved', '''V1 removed the blanket MTP exclusion and added separate phase accounting. Raw logits, every retained state byte, continuation, speculative IDs and the 10 GB physical ceiling passed, but the newly required group > 8192 assertion failed: the largest admitted group was 8192. Preserve the failed report and candidate-v1 binary/source identity. The followup did not weaken that assertion or enlarge its pool/budget. It changed actual expert-buffer lifetimes and priced the largest replacement piece, after which V2 and final both passed the original larger-group assertion.''',discarded=True,binary=json.loads((r/'candidate-v1/build-identity.json').read_text())['binary_sha256'])
run('phase-screen','MTP phase accounting versus bounded writes: one-pair screen',f'''One fresh-process pair compares frozen V1 phase accounting alone against the final automatic policy, at the same 10 GB, 640-slot, compute 256, MTP/two-draft configuration. This isolates the additional write/group tradeoff as a screen; one pair is insufficient for a repeatable speed percentage.

{table(screen,'phase_only')}

Earlier fixed-group experiments found piecewise writes slower. That negative evidence remains valid. The new policy pays those barriers only when they allow at least twice as many rows in a larger group; the comparison here tests that changed benefit. Exact raw cells and any paging exclusions remain in phase-screen/ and analysis.json.''',discarded=not all(x['eligible'] for x in screen['pairs']))
body=f'''The supported fused text-prefill policy now works with MTP automatically. There is no new user opt-in. MTP changes retained tensors and peak memory, but it does not require disabling fused main attention. {claim}

## Implementation

Price the main and draft phases separately and reserve their maximum. The draft calculation includes the complete main multi-stream output while it is retained, the shifted first draft pass and cache positions, short tails and full draft-attention allowance. Main and draft replacement caches remain separately charged. All byte arithmetic saturates on invalid input or overflow.

MTP resident weights can leave too little room for the larger main expert workspace. The engine can evaluate expert-buffer writes one piece at a time, which releases each old piece before replacing the next. Price the actual largest piece from pool shapes while retaining full original weights, staging, routed activations, retained frontiers and admission copies. This changes allocation lifetimes, not expert bytes or mathematical passes.

Extra write barriers are a performance cost. In the qualified fused MTP path, choose this strategy only for groups beyond 8192 through 16384 rows that at least double the largest batched-write group fitting the current process budget. The existing physical-footprint, live-headroom, queued-request, cancellation and checkpoint guards still select or reject each candidate. Public optimization settings remain immutable; execution controls belong to the current group. This is an operating tradeoff, not a new hardware, memory or arithmetic ceiling.

## Qualification

{functional}

## Paired latency

{perf}

## Limits and remaining opportunities

The result applies to this qualified M5 Pro profile, synthetic 16K prompt, small fixed target and MTP configuration. Do not compound it with the earlier standalone fused-kernel percentage. Other budgets and prompt shapes can choose different groups, and extra barriers do not help when the same group already fits. The first implementation's failed larger-scope assertion and the earlier fixed-group negative write experiments remain preserved.

The primary cells report median prefill I/O time falling from 106.28 to 5.16 seconds, while median total prefill falls from 155.22 to 53.94 seconds. Scatter time increases from 1.32 to 2.85 seconds and reported GPU wait from 7.46 to 14.37 seconds. These counters may overlap and are not a complete additive profile. They support prioritizing remaining model computation and synchronization over expecting another comparable gain from read elimination at this profile. Raw medians and their interpretation are in timing-counters.json.

The 16K key envelope, later-context reservations, full indexer/mask work, expert assembly and main-model compute remain limits on further gains. Broader key ranges and the write-strategy crossover across other prompt/budget profiles need separate measured qualification. Images retain their existing main-workspace policy. At qualification time these were local changes; this record is not a release receipt.

Decision: [[{decision}]]. Raw evidence: [[{prefix}timing]], [[{prefix}correctness]], [[{prefix}v1]], [[{prefix}phase-screen]].'''
write(measurement,'measurement','Automatic MTP prefill: phase accounting and bounded expert writes',body,doc='measurements',order='1615',level='2',date='2026-09-21',status='measured',machines='[[records/machines/macbook-pro-m5-pro-48gb]]',runs=', '.join('[['+prefix+x+']]' for x in ['timing','correctness','v1','phase-screen']))
write(decision,'decision','Apply MTP prefill improvements automatically',f'''At Carlos's explicit direction, replace the blanket MTP exclusion with actual phase accounting and qualify the combined path. Adopt the final implementation in [[{measurement}]] after exactness, physical-memory, lifecycle, cache, native app and static gates. {claim}

Main and draft phases reserve their real overlap through the larger peak. In the already supported fused text path, the engine may use bounded expert-buffer writes when doing so allows an MTP group beyond 8192 that at least doubles the ordinary group fitting the current process budget, within the 16384-row envelope. These are internal choices. No user opt-in, larger memory target, altered math pass, draft-depth change or new hardware claim is introduced.

The doubled-group threshold limits extra synchronization and is an empirical operating choice. Revisit it with matched group/write timing across prompt shapes and budgets, while preserving actual allocation guards. Do not reclassify previous fixed-scope negative write experiments or V1's failed larger-group gate as successes.''',decided_on='2026-09-21',status='standing',evidence='[['+measurement+']]',reversible_if='Reproduced state/cache or process-memory failure, or clean paired latency regression, narrows or reverses the automatic policy; wider profiles need their own evidence.')
def prepend(path,note):
 p=db/path;body=p.read_text().split('\n---\n',1)[1];draft=drafts/('updated-'+p.name);draft.write_text(note+'\n\n'+body)
 subprocess.run(['dbmd','body','set',str(p),'--body-file',str(draft),'--json'],check=True)
prepend('records/decisions/automatic-prefill-read-policy.md','MTP followup: [['+decision+']] replaces the initial MTP exclusion after separate phase and expert-buffer qualification. The original adoption and evidence below remain historical facts.')
prepend('records/measurements/automatic-prefill-policy-2026-09-21.md','Historical initial automatic-policy validation, preserved below. MTP is now included through [['+measurement+']]; the earlier paging-excluded study is not relabeled successful.')
(r/'registration-result.json').write_text(json.dumps({'measurement':measurement,'decision':decision,'qualified':qualified},indent=2)+'\n')
