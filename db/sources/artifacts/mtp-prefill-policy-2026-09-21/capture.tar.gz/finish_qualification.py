from pathlib import Path
import subprocess,sys
r=Path(__file__).parent
for script in ['qualify-final.py','timing.py','regressions.py']:
 print('START SCRIPT',script,flush=True)
 result=subprocess.call([sys.executable,str(r/script)])
 print('END SCRIPT',script,result,flush=True)
 if result:raise SystemExit(result)
