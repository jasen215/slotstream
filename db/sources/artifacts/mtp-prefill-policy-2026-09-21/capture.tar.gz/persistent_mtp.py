from pathlib import Path
import importlib.util,subprocess,sys,json
r=Path(__file__).parent;binary=str(r/'candidate/slotstream')
spec=importlib.util.spec_from_file_location('persistent_e2e','/Users/carlos/Projects/slotstream/Tools/persistent_prefix_e2e.py')
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
original=subprocess.Popen
launches=[]
def popen(args,*extra,**kwargs):
 if isinstance(args,(list,tuple)) and len(args)>1 and str(args[0])==binary and args[1]=='serve':
  args=list(args)+['--mtp','on'];launches.append(args)
  (r/'persistent-mtp-launches.json').write_text(json.dumps(launches,indent=2)+'\n')
 return original(args,*extra,**kwargs)
subprocess.Popen=popen
sys.argv=[__file__,'--binary',binary,'--memory-gb','10','--words','1200','--turn-words','200','--num-predict','16','--min-tokens','1024','--work',str(r/'persistent-mtp-state'),'--keep','--out',str(r/'persistent-mtp-result.json')]
code=module.main()
assert launches and all(x[-2:]==['--mtp','on'] for x in launches)

sys.exit(code)
