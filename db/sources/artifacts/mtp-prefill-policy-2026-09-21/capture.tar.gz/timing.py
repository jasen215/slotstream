from pathlib import Path
import sys,subprocess,json
r=Path(__file__).parent;c=r/'candidate/slotstream'
cmd=[sys.executable,str(r/'settled_bench.py'),'--arm','control='+str(c),'--arm','automatic='+str(c),'--arm-env','control={"SLOTSTREAM_OPT_FUSED_WORKSPACE":"0"}','--prompts','inventory16387','--rounds','3','--chunks','256','--memory-gb','10','--mtp','on','--max-tokens','16','--sample-footprint','--out',str(r/'timing')]
print('COMMAND',json.dumps(cmd),flush=True)
code=subprocess.call(cmd)
print('BENCHMARK EXIT',code,flush=True)
rows=(r/'timing/results.jsonl').read_text().splitlines()
if len(rows)!=6:raise SystemExit('Incomplete study: '+str(len(rows))+' cells')

cmd=[sys.executable,str(r/'settled_bench.py'),'--arm','phase_only='+str(r/'candidate-v1/slotstream'),'--arm','automatic='+str(c),'--prompts','inventory16387','--rounds','1','--chunks','256','--memory-gb','10','--mtp','on','--max-tokens','16','--sample-footprint','--out',str(r/'phase-screen')]
print('SCREEN COMMAND',json.dumps(cmd),flush=True)
code=subprocess.call(cmd)
print('SCREEN EXIT',code,flush=True)
if len((r/'phase-screen/results.jsonl').read_text().splitlines())!=2:raise SystemExit('Incomplete V1 screen')
