from pathlib import Path
import os,sys,json,time
r=Path(__file__).parent;repo=Path('/Users/carlos/Projects/slotstream');sys.path.insert(0,str(repo/'Tools'))
from prefill_bench import preflight,run_child,vm_snapshot
name,extra=sys.argv[1:3];cmd=sys.argv[3:]
env={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','SS_DEBUG','SEVRA_'))}|json.loads(extra)
before=preflight(14);cell=r/name;cell.mkdir(exist_ok=False);start=time.monotonic()
code=run_child(cmd,env,cell,1800)
(cell/'receipt.json').write_text(json.dumps({'command':cmd,'env':json.loads(extra),'before':before,'after':vm_snapshot(),'exit':code,'seconds':time.monotonic()-start},indent=2)+'\n')
print(name,code,flush=True);sys.exit(code)
