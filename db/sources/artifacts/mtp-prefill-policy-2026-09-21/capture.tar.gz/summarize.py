from pathlib import Path
import json,re
r=Path(__file__).parent;summary=[]
for p in sorted(r.glob('*/receipt.json')):
 receipt=json.loads(p.read_text());out=p.parent/'stdout.txt';item={'name':p.parent.name,'exit':receipt['exit'],'seconds':receipt['seconds']}
 if out.exists():
  text=out.read_text()
  try:
   d=json.loads(text)
   if isinstance(d,dict) and 'passed' in d:item.update(passed=d['passed'],assertions=len(d.get('items',[])),measurements=d.get('measurements'),failures=[x for x in d.get('items',[]) if not x['passed']])
  except ValueError:pass
  match=re.search(r'(\d+) passed, (\d+) failed, (\d+) skipped \((\d+) assertions\)',text)
  if match:item.update(groups=int(match[1]),failed_groups=int(match[2]),assertions=int(match[4]),passed=int(match[2])==0)
 summary.append(item)
for p in sorted(r.glob('*/metrics.json')):
 d=json.loads(p.read_text());s=d['stats'];summary.append({'name':p.parent.name+'-metrics','passed':s.get('finishReason')!='error' and not s.get('runtimeError') and s['peakMemoryGB']<=d['plan']['target_gb'],'mtp':d['effective_mtp'],'peak_gb':s['peakMemoryGB'],'prefill_tokens':s['prefillTokens'],'read_groups':s['prefillPasses'],'output_ids':d['output_ids']})
(r/'functional-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for x in summary:print(x['name'],x.get('passed'),x.get('exit'),x.get('assertions'))
