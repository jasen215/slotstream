from pathlib import Path
import json,subprocess,sys,time,shutil
repo=Path('/Users/carlos/Projects/slotstream')
root=Path(__file__).parent
sys.path.insert(0,str(repo/'Tools'))
from prefill_bench import preflight
binary=root/'build/candidate/slotstream'
steps=[('t1',[str(root/'build/candidate/slotstream-checks'),'--tier','t1','--json']),
       ('runtime',[str(binary),'runtime-check']),
       ('live',['python3','Tools/issue21_e2e.py','--binary',str(binary),'--out',str(root/'live')])]
for label,command in steps:
    preflight(13)
    print('START',label,flush=True)
    started=time.time()
    with (root/(label+'.log')).open('w') as log:
        done=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
    (root/(label+'-receipt.json')).write_text(json.dumps({'command':command,'exit_code':done.returncode,'started_unix':started,'finished_unix':time.time()},indent=2))
    print('END',label,done.returncode,flush=True)
    if done.returncode:raise SystemExit(done.returncode)
