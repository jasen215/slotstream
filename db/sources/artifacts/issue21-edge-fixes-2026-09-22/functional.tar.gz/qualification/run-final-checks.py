from pathlib import Path
import json,os,subprocess,sys,time
repo=Path('/Users/carlos/Projects/slotstream');root=Path(__file__).parent
sys.path.insert(0,str(repo/'Tools'))
from prefill_bench import preflight
binary=root/'build/candidate/slotstream'
steps=[('baseline-branch',['python3',str(root/'baseline-branch.py')],13),
       ('prefix-exact',[str(binary),'prefix-exact-check','--plan','--memory-gb','10','--max-context','32768','--mtp','off','--vision','off'],13),
       ('long131k',['python3','Tools/issue21_long_context.py','--binary',str(binary),'--out',str(root/'long131k'),'--max-context','131072'],16.5),
       ('static',['bash','Tools/static_gates.sh'],13)]
for label,command,headroom in steps:
    preflight(headroom)
    print('START',label,flush=True)
    started=time.time()
    with (root/(label+'.log')).open('w') as log:
        done=subprocess.run(command,cwd=repo,env=dict(os.environ,SLOTSTREAM_TEST_BINARY=str(binary)),stdout=log,stderr=subprocess.STDOUT)
    (root/(label+'-receipt.json')).write_text(json.dumps({'command':command,'exit_code':done.returncode,'started_unix':started,'finished_unix':time.time()},indent=2))
    print('END',label,done.returncode,flush=True)
    if done.returncode:raise SystemExit(done.returncode)
