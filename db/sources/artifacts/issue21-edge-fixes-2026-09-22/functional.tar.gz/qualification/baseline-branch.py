from pathlib import Path
import hashlib,http.client,json,os,socket,subprocess,sys,time
repo=Path('/Users/carlos/Projects/slotstream');root=Path(__file__).parent
sys.path.insert(0,str(repo/'Tools'))
from prefill_bench import preflight,vm_snapshot
binary=Path('/tmp/slotstream-issue21-review-20260922/bin/slotstream')
out=root/'baseline-branch';out.mkdir(exist_ok=False)
preflight(11.1)
with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
command=[str(binary),'serve','--memory-gb','8.1','--max-context','32768','--mtp','off','--vision','off','--port',str(port),'--prefix-cache-dir',str(out/'prefix'),'--prefix-cache-min-tokens','512']
receipt={'classification':'expected failure of pre-fix production engine on the new deterministic branch regression','command':command,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'before':vm_snapshot(),'reproduced':False}
log=(out/'server.log').open('w');server=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
try:
 for _ in range(180):
  assert server.poll() is None
  try:
   c=http.client.HTTPConnection('127.0.0.1',port,timeout=1);c.request('GET','/api/version');r=c.getresponse();r.read();c.close()
   if r.status==200:break
  except (OSError,http.client.HTTPException):pass
  time.sleep(.5)
 else:raise RuntimeError('startup timeout')
 rows=[]
 for label in ['branch-alpha-seed','branch-beta-seed','branch-alpha-followup']:
  source=json.loads((root/'live/issue21'/(label+'.json')).read_text())
  body=source['request'];(out/(label+'-request.json')).write_text(json.dumps(body,indent=2))
  c=http.client.HTTPConnection('127.0.0.1',port,timeout=180)
  try:
   c.request('POST','/v1/chat/completions',json.dumps(body),{'Content-Type':'application/json'});r=c.getresponse();raw=r.read();status=r.status
  finally:c.close()
  (out/(label+'.sse')).write_bytes(raw)
  events=[json.loads(line[6:]) for line in raw.decode().splitlines() if line.startswith('data: ') and line!='data: [DONE]']
  assert status==200 and b'data: [DONE]' in raw and not any('error' in e for e in events)
  usage=next(e['usage'] for e in reversed(events) if e.get('usage'))
  rows.append(usage);print(label,usage,flush=True)
 expected=rows[0]['prompt_tokens']-256
 receipt.update(rows=rows,minimum_expected_reuse=expected,reproduced=rows[-1]['prompt_tokens_details']['cached_tokens']<expected)
 assert receipt['reproduced'], 'baseline unexpectedly passes the branch regression'
 print('EXPECTED FAILURE reproduced: old selector loses a retained compatible branch',flush=True)
finally:
 if server.poll() is None:
  server.terminate()
  try:server.wait(timeout=20)
  except subprocess.TimeoutExpired:server.kill();server.wait()
 log.close();receipt.update(server_pid=server.pid,server_exit_code=server.returncode,after=vm_snapshot())
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2))
