from pathlib import Path
import hashlib,json,tarfile,io
root=Path.cwd()
out=root/'db/sources/artifacts/adaptive-memory-third-review-2026-09-21'
out.mkdir(parents=True,exist_ok=False)
files={}
allowed={'.json','.log','.md','.txt','.py','.swift'}
for p in Path('/tmp').glob('memory-review3-*'):
    if p.is_file() and p.suffix in allowed: files[p.name]=p.read_bytes()
    elif p.is_dir():
        for f in p.rglob('*'):
            if f.is_file() and f.suffix in allowed: files[str(f.relative_to(p.parent))]=f.read_bytes()
paths=set(json.loads(Path('/tmp/memory-review3-final-proxy/report.json').read_text())['source_sha256'])
paths.update(['Sources/slotstream-cli/main.swift','Sources/slotstream-cli/LaunchCommand.swift','Sources/Slotstream/CodingToolLaunch.swift','Sources/Slotstream/Server.swift','Sources/SlotstreamTestKit/LaunchChecks.swift','Tools/verify.sh','Tools/verify_binary_test.py','Tools/memory_override_gate.py','Tools/adaptive_memory_e2e.py','Tools/check_sevra_memory_ui.sh','Tools/consumer_smoke.sh','apps/macos/Runtime/ResponseMetrics.swift','apps/macos/Runtime/Performance.swift','apps/macos/Runtime/Inference.swift','apps/macos/App/ContentView.swift','apps/macos/App/ResponseDetails.swift','apps/macos/NativeChecks/MemoryUIChecks.swift','apps/macos/Checks/PerformanceChecks.swift','apps/macos/Checks/RealMetricsChecks.swift','apps/macos/Checks/ResponseDetailsChecks.swift','docs/LIBRARY.md','CHANGELOG.md'])
for p in paths: files['source/'+p]=(root/p).read_bytes()
manifest={n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(files.items())}
archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for name,data in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
        tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive) as tar:
    assert len(tar.getmembers())==len(manifest)
    for member in tar.getmembers():
        data=tar.extractfile(member).read()
        assert len(data)==manifest[member.name]['bytes']
        assert hashlib.sha256(data).hexdigest()==manifest[member.name]['sha256']
(out/'manifest.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':manifest},indent=2)+'\n')
print('Verified archive:',len(manifest),'members',archive.stat().st_size,'bytes')
