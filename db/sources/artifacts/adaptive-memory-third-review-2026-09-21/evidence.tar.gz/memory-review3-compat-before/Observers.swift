import Foundation

public struct ModelError: Error, CustomStringConvertible {
    public let description: String
    public init(_ s: String) { description = s }
}

// MARK: - Config

public struct ModelConfig {
    public var hiddenSize = 2560
    public var numLayers = 48
    public var numAttentionHeads = 24
    public var numKVHeads = 2
    public var headDim = 256
    public var maxPositionEmbeddings = ContextPolicy.modelLimit
    public var vocabSize = 248_320
    public var rmsNormEps: Float = 1e-6
    public var fullAttentionInterval = 4
    public var layerTypes: [String] = []
    // MoE
    public var numExperts = 512
    public var topK = 10
    public var moeIntermediate = 640
    public var sharedExpertIntermediate = 640
    // GDN
    public var linearNumKHeads = 16
    public var linearNumVHeads = 48
    public var linearKHeadDim = 128
    public var linearVHeadDim = 128
    public var convKernel = 4
    public var outputGateType = "sigmoid"
    // hyper-connections
    public var hcCount = 4
    public var hcLowrank = 320
    // QSA indexer
    public var indexerNHeads = 4
    public var indexerKVHeads = 1
    public var indexerHeadDim = 128
    public var indexerBudget = 2048
    public var indexerCompressRatio = 4
    // n-gram / PLE
    public var ngramSize = 3
    public var headsPerNgram = 8
    public var ngramVocabBase = 20_000_000
    public var ngramDivisibleBy = 128
    public var splitNgramParts = 128
    public var pleEmbedDim = 2560
    public var pleLayerIds: [Int] = [2]  // 1-based per config; layer index = id-1
    public var pleConvKernel = 4
    public var seed = 1234
    // rope
    public var ropeTheta: Float = 10_000_000
    public var partialRotaryFactor: Float = 0.25
    public var eosTokenId = 248_044
    // vision (VLM): the placeholder the template emits per image, and the ids
    // the tower's embeddings splice in under (see Model.hiddenStates).
    public var imageTokenId = 248_056
    public var visionStartId = 248_053
    public var visionEndId = 248_054
    // quantization
    public var qBits = 4
    public var qGroup = 64
    public var ngramQGroup = 32

    public var rotaryDim: Int { Int(Float(headDim) * partialRotaryFactor) }
    public var pleLayerIndices: [Int] { pleLayerIds.map { $0 - 1 } }

    public static func load(from dir: URL) throws -> ModelConfig {
        let path = dir.appendingPathComponent("config.json")
        let data = try Data(contentsOf: path)
        guard let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw ModelError("\(path.path) is not valid JSON — re-run `slotstream pull`")
        }
        guard let t = root["text_config"] as? [String: Any] else {
            throw ModelError(
                "\(path.path) has no `text_config` section, so it is not a "
                    + "\(PinnedModelName.display) checkpoint — check --model")
        }
        var c = ModelConfig()
        func i(_ k: String, _ d: Int) -> Int { (t[k] as? Int) ?? d }
        func f(_ k: String, _ d: Float) -> Float {
            if let v = t[k] as? Double { return Float(v) }
            return d
        }
        c.hiddenSize = i("hidden_size", c.hiddenSize)
        c.numLayers = i("num_hidden_layers", c.numLayers)
        c.numAttentionHeads = i("num_attention_heads", c.numAttentionHeads)
        c.numKVHeads = i("num_key_value_heads", c.numKVHeads)
        c.headDim = i("head_dim", c.headDim)
        c.maxPositionEmbeddings = i("max_position_embeddings", c.maxPositionEmbeddings)
        c.vocabSize = i("vocab_size", c.vocabSize)
        c.rmsNormEps = f("rms_norm_eps", c.rmsNormEps)
        c.fullAttentionInterval = i("full_attention_interval", c.fullAttentionInterval)
        c.layerTypes = (t["layer_types"] as? [String]) ?? []
        c.numExperts = i("num_experts", c.numExperts)
        c.topK = i("num_experts_per_tok", c.topK)
        c.moeIntermediate = i("moe_intermediate_size", c.moeIntermediate)
        c.sharedExpertIntermediate = i("shared_expert_intermediate_size", c.sharedExpertIntermediate)
        c.linearNumKHeads = i("linear_num_key_heads", c.linearNumKHeads)
        c.linearNumVHeads = i("linear_num_value_heads", c.linearNumVHeads)
        c.linearKHeadDim = i("linear_key_head_dim", c.linearKHeadDim)
        c.linearVHeadDim = i("linear_value_head_dim", c.linearVHeadDim)
        c.convKernel = i("linear_conv_kernel_dim", c.convKernel)
        c.outputGateType = (t["output_gate_type"] as? String) ?? c.outputGateType
        c.hcCount = i("hc_count", c.hcCount)
        c.hcLowrank = i("hc_lowrank", c.hcLowrank)
        c.indexerNHeads = i("indexer_n_heads", c.indexerNHeads)
        c.indexerKVHeads = i("indexer_kv_heads", c.indexerKVHeads)
        c.indexerHeadDim = i("indexer_head_dim", c.indexerHeadDim)
        c.indexerBudget = i("indexer_budget", c.indexerBudget)
        c.indexerCompressRatio = i("indexer_compress_ratio", c.indexerCompressRatio)
        c.ngramSize = i("ngram_size", c.ngramSize)
        c.headsPerNgram = i("heads_per_ngram", c.headsPerNgram)
        c.ngramVocabBase = i("ngram_vocab_size_base", c.ngramVocabBase)
        c.ngramDivisibleBy = i("make_ngram_vocab_size_divisible_by", c.ngramDivisibleBy)
        c.splitNgramParts = i("split_ngram_parts", c.splitNgramParts)
        c.pleEmbedDim = i("ple_embed_dim", c.pleEmbedDim)
        c.pleLayerIds = (t["ple_layer_ids"] as? [Int]) ?? c.pleLayerIds
        c.pleConvKernel = i("ple_conv_kernel_size", c.pleConvKernel)
        c.seed = i("seed", c.seed)
        if let rp = t["rope_parameters"] as? [String: Any] {
            if let th = rp["rope_theta"] as? Double { c.ropeTheta = Float(th) }
            if let pf = rp["partial_rotary_factor"] as? Double { c.partialRotaryFactor = Float(pf) }
        }
        if let e = t["eos_token_id"] as? Int { c.eosTokenId = e }
        if let e = (t["eos_token_id"] as? [Int])?.first { c.eosTokenId = e }
        // Vision ids live in the root of config.json, not text_config.
        if let v = root["image_token_id"] as? Int { c.imageTokenId = v }
        if let v = root["vision_start_token_id"] as? Int { c.visionStartId = v }
        if let v = root["vision_end_token_id"] as? Int { c.visionEndId = v }
        // These two values shape a Range and a modulo below. Validate them
        // before using either; malformed custom config used to trap here before
        // the comprehensive validation at the end of the loader could run.
        guard c.numLayers > 0, c.numLayers <= 256, c.fullAttentionInterval > 0 else {
            throw ModelError(
                "unsupported or invalid text_config (layer count/attention interval) — check --model")
        }
        if c.layerTypes.isEmpty {
            c.layerTypes = (0 ..< c.numLayers).map {
                ($0 + 1) % c.fullAttentionInterval == 0 ? "full_attention" : "linear_attention"
            }
        }
        if let q = root["quantization"] as? [String: Any] {
            c.qBits = (q["bits"] as? Int) ?? c.qBits
            c.qGroup = (q["group_size"] as? Int) ?? c.qGroup
            // ngram shard override (all identical per M0)
            for (k, v) in q {
                if k.contains("ngram_embedding"), let d = v as? [String: Any],
                    let g = d["group_size"] as? Int
                {
                    c.ngramQGroup = g
                    break
                }
            }
        }
        try c.validate()
        return c
    }

    /// Reject unsupported or internally inconsistent geometry before any
    /// range construction, array indexing, or GPU allocation can trap. This
    /// runner intentionally supports one architecture; silently accepting a
    /// near-match only turns a useful `--model` error into a much later crash.
    private func validate() throws {
        func bad(_ detail: String) throws -> Never {
            throw ModelError("unsupported or invalid text_config (\(detail)) — check --model")
        }
        guard hiddenSize == 2560, numLayers == 48, maxPositionEmbeddings == ContextPolicy.modelLimit,
            numAttentionHeads == 24, numKVHeads == 2, headDim == 256,
            vocabSize == 248_320, fullAttentionInterval == 4,
            numExperts == 512, topK == 10, moeIntermediate == 640,
            sharedExpertIntermediate == 640,
            linearNumKHeads == 16, linearNumVHeads == 48,
            linearKHeadDim == 128, linearVHeadDim == 128, convKernel == 4,
            outputGateType == "sigmoid", hcCount == 4, hcLowrank == 320,
            indexerNHeads == 4, indexerKVHeads == 1, indexerHeadDim == 128,
            indexerBudget == 2048, indexerCompressRatio == 4,
            ngramSize == 3, headsPerNgram == 8, ngramVocabBase == 20_000_000,
            ngramDivisibleBy == 128, splitNgramParts == 128,
            pleEmbedDim == 2560, pleLayerIds == [2], pleConvKernel == 4,
            qBits == 4, qGroup == 64, ngramQGroup == 32
        else {
            try bad("checkpoint geometry does not match Qwen3.8-Flash-Next-MLX-4bit")
        }
        guard numAttentionHeads > 0, numKVHeads > 0, headDim > 0,
            vocabSize > 0, fullAttentionInterval > 0,
            topK > 0, topK <= numExperts, moeIntermediate > 0,
            sharedExpertIntermediate > 0, linearNumKHeads > 0,
            linearNumVHeads > 0, linearKHeadDim > 0, linearVHeadDim > 0,
            convKernel > 0, hcCount > 0, hcLowrank > 0,
            indexerNHeads > 0, indexerKVHeads > 0, indexerHeadDim > 0,
            indexerBudget > 0, indexerCompressRatio > 0,
            ngramSize >= 2, headsPerNgram > 0, ngramVocabBase > 0,
            ngramDivisibleBy > 0, splitNgramParts > 0, pleEmbedDim > 0,
            pleConvKernel > 0, !pleLayerIds.isEmpty,
            qGroup > 0, ngramQGroup > 0,
            rmsNormEps.isFinite, rmsNormEps > 0,
            ropeTheta.isFinite, ropeTheta > 0,
            partialRotaryFactor.isFinite, partialRotaryFactor > 0,
            partialRotaryFactor <= 1
        else { try bad("non-positive, non-finite, or unsupported dimensions") }
        guard hiddenSize % 8 == 0, hiddenSize % qGroup == 0,
            moeIntermediate % 8 == 0, moeIntermediate % qGroup == 0,
            pleEmbedDim % ((ngramSize - 1) * headsPerNgram) == 0,
            indexerBudget / indexerCompressRatio > 0
        else { try bad("dimensions are not divisible by their packing/group sizes") }
        guard pleLayerIds.allSatisfy({ $0 >= 1 && $0 <= numLayers }) else {
            try bad("ple_layer_ids is outside the layer stack")
        }
        if !layerTypes.isEmpty {
            let expected = (0 ..< numLayers).map {
                ($0 + 1) % fullAttentionInterval == 0 ? "full_attention" : "linear_attention"
            }
            guard layerTypes.count == numLayers,
                layerTypes == expected
            else { try bad("layer_types must name all 48 supported attention layers") }
            guard pleLayerIds.allSatisfy({ layerTypes[$0 - 1] == "linear_attention" }) else {
                try bad("a PLE layer is not a linear_attention layer")
            }
        }
        guard eosTokenId >= 0, eosTokenId < vocabSize else {
            try bad("eos_token_id is outside the vocabulary")
        }
    }
}


public enum GovernorPolicy {
    public enum Pressure: String { case warning, critical }

    public struct Inputs {
        public var currentSlots: Int
        public var availableGB: Double
        public var ramGB: Double
        public var workingSetGB: Double
        /// The RAM share auto may target; mirrors --max-ram-percent.
        public var ramPercent: Double
        public var memoryLimitGB: Double?
        public var mtpEnabled: Bool
        public var visionEnabled: Bool
        public var visionResidentReserved: Bool
        public var maxContextTokens: Int
        public var runtimeAllocationPolicy: RuntimeAllocationPolicy?
        public var ownedAdditionalBytes: Int
        public var contextQualification: Bool
        /// The running engine's decode lookahead decision and reserved bytes. A
        /// restart would release the bytes; a re-plan keeps both.
        public var decodeLookahead: Bool
        public var lookaheadReserveBytes: Int
        /// nil = no such event yet in this process.
        public var secondsSincePressure: Double?
        public var secondsSinceResize: Double?
        /// Set when this tick is an OS pressure event rather than a poll.
        public var pressure: Pressure?

        public init(
            currentSlots: Int, availableGB: Double, ramGB: Double, workingSetGB: Double,
            ramPercent: Double = Planner.defaultRAMPercent,
            secondsSincePressure: Double? = nil, secondsSinceResize: Double? = nil,
            pressure: Pressure? = nil,
            mtpEnabled: Bool = false, visionEnabled: Bool = false,
            visionResidentReserved: Bool = false,
            maxContextTokens: Int = ContextPolicy.defaultTokens,
            runtimeAllocationPolicy: RuntimeAllocationPolicy? = nil,
            ownedAdditionalBytes: Int = 0, contextQualification: Bool = false,
            decodeLookahead: Bool = false, lookaheadReserveBytes: Int = 0,
            memoryLimitGB: Double? = nil
        ) {
            self.ramPercent = ramPercent
            self.memoryLimitGB = memoryLimitGB
            self.currentSlots = currentSlots
            self.availableGB = availableGB
            self.ramGB = ramGB
            self.workingSetGB = workingSetGB
            self.secondsSincePressure = secondsSincePressure
            self.secondsSinceResize = secondsSinceResize
            self.pressure = pressure
            self.mtpEnabled = mtpEnabled
            self.visionEnabled = visionEnabled
            self.visionResidentReserved = visionResidentReserved
            self.maxContextTokens = maxContextTokens
            self.runtimeAllocationPolicy = runtimeAllocationPolicy
            self.ownedAdditionalBytes = max(0, ownedAdditionalBytes)
            self.contextQualification = contextQualification
            self.decodeLookahead = decodeLookahead
            self.lookaheadReserveBytes = max(0, lookaheadReserveBytes)
        }
    }

    public enum Decision: Equatable {
        case hold
        case resize(slots: Int, reason: String)
    }

    public static let growCooldown: TimeInterval = 60
    static let shrinkDeadbandGB = 1.0
    static let growDeadbandGB = 2.0

    private static func settle(_ target: Int, _ current: Int, _ reason: String) -> Decision {
        let t = max(Geometry.floorSlots, min(target, Geometry.totalRecords))
        return t == current ? .hold : .resize(slots: t, reason: reason)
    }

    /// What auto would choose if slotstream restarted right now: reclaimable
    /// memory credited with everything we hold that a restart would release —
    /// the pool AND the fixed footprint (the planner subtracts the fixed
    /// footprint again when deriving slots, so without this credit the steady
    /// state under contention double-reserves ~4 GB).
    public static func desiredPlan(_ i: Inputs) -> MemoryPlan? {
        let credited = i.availableGB + Geometry.gb(i.currentSlots) + Planner.fixedFootprintGB
            + (i.mtpEnabled ? Planner.mtpResidentGB : 0)
            + (i.visionResidentReserved ? Planner.visionResidentGB : 0)
            + Double(i.ownedAdditionalBytes) / 1e9
            + Double(i.lookaheadReserveBytes) / 1e9
        guard let plan = try? Planner.plan(
            expertsPerLayer: nil, poolGB: nil, memoryGB: nil, memoryLimitGB: i.memoryLimitGB,
            ramGB: i.ramGB, workingSetGB: i.workingSetGB, availableGB: credited,
            ramPercent: i.ramPercent,
            mtp: i.mtpEnabled ? .on : .off, mtpAvailable: i.mtpEnabled,
            vision: i.visionEnabled ? .on : .off, visionAvailable: i.visionEnabled,
            visionResidentReserved: i.visionResidentReserved, maxContextTokens: i.maxContextTokens,
            qualification: i.contextQualification, runtimePolicy: i.runtimeAllocationPolicy,
            decodeLookahead: .retained(enabled: i.decodeLookahead, bytes: i.lookaheadReserveBytes)),
            plan.mtpEnabled == i.mtpEnabled else { return nil }
        // Startup preserves a legacy advisory floor at ordinary contexts.
        // A live governor must not interpret that advisory as permission to
        // admit work after an infeasible replan. Price the complete resolved
        // allocation against the same credited physical budget at every cap.
        let physical = min(i.workingSetGB,
            credited - Planner.availabilitySlackGB(ramGB: i.ramGB))
        let peak = Double(plan.memoryLedger.expectedPeakBytes)
        guard physical.isFinite, physical > 0, peak <= physical * 1e9,
              plan.targetGB.map({ peak <= $0 * 1e9 }) ?? true else { return nil }
        // A startup planner may decline a head under pressure, but the live
        // governor has no operation that unloads an already resident head.
        return plan
    }

    public static func desiredSlots(_ i: Inputs) -> Int? {
        desiredPlan(i)?.slots
    }

    /// Live allocation controls for a resize. Availability-driven targets come
    /// directly from a fresh planner result, so preserve that result's prefill
    /// and prefix budgets. Deriving them again from the already-net expert pool
    /// double-subtracts their cost: at the 33 GB knee it downgraded a recovered
    /// server from the planned 4096-token pass to 2048. A pressure-event target
    /// can be an arbitrary extra shed, so it deliberately uses the conservative
    /// pool-only fallback.
    public static func liveControls(
        for targetSlots: Int, inputs i: Inputs
    ) -> (prefillChunk: Int, prefixCacheTokens: Int) {
        if let p = desiredPlan(i), p.slots == targetSlots {
            return (p.prefillChunk, p.prefixCacheTokens)
        }
        let gb = Geometry.gb(targetSlots)
        return (
            min(Planner.prefillChunkFor(poolBudgetGB: gb, contextCap: i.maxContextTokens), i.runtimeAllocationPolicy?.prefillChunkOverride ?? 4096),
            i.runtimeAllocationPolicy?.prefixCacheEnabled == false ? 0 : Planner.prefixCacheTokensFor(poolBudgetGB: gb, contextCap: i.maxContextTokens))
    }

    public static func decide(_ i: Inputs) -> Decision {
        let curGB = Geometry.gb(i.currentSlots)
        let planned = desiredPlan(i)
        let desired = planned?.slots
        // OS pressure events see what availability math cannot: compressor and
        // swap strain from system-wide overcommit. Shed an absolute chunk —
        // repeated events keep shedding until the pressure stops.
        if let p = i.pressure {
            let shedGB = p == .critical ? max(4.0, curGB * 0.5) : max(2.0, curGB * 0.15)
            var target = Int((curGB - shedGB) * 1e9 / Geometry.recordBytes)
            if let d = desired { target = min(target, d) }
            return settle(target, i.currentSlots, "memory pressure (\(p.rawValue))")
        }
        guard let d = desired else { return settle(Geometry.floorSlots, i.currentSlots, "context plan unavailable") }
        let desiredGB = Geometry.gb(d)
        if desiredGB <= curGB - shrinkDeadbandGB {
            return settle(d, i.currentSlots, "availability dropped")
        }
        // Finish recovery at the supported ceiling, including a busy startup.
        // While availability still clamps the plan, retain the normal band.
        let restoring = planned?.clamped == false && d > i.currentSlots
        if desiredGB >= curGB + growDeadbandGB || restoring {
            let calm = i.secondsSincePressure.map { $0 > growCooldown } ?? true
            let cooled = i.secondsSinceResize.map { $0 > growCooldown } ?? true
            if calm, cooled { return settle(d, i.currentSlots, "memory freed") }
        }
        return .hold
    }
}


public struct ChatMessage {
    public var role: String
    public var content: String
    /// An assistant turn's reasoning, rendered as `reasoning_content`. Clients
    /// that keep reasoning in history can replay it; fx does not send any.
    public var reasoning: String?
    /// Calls this assistant turn made.
    public var toolCalls: [ParsedToolCall]
    /// For a `tool` message: which call it answers.
    public var toolCallId: String?
    public var toolName: String?
    /// Pictures this turn carries, as inline bytes (a `data:` URL or bare
    /// base64) in the order the template should render them. Text-only paths
    /// leave it empty and behave exactly as before.
    public var images: [String] = []

    public init(role: String, content: String) {
        self.role = role
        self.content = content
        self.reasoning = nil
        self.toolCalls = []
        self.toolCallId = nil
        self.toolName = nil
    }

    public init(
        role: String, content: String, reasoning: String? = nil,
        toolCalls: [ParsedToolCall] = [], toolCallId: String? = nil, toolName: String? = nil
    ) {
        self.role = role
        self.content = content
        self.reasoning = reasoning
        self.toolCalls = toolCalls
        self.toolCallId = toolCallId
        self.toolName = toolName
    }

    /// The dictionary the chat template consumes.
    ///
    /// Tool-call arguments are bridged as an unordered dictionary because
    /// swift-jinja accepts nothing else, so the template's `arguments|items`
    /// follows Swift's hash order. That is why a generated assistant turn is
    /// spliced back as raw ids rather than re-rendered (`PrefixCache`): a
    /// re-render is semantically identical but not byte-identical, and the
    /// prefix cache matches on bytes.
    public var templateValue: [String: any Sendable] {
        var m: [String: any Sendable] = ["role": role, "content": content]
        // The template checks each content part for an `image`/`image_url`
        // key, so a turn with pictures has to arrive as parts rather than a
        // string. Images first, then the text: that is the order the template
        // numbers them in ("Picture 1: ..."), and the order
        // `Engine.imageSources` reads them back in.
        if !images.isEmpty {
            var parts: [[String: any Sendable]] = images.map {
                ["type": "image_url", "image_url": ["url": $0] as [String: any Sendable]]
            }
            if !content.isEmpty { parts.append(["type": "text", "text": content]) }
            m["content"] = parts
        }
        if let r = reasoning, !r.isEmpty { m["reasoning_content"] = r }
        if !toolCalls.isEmpty {
            m["tool_calls"] = toolCalls.map { call in
                [
                    "type": "function",
                    "function": [
                        "name": call.name,
                        "arguments": call.arguments.mapValues { $0.any },
                    ] as [String: any Sendable],
                ] as [String: any Sendable]
            }
        }
        return m
    }
}


public enum RuntimeClock {
    public static func now() -> UInt64 { DispatchTime.now().uptimeNanoseconds }
    public static func seconds(since start: UInt64) -> Double {
        Double(now() - start) / 1e9
    }
}

/// Image source decoding and first-tower loading happen before Generator.
/// Keep this separate interval observable instead of omitting a cold peak.

public enum SweepTuning {
    /// Inputs of this many tokens or more, which only a prefill pass is, take
    /// the sweep: each layer's routed experts stream through staging groups
    /// and MLX's grouped GEMM and never touch the slot pool. Shorter inputs
    /// (decode, speculative verify passes, short follow-up turns) gather over
    /// the pool as before. The choice is a function of the token count alone,
    /// never of the pool, so pool size and contents still cannot change the
    /// math (the golden-equivalence invariant). `Int.max` forces the pool path
    /// at every size.
    /// Whether the sweep gathers every sorted row up front (what shipped
    /// through 0.2.3) instead of per staging group. `SLOTSTREAM_SWEEP_ROWS=all`
    /// restores it for an A/B; the rows the kernel sees are identical either
    /// way, only how long the replicated copy is held changes.
    public static let gatherAllRows: Bool =
        ProcessInfo.processInfo.environment["SLOTSTREAM_SWEEP_ROWS"] == "all"

    public static var minTokens: Int =
        ProcessInfo.processInfo.environment["SLOTSTREAM_SWEEP"] == "0" ? Int.max : 256
}


public enum PrefixCache {
    public static let bytesPerToken = 27_648
    public static let fixedBytesPerEntry = 36 * 48 * 128 * 128 * 4
    public static let maxEntries = 4
}
extension Planner {
    // Deliberately unreadable observers. Every successful test injects its
    // machine values; forgotten injection cannot borrow real host headroom.
    public static func deviceRAMGB() -> Double { .nan }
    public static func deviceWorkingSetGB() -> Double { .nan }
    public static func deviceAvailableGB() -> Double? { nil }
}