from pathlib import Path
import subprocess,re
specs=[('Sources/Slotstream/Machine.swift','    public init(\n        expertsPerLayer:', 'PlanRequest'),('Sources/Slotstream/Plan.swift','    public init(\n        source:', 'MemoryPlan'),('Sources/Slotstream/Governor.swift','        public init(\n            currentSlots:', 'GovernorPolicy.Inputs')]
refs=[]
def parameters(signature):
    inside=signature[signature.index('(')+1:signature.rindex(')')]
    return [(x.split(':',1)[0].strip(),x.split(':',1)[1].split('=',1)[0].strip()) for x in inside.split(',')]
def types(params,owner):
    mapping={'Source':'MemoryPlan.Source','Pressure':'GovernorPolicy.Pressure','MTPMode':'Planner.MTPMode','VisionMode':'Planner.VisionMode','ContextRetention':'Planner.ContextRetention'}
    return ', '.join(re.sub(r'(?<![\w.])('+'|'.join(mapping)+r')\b',lambda m:mapping[m[1]],t) for _,t in params)
for path,anchor,owner in specs:
    old=subprocess.check_output(['git','show','HEAD:'+path],text=True)
    start=old.index(anchor);end=old.index('{',start)
    sig=old[start:end]; params=parameters(sig)
    current=Path(path).read_text(); at=current.index(anchor); stop=current.index('{',at)
    header=current[at:stop].replace('memoryLimitGB: Double? = nil','memoryLimitGB: Double?')
    current=current[:at]+header+current[stop:]
    args=[name+': '+name for name,_ in params]
    insert=3 if owner=='PlanRequest' else len(args)
    args.insert(insert,'memoryLimitGB: nil')
    indent='        ' if owner=='GovernorPolicy.Inputs' else '    '
    wrapper=indent+'/// Preserve the original initializer, including its function-value type.\n'+sig+'{\n'+indent+'    self.init('+', '.join(args)+')\n'+indent+'}\n\n'
    current=current[:at]+wrapper+current[at:];Path(path).write_text(current)
    refs.append('        let legacy'+owner.replace('.','')+': ('+types(params,owner)+') -> '+owner+' = '+owner+'.init')
path='Sources/Slotstream/Plan.swift';old=subprocess.check_output(['git','show','HEAD:'+path],text=True);current=Path(path).read_text()
anchor='    public static func plan(\n        expertsPerLayer:'
positions=[m.start() for m in re.finditer(re.escape(anchor),old)]
for i,start in reversed(list(enumerate(positions))):
    sig=old[start:old.index('{',start)];params=parameters(sig)
    matches=[m.start() for m in re.finditer(re.escape(anchor),current)];at=matches[i];stop=current.index('{',at)
    header=current[at:stop].replace('memoryLimitGB: Double? = nil','memoryLimitGB: Double?')
    current=current[:at]+header+current[stop:]
    args=[name+': '+name for name,_ in params];args.insert(3,'memoryLimitGB: nil')
    wrapper='    /// Preserve the original callable signature for embedding clients.\n'+sig+'{\n        try plan('+', '.join(args)+')\n    }\n\n'
    current=current[:at]+wrapper+current[at:]
    refs.append('        let legacyPlanner'+str(i)+': ('+types(params,'Planner')+') throws -> MemoryPlan = Planner.plan')
Path(path).write_text(current)
p=Path('Tools/context_proxy.swift');s=p.read_text();anchor='    static func adaptiveBudgets() throws {\n'
refs.append('        _ = ('+', '.join(re.search(r'let (\w+)',x)[1] for x in refs)+')')
s=s.replace(anchor,anchor+'\n'.join(refs)+'\n');p.write_text(s)
Path('/tmp/memory-review3-legacy-signatures.swift').write_text('\n'.join(refs)+'\n')
