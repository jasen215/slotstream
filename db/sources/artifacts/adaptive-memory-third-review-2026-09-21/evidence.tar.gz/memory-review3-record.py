from pathlib import Path
import datetime,hashlib,json,subprocess
root=Path.cwd(); temp=Path('/tmp')
def read(name):return (temp/('memory-review3-'+name)).read_text()
identity=json.loads(read('final-binary.json')); binary=Path(identity['binary'])
assert hashlib.sha256(binary.read_bytes()).hexdigest()==identity['sha256']
cli=json.loads(read('cli.json'));assert cli['passed']
t0=json.loads(read('t0.json'));assert t0['failed']==0 and t0['skipped']==0
proxy=json.loads(read('final-proxy/report.json'));assert proxy['passed']
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in proxy['source_sha256'].items())
assert 'consumer ok:' in read('consumer.log')
live=json.loads(read('live-result.json'))
if live['attempted']:
    assert live['exit_code']==0,live
    server=json.loads(read('server/report.json'));assert server['passed'] and server['server_reaped']
    live_text='The rebuilt public server completed a request with a 9.99 GB saved limit after the real production timer passed its startup cooldown. Every observed plan retained that ceiling and stayed within it. Its child was reaped.'
else:
    live_text='The optional repeated public-server check was not run: another task held the normal model lock throughout the bounded two-minute wait. No process was interrupted and no lock was bypassed. This is an explicit gap in the third-pass rerun, not a passing live result.'
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
body=f'''---
type: run
meta-type: fact
created: {now}
updated: {now}
summary: Third memory review repairs Swift callable compatibility and contradictory direct adaptive plans, with external-package and engine-startup regressions.
binary: {identity['sha256']}
captured_at: 2026-09-21
command: Exact commands and raw outputs below and in the evidence archive
discarded: false
machines: '[[records/machines/macbook-pro-m5-pro-48gb]]'
title: Adaptive memory third adversarial review
tool: source review, external package consumer, policy contracts, public CLI and native runtime checks
---
# Adaptive memory third review

This extends [[sources/runs/2026/09/2026-09-21-adaptive-memory-second-review]]. It re-traces saved-limit references, plan constructors and transformations through CLI validation, launch/reuse, diagnostics, context selection, startup, vision admission, inference, governor recovery, native settings and persisted response details. The new concrete defects are at the Swift embedding boundary; ordinary CLI/app planner calls did not construct the malformed plans.

## Findings and corrections

Adding a defaulted parameter changes a Swift function's full type. The first reproduction failed to compile original function-value references, even though ordinary calls still compiled. The existing external consumer's loose planner reference also exposed this regression. Preserve all six old callable signatures: the three initializers for PlanRequest, MemoryPlan and GovernorPolicy.Inputs, and the three loose Planner.plan overloads. Their wrappers delegate with no adaptive limit. New adaptive overloads require that argument explicitly, avoiding ambiguity in ordinary calls that omit it.

A manually constructed plan could pair a 10 GB adaptive ceiling with an 11 GB target, no target, or a fixed-pool source and still pass shared validation when the cache itself was small. The before-policy reproduction has exactly three new failed assertions. Shared adaptive-policy validation now requires an automatic source and a finite positive target within the finite saved ceiling. Engine startup applies that validation even to a conflicting source, and vision replanning validates before its early return. Image and inference admission also include the saved ceiling in their comparisons.

The external consumer compiles through actual package products, checks all six legacy callable types, and constructs all three malformed plans through the real Engine initializer with a nonexistent checkpoint path. Each is rejected as an invalid adaptive policy before a model is opened. This check loads no weights.

## Evidence and results

[Raw archive](../../../artifacts/adaptive-memory-third-review-2026-09-21/evidence.tar.gz) preserves the before-fix counterexamples, source snapshots, audit matrix, build logs and final reports. [Manifest](../../../artifacts/adaptive-memory-third-review-2026-09-21/manifest.json) records member hashes and lengths; all members were reopened and verified. Executables and model weights are excluded.

Frozen CLI: `{binary.relative_to(root)}`, SHA-256 `{identity['sha256']}`. The final pure-policy source hashes match the checkout. The checkout also contains concurrent unrelated work; HEAD at evidence capture is `{head}`, and the tested dirty sources are recorded independently. This receipt does not certify unrelated changes.

Final software results: {cli['cases']} public CLI cases; {proxy['contracts']['assertions']} pure assertions, including {proxy['contracts']['gates']['M01']} memory assertions; {t0['passed']} T0 groups and {sum(len(c.get('items',[])) for c in t0['checks'])} assertions, with no failures or skips. The external package passes. Native policy and response-persistence checks pass. Harness checks pass for consumer cleanup (4), planner harness (7), and verification dispatch (22). Claims, generated projections and whitespace checks pass.

{live_text}

The previous receipt retains the completed small/full shrink-and-recovery drills, fractional and pinned server requests, real native deferred change/reload/idle lifecycle, and eight light/dark UI renders. Those are prior results, not newly repeated tests. This pass changes API overloads and validation, not the governor's growth decision or native UI implementation. New native policy checks exercise the changed planning API.

Commands from the repository root:

```sh
python3 Tools/context_proxy.py --out /tmp/memory-review3-final-proxy
bash Tools/consumer_smoke.sh
swift build -c release --product slotstream -j 2
python3 Tools/memory_override_gate.py --binary {binary.relative_to(root)} --out /tmp/memory-review3-cli.json
swift build -c release --product slotstream-checks -j 2
.build/release/slotstream-checks --tier t0 --json
swift build --package-path apps/macos --product sevra-mac-checks -j 2
apps/macos/.build/debug/sevra-mac-checks --performance
apps/macos/.build/debug/sevra-mac-checks --response-details
python3 /tmp/memory-review3-live-driver.py
```

The bounded live driver, exact child command if launched, and result ride in the archive. Reclaimable-memory preflights precede builds; the optional server gate also checks real headroom and the shared model lock. No memory hog is used. Larger hardware is simulated. Real allocation on a 64 GiB Mac, the complete release battery, and a published release remain outside this evidence.
'''
for title,name in [('External package','consumer.log'),('Native policy','native-performance.log'),('Native response details','native-response-details.log'),('Live rerun status','live-result.json'),('Original callable-type failure','compat-before/compile.log'),('Malformed-plan counterexample','before-policy/contracts.stdout.json'),('Final pure policy','final-proxy/contracts.stdout.json')]:
    body+='\n## '+title+'\n\n```text\n'+read(name).rstrip()+'\n```\n'
p=root/'db/sources/runs/2026/09/2026-09-21-adaptive-memory-third-review.md'
assert not p.exists();p.write_text(body)
print(p)
