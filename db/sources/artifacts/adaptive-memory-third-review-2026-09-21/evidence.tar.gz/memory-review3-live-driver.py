import fcntl,os,subprocess,time,json
from pathlib import Path
end=time.monotonic()+120
while True:
    with open(f"/tmp/slotstream-model-{os.getuid()}.lock", "a+") as lock:
        try:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            ready=True
            fcntl.flock(lock,fcntl.LOCK_UN)
        except BlockingIOError:
            ready=False
    if ready:
        command=["python3","Tools/adaptive_memory_e2e.py","--binary",".build/memory-review3-final-0vxi9m7d/slotstream","--limit-gb","9.99","--out","/tmp/memory-review3-server"]
        result=subprocess.run(command)
        Path("/tmp/memory-review3-live-result.json").write_text(json.dumps({"attempted":True,"exit_code":result.returncode,"command":command})+"\n")
        raise SystemExit(result.returncode)
    if time.monotonic()>=end:
        result={"attempted":False,"reason":"Normal model lock remained occupied by another task for the bounded two-minute wait; no process interrupted."}
        Path("/tmp/memory-review3-live-result.json").write_text(json.dumps(result)+"\n")
        print(json.dumps(result),flush=True)
        raise SystemExit(0)
    time.sleep(2)
