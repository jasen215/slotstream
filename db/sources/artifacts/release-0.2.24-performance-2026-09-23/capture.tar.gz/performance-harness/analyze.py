"""Pair matched release runs, keep every exclusion, require three pairs for gain claims."""
import argparse,json,statistics
from pathlib import Path
PLAN_KEYS=['pool_slots','prefill_chunk','max_context_tokens','target_gb','mtp','decode_lookahead']
def paired(old,new,control=False):
    reasons=[]
    for label,row in [('old',old),('new',new)]:
        if not row['environment_eligible']:reasons.append(label+': '+', '.join(row.get('environment_exclusions',row.get('exclusions',[]))))
    a=old.get('runtime_plan',old.get('plan_after'));b=new.get('runtime_plan',new.get('plan_after'))
    if any(a[k]!=b[k] for k in PLAN_KEYS):reasons.append('different effective plans')
    if not old['strict_global_swap_eligible'] or not new['strict_global_swap_eligible']:
        reasons.append('global paging observed; timing remains diagnostic')
    same_ids=None
    if control:
        same_ids=all(old['metrics'][k]==new['metrics'][k] for k in ['prompt_ids','output_ids'])
        if not same_ids:reasons.append('prompt/output IDs differ')
        if old['metrics']['stats']['reusedPrefixTokens']!=new['metrics']['stats']['reusedPrefixTokens']:reasons.append('different control reuse')
    else:
        if old['request']!=new['request']:reasons.append('different request bytes')
    return {'eligible':not reasons,'exclusions':reasons,'same_control_ids':same_ids,
            'old_seconds':old['client_seconds'],'new_seconds':new['client_seconds'],
            'old_decode_tps':old.get('decode_tps'),'new_decode_tps':new.get('decode_tps'),
            'decode_speedup_fraction':(new['decode_tps']/old['decode_tps']-1) if control and old.get('decode_tps') and new.get('decode_tps') else None,
            'time_reduction_fraction':1-new['client_seconds']/old['client_seconds'],
            'old_first_argument_value_seconds':old.get('first_argument_value_seconds'),'new_first_argument_value_seconds':new.get('first_argument_value_seconds'),
            'old_arguments_events':old.get('argument_events'),'new_arguments_events':new.get('argument_events'),
            'old_usage':old.get('usage'),'new_usage':new.get('usage'),
            'same_answer':old['text']==new['text'],'same_reasoning':old.get('reasoning')==new.get('reasoning'),
            'strict_global_swap_eligible':old['strict_global_swap_eligible'] and new['strict_global_swap_eligible']}

def summarize(rows):
    eligible=[r for r in rows if r['eligible']]
    return {'pairs':rows,'eligible_pairs':len(eligible),'gain_claim_qualified':len(eligible)>=3,
            'median_decode_speedup_fraction':statistics.median(x['decode_speedup_fraction'] for x in eligible) if len(eligible)>=3 and all(x['decode_speedup_fraction'] is not None for x in eligible) else None,
            'median_old_seconds':statistics.median(x['old_seconds'] for x in eligible) if eligible else None,
            'median_new_seconds':statistics.median(x['new_seconds'] for x in eligible) if eligible else None,
            'median_paired_time_reduction_fraction':statistics.median(x['time_reduction_fraction'] for x in eligible) if len(eligible)>=3 else None}

def main():
    a=argparse.ArgumentParser();a.add_argument('root',type=Path);args=a.parse_args();report={}
    cells={f'{name}/{stage}':f'{name}/{stage}-result.json' for name in ['code2048','prose2048'] for stage in ['prefill_miss','repeat']}
    cells.update({name:f'{name}/result.json' for name in ['warmup','long-truncated-argument','nullable-truncated-argument','nullable-numeric-string','branch-alpha-seed','branch-beta-seed','branch-alpha-followup','branch-restart']})
    for name,path in cells.items():
        rows=[]
        for n in range(1,4):
            paths=[args.root/f'r{n}-{v}'/path for v in ['old','new']]
            if not all(p.exists() for p in paths):continue
            x,y=[json.loads(p.read_text()) for p in paths];rows.append({'round':n,**paired(x,y,control=name.startswith(('code','prose')))})
        report[name]=summarize(rows)
    (args.root/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:{a:b for a,b in v.items() if a!='pairs'} for k,v in report.items()},indent=2))
if __name__=='__main__':main()
