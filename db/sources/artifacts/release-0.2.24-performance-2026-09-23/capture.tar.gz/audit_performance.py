import json,pathlib,hashlib,statistics,sys,math
base=pathlib.Path(__file__).resolve().parent;root=base/'performance';p=json.loads((base/'performance-protocol-v3.json').read_text())
for name,h in p['files'].items():assert hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==h,name
sys.path.insert(0,str(base/'performance-harness'));from compare import decode_events
rows=[];validation=[];servers=[]
for session in sorted(root.glob('r*-*')):
 receipt=json.loads((session/'receipt.json').read_text());assert receipt['passed'] and receipt['completed_requests']==12
 assert all(s['reaped'] and s['exit_code']==0 for s in receipt['servers']);servers+=receipt['servers']
 for path in sorted(session.rglob('*result.json')):
  d=json.loads(path.read_text());control='metrics' in d
  if control:
   stage=path.name.removesuffix('-result.json');raw=path.with_name(stage+'-response.ndjson')
   frames=[json.loads(line) for line in raw.read_text().splitlines() if line.strip()]
   assert sum(bool(f.get('done')) for f in frames)==1 and frames[-1]['done']
   assert not any('error' in f for f in frames)
   assert {'schema_version':1,**frames[-1]['slotstream_benchmark']}==d['metrics']
   assert ''.join(f.get('response','') for f in frames)==d['text']
   assert len(d['metrics']['output_ids'])==128 and d['metrics']['stats']['decodeTokens']==128
  else:
   raw=path.with_name('response.sse');events=[]
   for line in raw.read_text().splitlines():
    if line.startswith('data: '):events.append('[DONE]' if line[6:].strip()=='[DONE]' else json.loads(line[6:]))
   assert events==d['events'] and len(events)==len(d['arrivals'])
   assert d['arrivals']==sorted(d['arrivals']) and d['arrivals'][-1]<=d['client_seconds']
   assert json.loads(path.with_name('request.json').read_text())==d['request']
   replay=decode_events(events,d['arrivals']);assert all(d[k]==v for k,v in replay.items())
  assert math.isfinite(d['client_seconds']) and d['client_seconds']>0
  rows.append((str(path.relative_to(root)),d));validation.append(str(path.relative_to(root)))
assert len(rows)==72 and len(servers)==12
pairs=[]
for n in range(1,4):
 for f in ['code2048','prose2048']:
  for stage in ['prefill_miss','repeat']:
   a,b=[json.loads((root/f'r{n}-{v}'/f/(stage+'-result.json')).read_text()) for v in ['old','new']]
   same=all(a['metrics'][k]==b['metrics'][k] for k in ['prompt_ids','output_ids'])
   assert same
   pairs.append({'round':n,'fixture':f,'stage':stage,'exact_ids':same,'old_reuse':a['metrics']['stats']['reusedPrefixTokens'],'new_reuse':b['metrics']['stats']['reusedPrefixTokens']})
summary={}
for version in ['old','new']:
 cases={}
 for case in ['long-truncated-argument','nullable-truncated-argument','nullable-numeric-string','branch-alpha-followup','branch-restart']:
  ds=[json.loads((root/f'r{n}-{version}'/case/'result.json').read_text()) for n in range(1,4)]
  cases[case]={'client_seconds':[d['client_seconds'] for d in ds],
    'first_argument_value_seconds':[d['first_argument_value_seconds'] for d in ds],
    'argument_events':[d['argument_events'] for d in ds],
    'usage':[d['usage'] for d in ds],
    'arguments':[d['arguments'] for d in ds] if case=='nullable-numeric-string' else None,
    'strict_global_swap_eligible':[d['strict_global_swap_eligible'] for d in ds]}
 summary[version]=cases
for n in range(1,4):
 for seed in ['branch-alpha-seed','branch-beta-seed']:
  ds=[json.loads((root/f'r{n}-{v}'/seed/'result.json').read_text()) for v in ['old','new']]
  assert all(ds[0][k]==ds[1][k] for k in ['text','reasoning','usage'])
 for version in ['old','new']:
  d=json.loads((root/f'r{n}-{version}'/'branch-alpha-followup/result.json').read_text())
  assert d['usage']['prompt_tokens_details']['cached_tokens']==(1024 if version=='old' else 1280)
  assert d['usage']['prompt_tokens']==(1541 if version=='old' else 1597)
  d=json.loads((root/f'r{n}-{version}'/'nullable-truncated-argument/result.json').read_text())
  assert d['argument_events']==(0 if version=='old' else 239)
  d=json.loads((root/f'r{n}-{version}'/'nullable-numeric-string/result.json').read_text())
  assert json.loads(d['arguments'])['content']==(123 if version=='old' else '00123')
report={'passed':True,'raw_replays':validation,'request_count':72,'control_pairs':pairs,'servers':servers,'functional_summary':summary,
 'primary_environment_eligible':sum(d['environment_eligible'] for _,d in rows),'strict_global_swap_eligible':sum(d['strict_global_swap_eligible'] for _,d in rows),
 'environment_exclusions':{name:d.get('environment_exclusions',d.get('exclusions',[])) for name,d in rows if not d['environment_eligible']},
 'all_prior_method_files_unchanged_during_measurement':True,
 'headline_policy':'Warmup has one output token and is excluded from performance claims regardless of its mechanical pair count. No measured test family has three strict eligible pairs; no general latency or decode-throughput percentage is qualified. Counts and type correctness are functional findings.',
 'uncached_branch_input':{'old':517,'new':317,'reduction_tokens':200,'reduction_fraction':1-317/517,'scope':'Preserves more valid reasoning; not equal model input and not a GPU-throughput improvement.'}}
(base/'performance-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['raw_replays','control_pairs','servers','functional_summary']},indent=2))
