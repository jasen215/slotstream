"""Frozen matched public-release serving comparison; runs after publication only."""
import argparse,hashlib,http.client,json,os,socket,subprocess,time
from pathlib import Path
import release_speed_bench as b
from prefill_bench import preflight,vm_snapshot,digest
from serve_bench import verified_build,wait_ready,stop_server,competing_jobs
ROOT=Path(__file__).resolve().parent

def decode_events(events,arrivals):
    text=reasoning=arguments='';finish=usage=None;first=first_arg=None;argument_arrivals=[]
    for e,t in zip(events,arrivals):
        if not isinstance(e,dict):continue
        assert 'error' not in e,e
        for c in e.get('choices',[]):
            d=c.get('delta',{});text+=d.get('content','');reasoning+=d.get('reasoning_content','')
            if first is None and (d.get('content') or d.get('reasoning_content')):first=t
            finish=c.get('finish_reason') or finish
            for call in d.get('tool_calls',[]):
                fragment=call.get('function',{}).get('arguments','')
                if fragment:
                    arguments+=fragment;argument_arrivals.append(t)
                    # A JSON key/header alone is not delivery of the generated argument.
                    if first_arg is None and arguments.startswith('{"content":"') and len(arguments)>len('{"content":"'):first_arg=t
        usage=e.get('usage') or usage
    assert events[-1]=='[DONE]' and finish in ['length','stop','tool_calls'] and usage
    return dict(text=text,reasoning=reasoning,arguments=arguments,finish=finish,usage=usage,
                first_content_or_thought_seconds=first,first_argument_value_seconds=first_arg,
                argument_events=len(argument_arrivals),argument_arrival_span_seconds=(argument_arrivals[-1]-argument_arrivals[0]) if argument_arrivals else 0)

def sse(port,body,output):
    c=http.client.HTTPConnection('127.0.0.1',port,timeout=600);events=[];arrivals=[];start=time.monotonic()
    try:
        c.request('POST','/v1/chat/completions',json.dumps(body),{'Content-Type':'application/json'});r=c.getresponse()
        with output.open('wb') as raw:
            while line:=r.readline(1<<20):
                raw.write(line);raw.flush()
                if line.startswith(b'data: '):
                    value=line[6:].strip();events.append('[DONE]' if value==b'[DONE]' else json.loads(value));arrivals.append(time.monotonic()-start)
        assert r.status==200,r.status
        result=decode_events(events,arrivals);result.update(client_seconds=time.monotonic()-start,events=events,arrivals=arrivals)
        return result
    finally:c.close()

def ready(out,p,child=None):
    try:r=b.settle(p['probe'],10 if child else 60,0 if child else 13,300,lock_required=child is None,model_pid=child.pid if child else None)
    except Exception as e:
        if hasattr(e,'observations'):b.save(out,e.observations)
        raise
    b.save(out,r)

def request(child,port,name,body,session,p):
    cell=session/name;cell.mkdir();ready(cell/'readiness.json',p,child)
    b.save(cell/'request.json',body);plan0=b.runtime_plan(port);vm0=vm_snapshot();own0=b.probe(p['probe'],child.pid)
    with b.Monitor(child,p['probe'],10_000_000_000) as monitor:
        result=sse(port,body,cell/'response.sse')
    plan1=b.runtime_plan(port);vm1=vm_snapshot();own1=b.probe(p['probe'],child.pid)
    reasons=b.environment_reasons(vm0,vm1,own0,own1,monitor.samples)
    if monitor.abort:reasons.append(monitor.abort)
    if any(x.get('known_jobs') for x in monitor.samples) or competing_jobs():reasons.append('known competing job')
    if any(plan0[k]!=plan1[k] for k in ['pool_slots','prefill_chunk','max_context_tokens','target_gb','mtp','decode_lookahead']):reasons.append('plan changed')
    if any('probe_error' in x for x in monitor.samples):reasons.append('resource sample failed')
    result.update(name=name,request=body,before=vm0,after=vm1,own_before=own0,own_after=own1,samples=monitor.samples,
                  plan_before=plan0,plan_after=plan1,environment_exclusions=sorted(set(reasons)),environment_eligible=not reasons,
                  strict_global_swap_eligible=not reasons and vm0['swapins']==vm1['swapins'])
    b.save(cell/'result.json',result)
    b.emit({k:result[k] for k in ['name','client_seconds','first_argument_value_seconds','argument_events','usage','environment_eligible','environment_exclusions']})
    return result

def session(p,version,round_number,out):
    directory=out/f'r{round_number}-{version}';directory.mkdir();binary=p['binaries'][version]['path'];child=log=None;rows=[]
    receipt={'version':version,'round':round_number,'passed':False,'servers':[]}
    def stop():
        nonlocal child,log
        if child is not None:
            stop_server(child);receipt['servers'].append({'pid':child.pid,'exit_code':child.returncode,'reaped':True});child=None
        if log:log.close();log=None
    def start(label):
        nonlocal child,log
        ready(directory/(label+'-readiness.json'),p);preflight(13)
        with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
        command=[binary,'serve','--model',p['model'],'--memory-gb','10','--max-context','32768','--vision','off','--mtp','off','--port',str(port),'--prefix-cache-dir',str(directory/'cache'),'--prefix-cache-min-tokens','512']
        env={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','SS_DEBUG'))};env['SLOTSTREAM_BENCH_DETAILS']='1'
        b.save(directory/(label+'-command.json'),command);log=(directory/(label+'-server.log')).open('w')
        child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True);wait_ready(child,port)
        return port
    def req(name,body):
        x=request(child,port,name,body,directory,p);rows.append(x);return x
    try:
        port=start('first')
        common={'model':'qwen3.8-flash-next:4bit','temperature':0,'seed':42,'stream':True,'stream_options':{'include_usage':True}}
        # Identical warmup and within-session history for paired versions. Controls rotate by round.
        req('warmup',common|{'messages':[{'role':'user','content':'Reply with exactly OK.'}],'max_tokens':8})
        controls=['code2048','prose2048'];controls=controls[::-1] if round_number%2==0 else controls
        for name in controls:
            entry={'id':name,'kind':name[:-4],'path':str(ROOT/'fixtures'/(name+'.txt'))}
            profile={'id':'budget10','ceiling_gb':10};settings={'probe':p['probe'],'request_timeout_seconds':600,'minimum_decode_tokens':16}
            cell=directory/name;cell.mkdir()
            for stage in ['prefill_miss','repeat']:
                ready(cell/(stage+'-readiness.json'),p,child)
                result=b.request(child,port,entry,16,profile,settings,cell,stage,round_number);rows.append(result)
        for name in ['long-truncated-argument','nullable-truncated-argument']:
            body=json.loads((ROOT/'fixtures'/(name+'.json')).read_text());req(name,body)
        number=json.loads((ROOT/'fixtures/nullable-truncated-argument.json').read_text())
        number['messages']=[{'role':'user','content':'Call save_page with content exactly 00123. Preserve every leading zero.'}];number['max_tokens']=64
        numeric=req('nullable-numeric-string',number)
        for name in ['branch-alpha-seed','branch-beta-seed','branch-alpha-followup']:
            branch=req(name,json.loads((ROOT/'fixtures'/(name+'.json')).read_text()))
        if version=='new':
            assert json.loads(numeric['arguments'])=={'content':'00123'},numeric['arguments']
            assert branch['usage']['prompt_tokens_details']['cached_tokens']>=1280,branch['usage']
        stop();port=start('restart')
        restart=req('branch-restart',json.loads((ROOT/'fixtures/branch-alpha-followup.json').read_text()))
        if version=='new':
            assert (restart['text'],restart['reasoning'])==(branch['text'],branch['reasoning']),'restart changed the generated message'
            assert all(restart['usage'][k]==branch['usage'][k] for k in ['prompt_tokens','completion_tokens']),'restart changed prompt/output counts'
        # Reuse may advance on the replay because the preceding request saved a later checkpoint.
        receipt['passed']=True
    except Exception as e:
        receipt['error']=repr(e);raise
    finally:
        stop();receipt['completed_requests']=len(rows);b.save(directory/'receipt.json',receipt)

def main():
    a=argparse.ArgumentParser();a.add_argument('--protocol',type=Path,required=True);a.add_argument('--out',type=Path,required=True);v=a.parse_args();p=json.loads(v.protocol.read_text())
    for path,h in p['files'].items():assert digest(path)==h,path
    for arm in p['binaries'].values():assert verified_build(arm['path'])['identity']['binary_sha256']==arm['sha256']
    v.out.mkdir(exist_ok=False);b.save(v.out/'protocol.json',p)
    for n,order in enumerate([['old','new'],['new','old'],['old','new']],1):
        for version in order:session(p,version,n,v.out)
    b.save(v.out/'completion.json',{'passed':True,'sessions':6})
if __name__=='__main__':main()
