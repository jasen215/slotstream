import Foundation
import Slotstream

func tool(_ shape: JSONValue) -> ToolDefinition {
    ToolDefinition(name: "save_page", description: "Save text.", parameters: .object([
        "type": .string("object"),
        "properties": .object(["content": shape]),
        "required": .array([.string("content")])]))
}
let forms: [(String, JSONValue)] = [
    ("string", .object(["type": .string("string")])),
    ("anyOf", .object(["anyOf": .array([.object(["type": .string("string")]), .object(["type": .string("null")])])])),
    ("type-array", .object(["type": .array([.string("string"), .string("null")])]))
]
for (name, shape) in forms {
    let definition = tool(shape)
    let parser = ToolCallSplitter(tools: [definition.schema])
    var events = parser.push("<tool_call><function=save_page><parameter=content>\n")
    for _ in 0..<200 { events += parser.push("0123456789") }
    let deltasBeforeClose = events.filter { if case .toolInputDelta = $0 { return true }; return false }.count
    let numeric = ToolCallSplitter.parseAll("<tool_call><function=save_page><parameter=content>\n00123\n</parameter></function></tool_call>", tools: [definition.schema])
    let calls = numeric.compactMap { event -> ParsedToolCall? in if case .toolCall(let call) = event { return call }; return nil }
    print(name, "kind", definition.schema.params["content"]!.rawValue,
          "argument_deltas_before_close", deltasBeforeClose, "numeric_argument", calls[0].inputJSON)
    if name == "type-array" {
        precondition(deltasBeforeClose == 0)
        precondition(calls[0].arguments["content"] == .int(123))
    } else {
        precondition(deltasBeforeClose > 190)
        precondition(calls[0].arguments["content"] == .string("00123"))
    }
}
print("REPRODUCED: nullable type-array strings buffer until close and numeric-looking strings lose their declared type and leading zeros")
