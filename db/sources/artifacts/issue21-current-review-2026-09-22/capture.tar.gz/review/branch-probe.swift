import Foundation
import Slotstream

// Metadata-only states: no weights, tensors or inference are loaded. Exercise
// the real cache selector and the real assistant-turn compatibility check.
let producer = [1, 2]
let wanted = producer + [11, 99, 21]
let other = producer + [12, 99, 22, 23, 24]
let cache = PrefixCache(maxTokens: 100)
for ids in [wanted, other] {
    let state = Qwen4ExpModel.State()
    state.tokenCount = ids.count
    cache.store(state: state, tokens: ids)
}
precondition(cache.heldTokens == wanted.count + other.count)
let selected = cache.peek(extending: producer)!
let selectedTurn = Engine.assistantTurnIds(in: selected, after: producer.count, turnEnd: [99])
let expected = ChatMessage(role: "assistant", content: "Wanted answer.")
let selectedText = selectedTurn == [11] ? "Wanted answer." : "Different answer."
precondition(selected == other)
precondition(!Engine.spliceDescribes(selectedText, expected, tools: []))
precondition(Engine.spliceDescribes("Wanted answer.", expected, tools: []))
print("REPRODUCED: both branches retained; longest branch selected; it fails the requested turn; compatible shorter branch is never tried")

var diskA = PersistentPrefixEntry(file: "a", identity: "same", tokens: producer, bytes: 1, lastUsed: 0)
diskA.splicingTokens = wanted
var diskB = PersistentPrefixEntry(file: "b", identity: "same", tokens: producer + [12], bytes: 1, lastUsed: 0)
diskB.splicingTokens = other
let selectedDisk = PersistentPrefixPolicy.longestExtension([diskA, diskB], identity: "same", of: producer, now: 0, maxAge: nil)
precondition(selectedDisk == other)
print("REPRODUCED: persistent conversation metadata has the same longest-branch selection")
