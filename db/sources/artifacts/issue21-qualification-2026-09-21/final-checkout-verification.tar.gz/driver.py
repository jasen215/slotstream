from pathlib import Path
import json,os,subprocess,sys,time,shutil
repo=Path('/Users/carlos/Projects/slotstream')
sys.path.insert(0,str(repo/'Tools'))
from context_qualification import quiet_preflight
root=Path('/tmp/slotstream-issue21-checkout');root.mkdir(exist_ok=False)
results=[]
def run(name,command):
 print('START',name,flush=True)
 end=time.monotonic()+300
 while True:
  try:quiet_preflight(13);break
  except Exception:
   if time.monotonic()>end:raise
   time.sleep(2)
 start=time.monotonic()
 with (root/(name+'.log')).open('w') as out:
  code=subprocess.call(command,cwd=repo,stdout=out,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':command,'exit_code':code,'seconds':time.monotonic()-start})
 (root/'results.json').write_text(json.dumps(results,indent=2))
 print('PASS' if code==0 else 'FAIL',name,flush=True)
 if code:raise SystemExit(code)
result=Path('/tmp/slotstream-issue21-qualified/long131k/result.json')
end=time.monotonic()+2400
while not result.exists():
 if time.monotonic()>end:raise RuntimeError('long-context wait expired')
 time.sleep(2)
if not json.loads(result.read_text())['passed']:raise RuntimeError('long-context test needs investigation')
build=Path('/tmp/slotstream-issue21-checkout-build')
run('build',['python3','Tools/optimization_build.py','--out',str(build),'--wait-for-model-seconds','300','--jobs','2'])
run('t0',[str(build/'candidate/slotstream-checks'),'--tier','t0','--json'])
run('runtime',[str(build/'candidate/slotstream'),'runtime-check'])
live=root/'live';live.mkdir();(live/'bin').symlink_to(build/'candidate',target_is_directory=True)
script=Path('/tmp/slotstream-issue21-live-current.py').read_text().replace('/tmp/slotstream-issue21-qualified/live',str(live))
(root/'run-live.py').write_text(script)
run('live',['python3',str(root/'run-live.py')])
print('CHECKOUT VERIFICATION COMPLETE',flush=True)
