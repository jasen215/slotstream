from pathlib import Path
import json,os,subprocess,sys,time,shutil,hashlib
repo=Path('/Users/carlos/Projects/slotstream')
sys.path.insert(0,str(repo/'Tools'))
from prefill_bench import preflight,terminate_child_tree
from context_qualification import quiet_preflight
root=Path('/tmp/slotstream-issue21-qualified/qualification');root.mkdir(parents=True,exist_ok=True)
bin=Path('/tmp/slotstream-issue21-qualified-build/candidate')
env=os.environ.copy();env['SLOTSTREAM_TEST_BINARY']=str(bin/'slotstream');env['SLOTSTREAM_VERIFY_OUT']=str(root/'verify')
results=[]
driver_hashes={}
for source in sorted((repo/'Tools').rglob('*')):
 if source.is_file() and source.suffix in ('.py','.sh'):
  rel=source.relative_to(repo); dest=root/'drivers'/rel
  dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
  driver_hashes[str(rel)]=hashlib.sha256(source.read_bytes()).hexdigest()
(root/'driver-hashes.json').write_text(json.dumps(driver_hashes,indent=2))
shutil.copyfile(__file__,root/'qualify.py')
def run(name,cmd,timeout=1800,heavy=True):
 print('START',name,flush=True)
 if heavy:
  deadline=time.monotonic()+300
  while True:
   try:quiet_preflight(13);break
   except Exception:
    if time.monotonic()>deadline:raise
    time.sleep(2)
 begin=time.monotonic()
 with (root/(name+'.log')).open('w') as out:
  proc=subprocess.Popen(cmd,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=proc.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   terminate_child_tree(proc);code=-999
 result={'name':name,'command':cmd,'exit_code':code,'seconds':time.monotonic()-begin}
 results.append(result);(root/'results.json').write_text(json.dumps(results,indent=2))
 print('PASS' if code==0 else 'FAIL',name,'exit',code,flush=True)
 return code==0
while not Path('/tmp/slotstream-issue21-long/result.json').exists():time.sleep(2)
if not json.loads(Path('/tmp/slotstream-issue21-long/result.json').read_text())['passed']:
 print('Long-context counterexample needs investigation first',flush=True);sys.exit(1)
run('t0',[str(bin/'slotstream-checks'),'--tier','t0','--json'])
run('runtime',[str(bin/'slotstream'),'runtime-check'])
run('t1',[str(bin/'slotstream-checks'),'--tier','t1','--json'])
for variant in ['context-serving','output-serving','governor-boundary','governor-boundary-mtp','persistent-prefix','persistent-prefix-mtp']:
 run(variant,[str(bin/'slotstream'),'optimization-state-check','--variant',variant,'--json'])
run('full-verify',['bash','Tools/verify.sh'],timeout=7200)
(root/'driver-changes.json').write_text(json.dumps([rel for rel,digest in driver_hashes.items() if hashlib.sha256((repo/rel).read_bytes()).hexdigest()!=digest]))
print('QUALIFICATION FINISHED',json.dumps(results),flush=True)

sys.exit(0 if all(item['exit_code']==0 for item in results) else 1)
