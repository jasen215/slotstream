from pathlib import Path
import json,os,subprocess,sys,time
repo=Path('/Users/carlos/Projects/slotstream')
sys.path.insert(0,str(repo/'Tools'))
from context_qualification import quiet_preflight
build=Path('/tmp/slotstream-issue21-qualified-build')
root=Path('/tmp/slotstream-issue21-qualified');root.mkdir(exist_ok=False)
results=[]
def run(name,command,env=None):
 print('START',name,flush=True)
 deadline=time.monotonic()+600
 while True:
  try:quiet_preflight(16.5 if name=='long131k' else 13);break
  except Exception as error:
   if time.monotonic()>deadline:raise
   print('WAIT',name,str(error),flush=True);time.sleep(10)
 begin=time.monotonic()
 with (root/(name+'.log')).open('w') as out:
  code=subprocess.call(command,cwd=repo,stdout=out,stderr=subprocess.STDOUT,env=env)
 results.append({'name':name,'command':command,'exit_code':code,'seconds':time.monotonic()-begin})
 (root/'results.json').write_text(json.dumps(results,indent=2))
 print('PASS' if code==0 else 'FAIL',name,flush=True)
 return code==0
end=time.monotonic()+600
while not (build/'candidate/build-identity.json').exists():
 if time.monotonic()>end:raise RuntimeError('build wait expired')
 time.sleep(2)
binary=build/'candidate/slotstream'
env=os.environ.copy();env['SLOTSTREAM_TEST_BINARY']=str(binary)
run('qualification',['python3','/tmp/slotstream-issue21-qualify-current.py'])
live=Path('/tmp/slotstream-issue21-qualified/live');live.mkdir(exist_ok=False)
(live/'bin').symlink_to(build/'candidate',target_is_directory=True)
run('live',['python3','/tmp/slotstream-issue21-live-current.py'])
run('long131k',['python3','Tools/issue21_long_context.py','--binary',str(binary),'--out','/tmp/slotstream-issue21-qualified/long131k','--max-context','131072'])
print('COMPLETE',json.dumps(results),flush=True)
sys.exit(0 if all(item['exit_code']==0 for item in results) else 1)
