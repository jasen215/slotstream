from pathlib import Path
import json,os,subprocess,sys,time
repo=Path('/Users/carlos/Projects/slotstream')
sys.path.insert(0,str(repo/'Tools'))
from prefill_bench import preflight,terminate_child_tree
root=Path('/tmp/slotstream-issue21-qualification');root.mkdir(exist_ok=True)
bin=Path('/tmp/slotstream-issue21-requalification-build/candidate')
env=os.environ.copy();env['SLOTSTREAM_TEST_BINARY']=str(bin/'slotstream');env['SLOTSTREAM_VERIFY_OUT']=str(root/'verify')
results=[]
def run(name,cmd,timeout=1800,heavy=True):
 print('START',name,flush=True)
 if heavy:
  deadline=time.monotonic()+300
  while True:
   try:preflight(13);break
   except Exception:
    if time.monotonic()>deadline:raise
    time.sleep(2)
 begin=time.monotonic()
 with (root/(name+'.log')).open('w') as out:
  proc=subprocess.Popen(cmd,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=proc.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   terminate_child_tree(proc);code=-999
 result={'name':name,'command':cmd,'exit_code':code,'seconds':time.monotonic()-begin}
 results.append(result);(root/'results.json').write_text(json.dumps(results,indent=2))
 print('PASS' if code==0 else 'FAIL',name,'exit',code,flush=True)
 return code==0
while not Path('/tmp/slotstream-issue21-long/result.json').exists():time.sleep(2)
if not json.loads(Path('/tmp/slotstream-issue21-long/result.json').read_text())['passed']:
 print('Long-context counterexample needs investigation first',flush=True);sys.exit(1)
run('t1',[str(bin/'slotstream-checks'),'--tier','t1','--json'])
for variant in ['context-serving','output-serving','governor-boundary','governor-boundary-mtp','persistent-prefix','persistent-prefix-mtp']:
 run(variant,[str(bin/'slotstream'),'optimization-state-check','--variant',variant,'--json'])
run('full-verify',['bash','Tools/verify.sh'],timeout=7200)
print('QUALIFICATION FINISHED',json.dumps(results),flush=True)
