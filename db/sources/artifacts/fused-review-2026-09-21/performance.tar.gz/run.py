from pathlib import Path
import sys,json,hashlib,subprocess,re,time,tarfile
root=Path(__file__).parent
source=Path('/tmp/slotstream-speed-20260921/mlx032')
binary=source/'.build/release/slotstream'
def vm():
    s=subprocess.check_output(['vm_stat'],text=True)
    size=int(re.search(r'page size of (\d+)',s)[1])
    d={k:int(v) for k,v in re.findall(r'^([^:\n]+):\s*(\d+)\.',s,re.M)}
    return dict(reclaimable_gb=sum(d[k] for k in ['Pages free','Pages purgeable','File-backed pages'])*size/1e9,
                swapins=d['Swapins'],swapouts=d['Swapouts'])
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
expected=json.loads((root/'source-before.json').read_text())
assert all(sha(source/k)==v for k,v in expected.items()),'source changed during build'
if not (root/'source.tar.gz').exists():
    with tarfile.open(root/'source.tar.gz','w:gz') as tar:
        for name in expected: tar.add(source/name,arcname=name)
    (root/'identity.json').write_text(json.dumps(dict(source=expected,binary_sha256=sha(binary),
        metallib_sha256=sha(binary.parent/'mlx.metallib'),source_archive_sha256=sha(root/'source.tar.gz')),indent=2)+'\n')
for variant in sys.argv[1:]:
    before=vm()
    assert before['reclaimable_gb']>=14,before
    assert subprocess.run(['pgrep','-x','slotstream'],capture_output=True).returncode==1,'other model process'
    assert 'swift-frontend' not in subprocess.check_output(['ps','-Ao','comm'],text=True),'compiler busy'
    command=[str(binary),'optimization-state-check','--variant',variant,'--model','/Users/carlos/.slotstream/models/qwen38-flash-next-mlx-4bit','--tokens','2051','--json']
    start=time.monotonic()
    with (root/(variant+'.json')).open('w') as out,(root/(variant+'.stderr')).open('w') as err:
        run=subprocess.run(command,stdout=out,stderr=err,timeout=1800)
    record=dict(command=command,before=before,after=vm(),exit=run.returncode,seconds=time.monotonic()-start,binary_sha256=sha(binary))
    (root/(variant+'-receipt.json')).write_text(json.dumps(record,indent=2)+'\n')
    report=json.loads((root/(variant+'.json')).read_text())
    print(json.dumps(dict(variant=variant,seconds=record['seconds'],checks=len(report['items']),failures=[x for x in report['items'] if not x['passed']])),flush=True)
