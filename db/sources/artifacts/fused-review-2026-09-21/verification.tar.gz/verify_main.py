from pathlib import Path
import subprocess,re,os,json,hashlib,time
root=Path(__file__).parent
repo=Path('/Users/carlos/Projects/slotstream')
def preflight():
    s=subprocess.check_output(['vm_stat'],text=True)
    size=int(re.search(r'page size of (\d+)',s)[1])
    d={k:int(v) for k,v in re.findall(r'^([^:\n]+):\s*(\d+)\.',s,re.M)}
    gb=sum(d[k] for k in ['Pages free','Pages purgeable','File-backed pages'])*size/1e9
    assert gb>=14,gb
    assert subprocess.run(['pgrep','-x','slotstream'],capture_output=True).returncode==1,'another model'
    assert 'swift-frontend' not in subprocess.check_output(['ps','-Ao','comm'],text=True),'another compiler'
    return dict(reclaimable_gb=gb,swapins=d['Swapins'],swapouts=d['Swapouts'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
commands=[('main-build',['make','build']),
          ('main-t0',['.build/release/slotstream-checks','--tier','t0','--json']),
          ('main-scope-diagnostic',['.build/release/slotstream','optimization-state-check','--variant','scope-larger-family','--model','/Users/carlos/.slotstream/models/qwen38-flash-next-mlx-4bit','--tokens','1024','--json'])]
receipts=[]
for name,command in commands:
    before=preflight();start=time.monotonic()
    with (root/(name+'.stdout')).open('w') as out,(root/(name+'.stderr')).open('w') as err:
        p=subprocess.run(command,cwd=repo,stdout=out,stderr=err,env=dict(os.environ,SLOTSTREAM_BUILD_JOBS='2'),timeout=900)
    receipts.append(dict(name=name,command=command,before=before,seconds=time.monotonic()-start,exit=p.returncode))
    (root/'main-verification-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
    print(name,p.returncode,flush=True)
    assert p.returncode==0,name
report=json.loads((root/'main-scope-diagnostic.stdout').read_text())
assert all(f'{label}.arm{arm}.greedy_token' in report['measurements'] for label in ['prefill','continued-907','continued-1337','continued-2103','rollback-1','rollback-2','rollback-3'] for arm in range(3))
assert len([k for k in report['measurements'] if k.endswith('.control_greedy_matches')])==7
for name in ['build-identity.json','build-source.tar.gz']:
    (root/('main-'+name)).write_bytes((repo/'.build/release'/name).read_bytes())
(root/'main-diagnostic-observability.json').write_text(json.dumps(dict(checks=len(report['items']),passed=report['passed'],token_measurements=21,control_match_measurements=7,binary_sha256=sha(repo/'.build/release/slotstream')),indent=2)+'\n')
print('new control observations present; original parity gates pass',flush=True)
