import os
os.environ['OPENBLAS_NUM_THREADS'] = '2'
os.environ['VECLIB_MAXIMUM_THREADS'] = '2'
import json, subprocess, re, time, hashlib
from pathlib import Path
import numpy as np
import mlx.core as mx

root = Path(__file__).parent
def vm():
    s = subprocess.check_output(['vm_stat'], text=True)
    size = int(re.search(r'page size of (\d+)', s)[1])
    d = {k:int(v) for k,v in re.findall(r'^([^:\n]+):\s*(\d+)\.',s,re.M)}
    return dict(reclaimable_gb=sum(d[k] for k in ['Pages free','Pages purgeable','File-backed pages'])*size/1e9,
                swapins=d['Swapins'], swapouts=d['Swapouts'])
assert vm()['reclaimable_gb'] >= 14
assert subprocess.run(['pgrep','-x','slotstream'], capture_output=True).returncode == 1
mx.set_cache_limit(64<<20)
record = {'mlx':mx.__version__, 'device':mx.metal.device_info(), 'before':vm(), 'cases':[],
          'method':'float64 NumPy reference from exactly the same BF16 inputs; 8 sampled rows across all 24 heads; no model-quality or speed claim'}
for seed in [11,29,47]:
    for rows,keys,kind in [(256,8192,'causal'),(256,8192,'sparse'),(256,32768,'sparse'),(259,8211,'sparse')]:
        rng = np.random.default_rng(seed)
        q,k,v = [mx.array(rng.normal(size=shape).astype(np.float32)).astype(mx.bfloat16)
                 for shape in [(1,24,rows,256),(1,2,keys,256),(1,2,keys,256)]]
        mask = np.zeros((rows,keys),bool)
        for r in range(rows):
            end = keys-rows+r+1
            if kind == 'causal': mask[r,:end]=True
            else:
                blocks = rng.choice(end//4, min(512,end//4), replace=False)
                mask[r,(blocks[:,None]*4+np.arange(4)).reshape(-1)] = True
                mask[r,(end//4)*4:end] = True
        m = mx.array(mask[None,None])
        outputs = [mx.fast.scaled_dot_product_attention(q,k,v,scale=1/16,
                    mask='causal' if kind=='causal' else m,force_fused=f) for f in [False,True]]
        mx.eval(q,k,v,*outputs)
        qn,kn,vn = [np.array(x.astype(mx.float32)) for x in [q,k,v]]
        selected = np.unique(np.linspace(0,rows-1,8,dtype=int))
        ref = np.empty((24,len(selected),256),np.float64)
        for h in range(24):
            scores = (qn[0,h,selected].astype(np.float64)/16) @ kn[0,h//12].astype(np.float64).T
            scores[~mask[selected]] = -np.inf
            p = np.exp(scores-scores.max(axis=-1,keepdims=True)); p /= p.sum(axis=-1,keepdims=True)
            ref[h] = p @ vn[0,h//12].astype(np.float64)
        case = dict(seed=seed,rows=rows,keys=keys,mask=kind,arms={})
        for label,out in zip(['unfused','fused'],outputs):
            got = np.array(out.astype(mx.float32))[0,:,selected,:].transpose(1,0,2)
            # NumPy advanced indexing moves the selected-row axis first.
            assert got.shape == ref.shape, (got.shape,ref.shape)
            delta = got-ref
            case['arms'][label] = dict(relative_l2=float(np.linalg.norm(delta)/np.linalg.norm(ref)),
                                      max_abs=float(np.abs(delta).max()),finite=bool(np.isfinite(got).all()))
        case['fused_lower_l2_error'] = case['arms']['fused']['relative_l2'] < case['arms']['unfused']['relative_l2']
        record['cases'].append(case)
        print(json.dumps(case),flush=True)
        (root/'accuracy.json').write_text(json.dumps(record,indent=2)+'\n')
        del q,k,v,m,outputs,qn,kn,vn,ref,got,delta
        mx.clear_cache()
record['after']=vm()
record['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
(root/'accuracy.json').write_text(json.dumps(record,indent=2)+'\n')
